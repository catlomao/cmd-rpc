
#include "rpc_text.c"
#include "rpc.h"
#include "/secure/encryption.pa"
#include "/secure/encryption-sha2.pa"

Eq_9347 g_t0003;
uint8 g_b0104; // 0000000000000104
word16 g_w40000000; // 0000000040000000
word32 g_dw4000003C; // 000000004000003C
LONG g_t400016C0(struct _EXCEPTION_POINTERS * ExceptionInfo); // 00000000400016C0
int32 g_t400019C0(struct _exception * rcx); // 00000000400019C0
INT_PTR g_t400036F0(HWND rcx, UINT rdx, WPARAM r8, LPARAM r9); // 00000000400036F0
INT_PTR g_t400049A0(HWND rcx, UINT rdx, WPARAM r8, LPARAM r9); // 00000000400049A0
DWORD g_t40004BE0(LPVOID lpThreadParameter); // 0000000040004BE0
INT_PTR g_t40006050(HWND rcx, UINT rdx, WPARAM r8, LPARAM r9); // 0000000040006050
INT_PTR g_t400066A0(HWND rcx, UINT rdx, WPARAM r8, LPARAM r9); // 00000000400066A0
INT_PTR g_t400078B0(HWND rcx, UINT rdx, WPARAM r8, LPARAM r9); // 00000000400078B0
BOOL g_t40008AB0(HMODULE hModule, LPCSTR lpType, LPCSTR lpName, WORD wLanguage, LONG_PTR lParam); // 0000000040008AB0
struct _EXCEPTION_POINTERS g_t40009000;
<anonymous> * __imp__GetTokenInformation; // 0000000040009150
<anonymous> * __imp__RegDeleteValueA; // 0000000040009158
<anonymous> * __imp__RegOpenKeyExA; // 0000000040009160
<anonymous> * __imp__RegQueryInfoKeyA; // 0000000040009168
<anonymous> * __imp__FreeSid; // 0000000040009170
<anonymous> * __imp__OpenProcessToken; // 0000000040009178
<anonymous> * __imp__RegSetValueExA; // 0000000040009180
<anonymous> * __imp__RegCreateKeyExA; // 0000000040009188
<anonymous> * __imp__LookupPrivilegeValueA; // 0000000040009190
<anonymous> * __imp__AllocateAndInitializeSid; // 0000000040009198
<anonymous> * __imp__RegQueryValueExA; // 00000000400091A0
<anonymous> * __imp__EqualSid; // 00000000400091A8
<anonymous> * __imp__RegCloseKey; // 00000000400091B0
<anonymous> * __imp__AdjustTokenPrivileges; // 00000000400091B8
<anonymous> * __imp__COMCTL32.dll_17; // 00000000400091C8
<anonymous> * __imp__Cabinet.dll_20; // 00000000400091D8
<anonymous> * __imp__Cabinet.dll_21; // 00000000400091E0
<anonymous> * __imp__Cabinet.dll_23; // 00000000400091E8
<anonymous> * __imp__Cabinet.dll_22; // 00000000400091F0
<anonymous> * __imp__GetDeviceCaps; // 0000000040009200
<anonymous> * __imp___lopen; // 0000000040009210
<anonymous> * __imp___llseek; // 0000000040009218
<anonymous> * __imp__CompareStringA; // 0000000040009220
<anonymous> * __imp__GetLastError; // 0000000040009228
<anonymous> * __imp__GetFileAttributesA; // 0000000040009230
<anonymous> * __imp__GetSystemDirectoryA; // 0000000040009238
<anonymous> * __imp__LoadLibraryA; // 0000000040009240
<anonymous> * __imp__DeleteFileA; // 0000000040009248
<anonymous> * __imp__GlobalAlloc; // 0000000040009250
<anonymous> * __imp__GlobalFree; // 0000000040009258
<anonymous> * __imp__CloseHandle; // 0000000040009260
<anonymous> * __imp__WritePrivateProfileStringA; // 0000000040009268
<anonymous> * __imp__IsDBCSLeadByte; // 0000000040009270
<anonymous> * __imp__GetWindowsDirectoryA; // 0000000040009278
<anonymous> * __imp__SetFileAttributesA; // 0000000040009280
<anonymous> * __imp__GetProcAddress; // 0000000040009288
<anonymous> * __imp__GlobalLock; // 0000000040009290
<anonymous> * __imp__LocalFree; // 0000000040009298
<anonymous> * __imp__RemoveDirectoryA; // 00000000400092A0
<anonymous> * __imp__FreeLibrary; // 00000000400092A8
<anonymous> * __imp___lclose; // 00000000400092B0
<anonymous> * __imp__CreateDirectoryA; // 00000000400092B8
<anonymous> * __imp__GetPrivateProfileIntA; // 00000000400092C0
<anonymous> * __imp__GetPrivateProfileStringA; // 00000000400092C8
<anonymous> * __imp__GlobalUnlock; // 00000000400092D0
<anonymous> * __imp__ReadFile; // 00000000400092D8
<anonymous> * __imp__SizeofResource; // 00000000400092E0
<anonymous> * __imp__WriteFile; // 00000000400092E8
<anonymous> * __imp__GetDriveTypeA; // 00000000400092F0
<anonymous> * __imp__LoadLibraryExA; // 00000000400092F8
<anonymous> * __imp__SetFileTime; // 0000000040009300
<anonymous> * __imp__SetFilePointer; // 0000000040009308
<anonymous> * __imp__FindResourceA; // 0000000040009310
<anonymous> * __imp__CreateMutexA; // 0000000040009318
<anonymous> * __imp__GetVolumeInformationA; // 0000000040009320
<anonymous> * __imp__WaitForSingleObject; // 0000000040009328
<anonymous> * __imp__GetCurrentDirectoryA; // 0000000040009330
<anonymous> * __imp__FreeResource; // 0000000040009338
<anonymous> * __imp__GetVersion; // 0000000040009340
<anonymous> * __imp__SetCurrentDirectoryA; // 0000000040009348
<anonymous> * __imp__GetTempPathA; // 0000000040009350
<anonymous> * __imp__LocalFileTimeToFileTime; // 0000000040009358
<anonymous> * __imp__CreateFileA; // 0000000040009360
<anonymous> * __imp__SetEvent; // 0000000040009368
<anonymous> * __imp__TerminateThread; // 0000000040009370
<anonymous> * __imp__GetVersionExA; // 0000000040009378
<anonymous> * __imp__LockResource; // 0000000040009380
<anonymous> * __imp__GetSystemInfo; // 0000000040009388
<anonymous> * __imp__CreateThread; // 0000000040009390
<anonymous> * __imp__ResetEvent; // 0000000040009398
<anonymous> * __imp__LoadResource; // 00000000400093A0
<anonymous> * __imp__ExitProcess; // 00000000400093A8
<anonymous> * __imp__GetModuleHandleW; // 00000000400093B0
<anonymous> * __imp__CreateProcessA; // 00000000400093B8
<anonymous> * __imp__FormatMessageA; // 00000000400093C0
<anonymous> * __imp__GetTempFileNameA; // 00000000400093C8
<anonymous> * __imp__DosDateTimeToFileTime; // 00000000400093D0
<anonymous> * __imp__CreateEventA; // 00000000400093D8
<anonymous> * __imp__GetExitCodeProcess; // 00000000400093E0
<anonymous> * __imp__ExpandEnvironmentStringsA; // 00000000400093E8
<anonymous> * __imp__LocalAlloc; // 00000000400093F0
<anonymous> * __imp__lstrcmpA; // 00000000400093F8
<anonymous> * __imp__FindNextFileA; // 0000000040009400
<anonymous> * __imp__GetCurrentProcess; // 0000000040009408
<anonymous> * __imp__FindFirstFileA; // 0000000040009410
<anonymous> * __imp__GetModuleFileNameA; // 0000000040009418
<anonymous> * __imp__GetShortPathNameA; // 0000000040009420
<anonymous> * __imp__Sleep; // 0000000040009428
<anonymous> * __imp__GetStartupInfoW; // 0000000040009430
<anonymous> * __imp__RtlCaptureContext; // 0000000040009438
<anonymous> * __imp__RtlLookupFunctionEntry; // 0000000040009440
<anonymous> * __imp__RtlVirtualUnwind; // 0000000040009448
<anonymous> * __imp__UnhandledExceptionFilter; // 0000000040009450
<anonymous> * __imp__SetUnhandledExceptionFilter; // 0000000040009458
<anonymous> * __imp__TerminateProcess; // 0000000040009460
<anonymous> * __imp__QueryPerformanceCounter; // 0000000040009468
<anonymous> * __imp__GetCurrentProcessId; // 0000000040009470
<anonymous> * __imp__GetCurrentThreadId; // 0000000040009478
<anonymous> * __imp__GetSystemTimeAsFileTime; // 0000000040009480
<anonymous> * __imp__GetTickCount; // 0000000040009488
<anonymous> * __imp__EnumResourceLanguagesA; // 0000000040009490
<anonymous> * __imp__GetDiskFreeSpaceA; // 0000000040009498
<anonymous> * __imp__MulDiv; // 00000000400094A0
<anonymous> * __imp__FindClose; // 00000000400094A8
<anonymous> * __imp__ShowWindow; // 00000000400094B8
<anonymous> * __imp__MsgWaitForMultipleObjects; // 00000000400094C0
<anonymous> * __imp__SetWindowPos; // 00000000400094C8
<anonymous> * __imp__GetDC; // 00000000400094D0
<anonymous> * __imp__GetWindowRect; // 00000000400094D8
<anonymous> * __imp__DispatchMessageA; // 00000000400094E0
<anonymous> * __imp__GetSystemMetrics; // 00000000400094E8
<anonymous> * __imp__CallWindowProcA; // 00000000400094F0
<anonymous> * __imp__SetWindowTextA; // 00000000400094F8
<anonymous> * __imp__MessageBoxA; // 0000000040009500
<anonymous> * __imp__SendDlgItemMessageA; // 0000000040009508
<anonymous> * __imp__SendMessageA; // 0000000040009510
<anonymous> * __imp__GetDlgItem; // 0000000040009518
<anonymous> * __imp__DialogBoxIndirectParamA; // 0000000040009520
<anonymous> * __imp__GetWindowLongPtrA; // 0000000040009528
<anonymous> * __imp__SetWindowLongPtrA; // 0000000040009530
<anonymous> * __imp__SetForegroundWindow; // 0000000040009538
<anonymous> * __imp__ReleaseDC; // 0000000040009540
<anonymous> * __imp__EnableWindow; // 0000000040009548
<anonymous> * __imp__CharNextA; // 0000000040009550
<anonymous> * __imp__LoadStringA; // 0000000040009558
<anonymous> * __imp__CharPrevA; // 0000000040009560
<anonymous> * __imp__EndDialog; // 0000000040009568
<anonymous> * __imp__MessageBeep; // 0000000040009570
<anonymous> * __imp__ExitWindowsEx; // 0000000040009578
<anonymous> * __imp__SetDlgItemTextA; // 0000000040009580
<anonymous> * __imp__CharUpperA; // 0000000040009588
<anonymous> * __imp__GetDesktopWindow; // 0000000040009590
<anonymous> * __imp__PeekMessageA; // 0000000040009598
<anonymous> * __imp__GetDlgItemTextA; // 00000000400095A0
<anonymous> * __imp__VerQueryValueA; // 00000000400095B0
<anonymous> * __imp__GetFileVersionInfoSizeA; // 00000000400095B8
<anonymous> * __imp__GetFileVersionInfoA; // 00000000400095C0
<anonymous> * __imp__?terminate@@YAXXZ; // 00000000400095D0
<anonymous> * __imp___commode; // 00000000400095D8
<anonymous> * __imp___fmode; // 00000000400095E0
<anonymous> * __imp___acmdln; // 00000000400095E8
<anonymous> * __imp____C_specific_handler; // 00000000400095F0
<anonymous> * __imp__memset; // 00000000400095F8
<anonymous> * __imp____setusermatherr; // 0000000040009600
<anonymous> * __imp___ismbblead; // 0000000040009608
<anonymous> * __imp___cexit; // 0000000040009610
<anonymous> * __imp___exit; // 0000000040009618
<anonymous> * __imp__exit; // 0000000040009620
<anonymous> * __imp____set_app_type; // 0000000040009628
<anonymous> * __imp____getmainargs; // 0000000040009630
<anonymous> * __imp___amsg_exit; // 0000000040009638
<anonymous> * __imp___XcptFilter; // 0000000040009640
<anonymous> * __imp__memcpy_s; // 0000000040009648
<anonymous> * __imp___vsnprintf; // 0000000040009650
<anonymous> * __imp___initterm; // 0000000040009658
<anonymous> * __imp__memcpy; // 0000000040009660
<anonymous> * g_ptr40009678; // 0000000040009678
PVFV g_t400096A0; // 00000000400096A0
PVFV g_t400096B0; // 00000000400096B0
word64 g_qw400096B8; // 00000000400096B8
word64 g_qw400096D0; // 00000000400096D0
byte g_b400097A0; // 00000000400097A0
byte g_b400097A4; // 00000000400097A4
byte g_b400097B0; // 00000000400097B0
byte g_b400097B4; // 00000000400097B4
WCHAR g_t40009890; // 0000000040009890
struct HRSRC__ g_t400098F0;
Eq_1055 g_t40009998;
word64 g_qw4000A448; // 000000004000A448
word64 g_qw4000A450; // 000000004000A450
word64 g_qw4000A458; // 000000004000A458
word64 g_qw4000A460; // 000000004000A460
word64 g_qw4000A468; // 000000004000A468
word64 g_qw4000A470; // 000000004000A470
word64 g_qw4000A478; // 000000004000A478
word64 g_qw4000A480; // 000000004000A480
word64 g_qw4000A488; // 000000004000A488
word64 g_qw4000A490; // 000000004000A490
word64 g_qw4000A498; // 000000004000A498
word64 g_qw4000A4A0; // 000000004000A4A0
word64 g_qw4000A4A8; // 000000004000A4A8
word64 g_qw4000A4B0; // 000000004000A4B0
word64 g_qw4000A4C0; // 000000004000A4C0
word64 g_qw4000A4D0; // 000000004000A4D0
word64 g_qw4000A4D8; // 000000004000A4D8
word64 g_qw4000A4E0; // 000000004000A4E0
word64 g_qw4000A4E8; // 000000004000A4E8
word64 g_qw4000A4F8; // 000000004000A4F8
word64 g_qw4000A508; // 000000004000A508
word64 g_qw4000A510; // 000000004000A510
word64 g_qw4000A518; // 000000004000A518
word64 g_qw4000A520; // 000000004000A520
word64 g_qw4000A528; // 000000004000A528
word64 g_qw4000A530; // 000000004000A530
word64 g_qw4000A538; // 000000004000A538
word64 g_qw4000A540; // 000000004000A540
word64 g_qw4000A548; // 000000004000A548
word64 g_qw4000A550; // 000000004000A550
word64 g_qw4000A558; // 000000004000A558
word64 g_qw4000A560; // 000000004000A560
word64 g_qw4000A568; // 000000004000A568
word64 g_qw4000A570; // 000000004000A570
word64 g_qw4000A578; // 000000004000A578
word64 g_qw4000A580; // 000000004000A580
word64 g_qw4000A588; // 000000004000A588
word64 g_qw4000A590; // 000000004000A590
word64 g_qw4000A598; // 000000004000A598
word64 g_qw4000A5A0; // 000000004000A5A0
word64 g_qw4000A5A8; // 000000004000A5A8
word64 g_qw4000A5B0; // 000000004000A5B0
word64 g_qw4000A5B8; // 000000004000A5B8
word64 g_qw4000A5C0; // 000000004000A5C0
word64 g_qw4000A5C8; // 000000004000A5C8
word64 g_qw4000A5D0; // 000000004000A5D0
word64 g_qw4000A5D8; // 000000004000A5D8
word64 g_qw4000A5E0; // 000000004000A5E0
word64 g_qw4000A5E8; // 000000004000A5E8
word64 g_qw4000A5F0; // 000000004000A5F0
word64 g_qw4000A5F8; // 000000004000A5F8
word64 g_qw4000A600; // 000000004000A600
word64 g_qw4000A608; // 000000004000A608
word64 g_qw4000A610; // 000000004000A610
word64 g_qw4000A618; // 000000004000A618
word64 g_qw4000A620; // 000000004000A620
word64 g_qw4000A628; // 000000004000A628
word64 g_qw4000A630; // 000000004000A630
word64 g_qw4000A638; // 000000004000A638
word64 g_qw4000A640; // 000000004000A640
word64 g_qw4000A648; // 000000004000A648
word64 g_qw4000A650; // 000000004000A650
word64 g_qw4000A658; // 000000004000A658
word64 g_qw4000A660; // 000000004000A660
word64 g_qw4000A668; // 000000004000A668
word64 g_qw4000A670; // 000000004000A670
word64 g_qw4000A678; // 000000004000A678
word64 g_qw4000A680; // 000000004000A680
word64 g_qw4000A688; // 000000004000A688
word64 g_qw4000A690; // 000000004000A690
word64 g_qw4000A698; // 000000004000A698
word64 g_qw4000A6A0; // 000000004000A6A0
word64 g_qw4000A6A8; // 000000004000A6A8
word64 g_qw4000A6B0; // 000000004000A6B0
word64 g_qw4000A6B8; // 000000004000A6B8
word64 g_qw4000A6C0; // 000000004000A6C0
word64 g_qw4000A6C8; // 000000004000A6C8
word64 g_qw4000A6D0; // 000000004000A6D0
word64 g_qw4000A6D8; // 000000004000A6D8
word64 g_qw4000A6E0; // 000000004000A6E0
word64 g_qw4000A6E8; // 000000004000A6E8
word64 g_qw4000A6F0; // 000000004000A6F0
word64 g_qw4000A6F8; // 000000004000A6F8
word64 g_qw4000A700; // 000000004000A700
word64 g_qw4000A708; // 000000004000A708
word64 g_qw4000A710; // 000000004000A710
word64 g_qw4000A718; // 000000004000A718
word64 g_qw4000A720; // 000000004000A720
word64 g_qw4000A728; // 000000004000A728
word64 g_qw4000A730; // 000000004000A730
word64 g_qw4000A738; // 000000004000A738
word64 g_qw4000A740; // 000000004000A740
word64 g_qw4000A748; // 000000004000A748
word64 g_qw4000A750; // 000000004000A750
word64 g_qw4000A758; // 000000004000A758
word64 g_qw4000A760; // 000000004000A760
word64 g_qw4000A768; // 000000004000A768
word64 g_qw4000A770; // 000000004000A770
word64 g_qw4000A778; // 000000004000A778
word64 g_qw4000A780; // 000000004000A780
word64 g_qw4000A788; // 000000004000A788
word64 g_qw4000A790; // 000000004000A790
word64 g_qw4000A798; // 000000004000A798
word64 g_qw4000A7A0; // 000000004000A7A0
word64 g_qw4000A7B0; // 000000004000A7B0
word64 g_qw4000A7B8; // 000000004000A7B8
word64 g_qw4000A7C0; // 000000004000A7C0
word64 g_qw4000A7C8; // 000000004000A7C8
word64 g_qw4000A7D0; // 000000004000A7D0
word64 g_qw4000A7D8; // 000000004000A7D8
word64 g_qw4000A7E0; // 000000004000A7E0
word64 g_qw4000A7E8; // 000000004000A7E8
word64 g_qw4000A7F0; // 000000004000A7F0
word64 g_qw4000A7F8; // 000000004000A7F8
word64 g_qw4000A800; // 000000004000A800
word64 g_qw4000A808; // 000000004000A808
word64 g_qw4000A810; // 000000004000A810
word64 g_qw4000A818; // 000000004000A818
word64 g_qw4000A820; // 000000004000A820
word64 g_qw4000A828; // 000000004000A828
word64 g_qw4000A830; // 000000004000A830
word64 g_qw4000A838; // 000000004000A838
word64 g_qw4000A840; // 000000004000A840
word64 g_qw4000A848; // 000000004000A848
word64 g_qw4000A850; // 000000004000A850
word64 g_qw4000A858; // 000000004000A858
word64 g_qw4000A860; // 000000004000A860
word64 g_qw4000A868; // 000000004000A868
word64 g_qw4000A870; // 000000004000A870
word64 g_qw4000A878; // 000000004000A878
word64 g_qw4000A880; // 000000004000A880
word64 g_qw4000A888; // 000000004000A888
word64 g_qw4000A890; // 000000004000A890
word64 g_qw4000A898; // 000000004000A898
word64 g_qw4000A8A8; // 000000004000A8A8
word64 g_qw4000A8B0; // 000000004000A8B0
word64 g_qw4000A8B8; // 000000004000A8B8
word64 g_qw4000A8C8; // 000000004000A8C8
word64 g_qw4000A8D0; // 000000004000A8D0
word64 g_qw4000A8D8; // 000000004000A8D8
word64 g_qw4000A8E0; // 000000004000A8E0
word64 g_qw4000A8E8; // 000000004000A8E8
word64 g_qw4000A8F0; // 000000004000A8F0
word64 g_qw4000A8F8; // 000000004000A8F8
word64 g_qw4000A900; // 000000004000A900
word64 g_qw4000A908; // 000000004000A908
word64 g_qw4000A910; // 000000004000A910
word64 g_qw4000A918; // 000000004000A918
word64 g_qw4000A920; // 000000004000A920
word64 g_qw4000A928; // 000000004000A928
word64 g_qw4000A930; // 000000004000A930
word64 g_qw4000A938; // 000000004000A938
word64 g_qw4000A940; // 000000004000A940
word64 g_qw4000A948; // 000000004000A948
word64 g_qw4000A950; // 000000004000A950
word64 g_qw4000A958; // 000000004000A958
word32 g_dw4000C000; // 000000004000C000
ui64 g_qw4000C008; // 000000004000C008
word64 g_qw4000C010; // 000000004000C010
word32 g_dw4000C14C; // 000000004000C14C
word32 g_dw4000C1A8; // 000000004000C1A8
Eq_1054 g_t4000C1AC;
word32 g_dw4000C208; // 000000004000C208
word32 g_dw4000C20C; // 000000004000C20C
word32 g_dw4000C220; // 000000004000C220
word32 g_dw4000C224; // 000000004000C224
int32 g_dw4000C228; // 000000004000C228
int32 g_dw4000C22C; // 000000004000C22C
char ** g_ptr4000C230; // 000000004000C230
char ** g_ptr4000C238; // 000000004000C238
uint32 g_dw4000C240; // 000000004000C240
word32 g_dw4000C244; // 000000004000C244
word32 g_dw4000C250; // 000000004000C250
word32 g_dw4000C254; // 000000004000C254
Eq_415 g_t4000C260; // 000000004000C260
word32 g_dw4000C268; // 000000004000C268
word64 g_qw4000C270; // 000000004000C270
ui64 g_qw4000C278; // 000000004000C278
word64 g_qw4000C280; // 000000004000C280
CONTEXT g_t4000C2F0;
ui64 g_qw4000C370; // 000000004000C370
ULONGLONG * g_ptr4000C388; // 000000004000C388
Eq_415 g_t4000C3E8; // 000000004000C3E8
word32 g_dw4000C7C0; // 000000004000C7C0
word32 g_dw4000C7C4; // 000000004000C7C4
word32 g_dw4000C7C8; // 000000004000C7C8
word32 g_dw4000C7CC; // 000000004000C7CC
byte g_b4000C7D0; // 000000004000C7D0
word32 g_dw4000C820; // 000000004000C820
Eq_1049 g_t4000C828; // 000000004000C828
Eq_384 g_t4000C830; // 000000004000C830
Eq_384 g_t4000C838; // 000000004000C838
word32 g_dw4000C840; // 000000004000C840
Eq_384 g_t4000CA58; // 000000004000CA58
byte g_b4000CA60; // 000000004000CA60
word64 g_qw4000CB68; // 000000004000CB68
word64 g_qw4000CB70; // 000000004000CB70
uint64 g_qw4000CB78; // 000000004000CB78
word32 g_dw4000CB80; // 000000004000CB80
word64 g_qw4000CB88; // 000000004000CB88
Eq_7140 g_t4000CB90; // 000000004000CB90
byte g_b4000CBA0; // 000000004000CBA0
word32 g_a4000CCC0[];
word32 g_dw4000CCE0; // 000000004000CCE0
word32 g_dw4000CD00; // 000000004000CD00
Eq_1054 g_t4000CD04;
word32 g_dw4000CD08; // 000000004000CD08
word32 g_dw4000CD0C; // 000000004000CD0C
word32 g_dw4000CD10; // 000000004000CD10
word32 g_dw4000CD14; // 000000004000CD14
Eq_4245 g_t4000CD18;
byte g_b4000CD1A; // 000000004000CD1A
byte g_b4000CE1E; // 000000004000CE1E
byte g_b4000CE1F; // 000000004000CE1F
byte g_b4000CF22; // 000000004000CF22
ui32 g_dw4000D028; // 000000004000D028
Eq_225 g_t4000D030;
struct Eq_5064 g_t4000D040;
Eq_405 g_t4000D540;
int32 g_dw4000D544; // 000000004000D544
Eq_225 g_t4000D560;
word32 g_dw4000D568; // 000000004000D568
word32 g_dw4000D56C; // 000000004000D56C
word32 g_dw4000D5FC; // 000000004000D5FC
word32 g_dw4000D600; // 000000004000D600
Eq_225 g_t4000D608;
byte g_a4000D610[4];
byte g_b4000D611; // 000000004000D611
word32 g_dw4000D818; // 000000004000D818
word32 g_dw4000D820; // 000000004000D820
word32 g_dw4000D824; // 000000004000D824
word32 g_dw4000D82C; // 000000004000D82C
Eq_225 g_t4000D830;
struct Eq_9523 g_t4000DB4C;
byte g_b4000DC50; // 000000004000DC50
byte g_b4000DD54; // 000000004000DD54
word16 g_w4000DE58; // 000000004000DE58
word16 g_w4000DE5A; // 000000004000DE5A
int32 g_dw4000DE5C; // 000000004000DE5C
word32 g_dw4000DE60; // 000000004000DE60
Eq_1406 g_t4000DE64;
word32 g_dw4000DE68; // 000000004000DE68
Eq_265 g_t4000DE70;
word16 g_w4000DE78; // 000000004000DE78
word32 g_dw4000DE7C; // 000000004000DE7C
Eq_989 g_tFFFFFFFF;
