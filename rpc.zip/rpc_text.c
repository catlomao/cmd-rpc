#include "rpc.h"
#include "/secure/encryption.pa"
#include "/secure/encryption-sha2.pa"
// 0000000140001010: void fn0000000140001010()
void fn0000000140001010()
{
	uint32 eax_24;
	if (g_w40000000 != 23117)
	{
l0000000140001022:
		eax_24 = 0x00;
		goto l0000000140001079;
	}
	struct Eq_7 * rcx_12 = (int64) g_dw4000003C + 0x140000000;
	if (rcx_12->dw0000 != 0x4550)
		goto l0000000140001022;
	bool v21_96;
	if (rcx_12->w0018 != 0x010B)
	{
		if (rcx_12->w0018 != 0x020B)
			goto l0000000140001022;
		eax_24 = 0x00;
		if (rcx_12->dw0084 <= 0x0E)
		{
l0000000140001079:
			g_dw4000C240 = eax_24;
			__set_app_type((uint64) (word32) (uint64) fn0000000140001798(0x02));
			g_qw4000CB68 = ~0x00;
			g_qw4000CB70 = ~0x00;
			*fmode = (word32) (uint64) g_dw4000C7CC;
			*commode = (word32) (uint64) g_dw4000C7C0;
			fn00000001400017F0();
			if (g_dw4000C000 == 0x00)
				__setusermatherr(&g_t400019C0);
			return;
		}
		v21_96 = rcx_12->dw00F8 != 0x00;
	}
	else
	{
		eax_24 = 0x00;
		if (rcx_12->dw0074 <= 0x0E)
			goto l0000000140001079;
		v21_96 = rcx_12->dw00E8 != 0x00;
	}
	eax_24 = (uint32) (int8) v21_96;
	goto l0000000140001079;
}

// 00000001400010F0: void fn00000001400010F0()
void fn00000001400010F0()
{
	Eq_104 r9_9 = (uint64) g_dw4000C7C4;
	g_dw4000C244 = (word32) (uint64) g_dw4000C7C8;
	g_dw4000C22C = __getmainargs(&g_dw4000C228, &g_ptr4000C230, &g_ptr4000C238, r9_9);
}

// 0000000140001150: Register Eq_126 Win32CrtStartup()
Eq_126 Win32CrtStartup()
{
	fn00000001400018E4(qwLoc18);
	return (DWORD) (uint64) fn0000000140001168(gs);
}

// 0000000140001168: Register word32 fn0000000140001168(Register (ptr32 Eq_134) gs)
// Called from:
//      Win32CrtStartup
word32 fn0000000140001168(struct Eq_134 * gs)
{
	GetStartupInfoW(fp - 0x78);
	word64 rbx_17 = gs->ptr0030->qw0008;
	word32 edi_20 = 0x00;
	while (true)
	{
		__lock();
		word64 rax_30;
		if (__cmpxchg(g_qw4000CB78, rbx_17, 0x00, out rax_30))
			break;
		if (rax_30 == rbx_17)
		{
			edi_20 = 0x01;
			break;
		}
		Sleep(1000);
	}
	uint64 rax_254;
	uint64 rax_40 = (uint64) g_dw4000CB80;
	if ((word32) rax_40 == 0x01)
		_amsg_exit((uint64) (word32) (rax_40 + 0x1E));
	else
	{
		Eq_318 eax_304 = (word32) (uint64) g_dw4000CB80;
		if (eax_304 == 0x00)
		{
			g_dw4000CB80 = 0x01;
			word64 * rbx_53;
			for (rbx_53 = &g_qw400096B8; rbx_53 < &g_qw400096D0; ++rbx_53)
			{
				if (eax_304 != 0x00)
					goto l000000014000123A;
				if (*rbx_53 != 0x00)
				{
					eax_304.u0 = *rbx_53;
					fn0000000140008E50();
				}
			}
			if (eax_304 != 0x00)
			{
l000000014000123A:
				rax_254 = 0xFF;
				return (word32) rax_254;
			}
		}
		else
			g_dw4000C224 = 0x01;
	}
	if ((word32) (uint64) g_dw4000CB80 == 0x01)
	{
		_initterm(&g_t400096A0, &g_t400096B0);
		g_dw4000CB80 = 0x02;
	}
	if (edi_20 == 0x00)
		g_qw4000CB78 = 0x00;
	if (g_qw4000CB88 != 0x00 && (word32) ((uint64) fn0000000140001850(0x14000CB88)) != 0x00)
		fn0000000140008E50();
	Eq_225 rbx_147 = *acmdln;
	uint64 rdi_182 = 0x00;
	while (true)
	{
		word32 edi_165 = (word32) rdi_182;
		cu8 cl_159 = (byte) (uint64) (word32) *rbx_147;
		if (cl_159 <= 0x20 && (cl_159 == 0x00 || edi_165 == 0x00))
			break;
		if (cl_159 == 0x22)
			rdi_182 = (uint64) (uint32) (int8) (edi_165 == 0x00);
		word64 rax_200;
		word64 rdx_201;
		word64 r10_202;
		word64 r8_203;
		word64 r9_204;
		ismbblead();
		if ((word32) rax_200 != 0x00)
			rbx_147 = (word128) rbx_147 + 1;
		rbx_147 = (word128) rbx_147 + 1;
	}
	while (cl_159 <= 0x20 && cl_159 >= 0x01)
	{
		rbx_147 = (word128) rbx_147 + 1;
		cl_159 = (cu8) *rbx_147;
	}
	rax_254 = (uint64) fn0000000140007FE4(0x140000000, rbx_147);
	word32 eax_264 = (word32) rax_254;
	g_dw4000C220 = eax_264;
	if (g_dw4000C240 != 0x00)
	{
		if (g_dw4000C224 == 0x00)
		{
			word64 rdx_277;
			word64 r10_278;
			word64 r8_279;
			word64 r9_280;
			cexit();
			rax_254 = (uint64) g_dw4000C220;
		}
		return (word32) rax_254;
	}
	else
		exit((uint64) eax_264);
}

// 00000001400013E0: Register word64 fn00000001400013E0(Register ui64 rcx)
// Called from:
//      fn0000000140001A08
//      fn0000000140001D28
//      fn0000000140002590
//      fn00000001400026B8
//      fn00000001400028B8
//      fn0000000140002A10
//      fn0000000140002D34
//      fn0000000140003044
//      fn0000000140003118
//      fn000000014000332C
//      fn00000001400033BC
//      fn00000001400036F0
//      fn0000000140003C8C
//      fn0000000140003DF0
//      fn00000001400041EC
//      fn00000001400043CC
//      fn00000001400046E8
//      fn0000000140004FD8
//      fn000000014000521C
//      fn0000000140005810
//      fn0000000140005B50
//      fn00000001400061E8
//      fn00000001400065B8
//      fn0000000140006768
//      fn0000000140006E50
//      fn0000000140007010
//      fn000000014000721C
//      fn0000000140007BB8
//      fn0000000140007E28
//      fn00000001400081D0
//      fn0000000140008BB4
//      fn0000000140008DA0
word64 fn00000001400013E0(ui64 rcx)
{
	if (rcx != g_qw4000C008)
		return fn0000000140001440(rcx);
	word64 rcx_8 = __rol(rcx, 0x10);
	if ((word16) rcx_8 == 0x00)
		return rax;
	rcx = __ror(rcx_8, 0x10);
	return fn0000000140001440(rcx);
}

// 0000000140001404: Register word64 fn0000000140001404(Register (ptr64 Eq_383) rcx, Register out Eq_384 rcxOut)
// Called from:
//      fn00000001400013E0
//      fn00000001400015B8
word64 fn0000000140001404(struct _EXCEPTION_POINTERS * rcx, HANDLE & rcxOut)
{
	word32 rax_32_32_15 = SLICE(SetUnhandledExceptionFilter(null), word32, 32);
	UnhandledExceptionFilter(rcx);
	Eq_384 rax_16 = SEQ(rax_32_32_15, GetCurrentProcess());
	word64 rax_28 = SEQ(rax_32_32_15, TerminateProcess(rax_16, 0xC0000409));
	rcxOut = rax_16;
	return rax_28;
}

// 0000000140001440: Register ptr64 fn0000000140001440(Register ui64 rcx)
// Called from:
//      fn00000001400013E0
ptr64 fn0000000140001440(ui64 rcx)
{
	RtlCaptureContext(&g_t4000C2F0);
	Eq_415 rax_7 = g_t4000C3E8;
	Eq_418 rax_13 = RtlLookupFunctionEntry(rax_7, fp - 0x38, null);
	if (rax_13 != null)
		KERNEL32.dll!RtlVirtualUnwind();
	else
	{
		g_t4000C3E8 = (Eq_415) *g_ptr4000C388;
		++g_ptr4000C388;
	}
	g_t4000C260 = g_t4000C3E8;
	g_qw4000C370 = rcx;
	g_dw4000C250 = 0xC0000409;
	g_dw4000C254 = 0x01;
	g_dw4000C268 = 0x03;
	g_qw4000C270 = 0x02;
	g_qw4000C278 = g_qw4000C008;
	g_qw4000C280 = g_qw4000C010;
	word64 rcx_110;
	return fn0000000140001404(&g_t40009000, out rcx_110);
}

// 00000001400015B8: FlagGroup bool fn00000001400015B8(Register out ptr64 raxOut, Register out Eq_480 ecxOut)
// Called from:
//      fn0000000140006768
bool fn00000001400015B8(ptr64 & raxOut, union Eq_480 & ecxOut)
{
	RtlCaptureContext(&g_t4000C2F0);
	Eq_415 rax_6 = g_t4000C3E8;
	Eq_418 rax_12 = RtlLookupFunctionEntry(rax_6, fp - 0x28, null);
	if (rax_12 != null)
		KERNEL32.dll!RtlVirtualUnwind();
	else
	{
		g_t4000C3E8 = (Eq_415) *g_ptr4000C388;
		++g_ptr4000C388;
	}
	g_t4000C260 = g_t4000C3E8;
	g_dw4000C250 = 0xC0000409;
	g_dw4000C254 = 0x01;
	g_dw4000C268 = 0x01;
	g_qw4000C270 = 0x08;
	word64 rcx_58;
	raxOut = fn0000000140001404(&g_t40009000, out rcx_58);
	ecxOut.u0 = <invalid>;
	return SLICE(cond(fp), bool, 4);
}

// 00000001400016C0: void fn00000001400016C0(Register (ptr64 (ptr64 Eq_536)) rcx)
void fn00000001400016C0(struct Eq_536 ** rcx)
{
	struct Eq_536 * rax_6 = *rcx;
	if (rax_6->dw0000 == ~0x1F928C9C && rax_6->dw0018 == 0x04)
	{
		uint64 rcx_12 = (uint64) rax_6->dw0020;
		word32 ecx_18 = (word32) rcx_12;
		if ((word32) (uint64) (word32) (rcx_12 + ~0x1993051F) <= 0x02 || ecx_18 == 0x01994000)
		{
			terminate();
			int3();
		}
	}
}

// 0000000140001710: void fn0000000140001710()
void fn0000000140001710()
{
	SetUnhandledExceptionFilter(&g_t400016C0);
}

// 000000014000173C: Register (ptr64 word32) fn000000014000173C(Register Eq_265 rcx)
// Called from:
//      fn0000000140001798
word32 * fn000000014000173C(Eq_265 rcx)
{
	word32 * rdx_28 = null;
	if (rcx <= ~0x01)
	{
		if (*rcx == 23117 && (*((word64) rcx + 60) >= 0x00 && *((word64) rcx + 60) < 0x10000000))
		{
			word32 * rax_22 = (word64) rcx + (int64) (*((word64) rcx + 60));
			if (*rax_22 != 0x4550)
				rax_22 = null;
			rdx_28 = rax_22;
		}
	}
	return rdx_28;
}

// 0000000140001798: Register word32 fn0000000140001798(Register word32 ecx)
// Called from:
//      fn0000000140001010
word32 fn0000000140001798(word32 ecx)
{
	uint64 rax_40;
	word32 ebx_36 = (word32) (uint64) ecx;
	Eq_265 rax_12 = GetModuleHandleW(null);
	if (rax_12 != 0x00)
	{
		struct Eq_622 * rax_17 = fn000000014000173C(rax_12);
		if (rax_17 != null)
		{
			if (rax_17->w005C == 0x02)
			{
				rax_40 = 0x02;
				return (word32) rax_40;
			}
			if (rax_17->w005C == 0x03)
				ebx_36 = 0x01;
		}
	}
	rax_40 = (uint64) ebx_36;
	return (word32) rax_40;
}

// 00000001400017F0: void fn00000001400017F0()
// Called from:
//      fn0000000140001010
void fn00000001400017F0()
{
}

// 0000000140001800: Register (ptr64 Eq_641) fn0000000140001800(Register (ptr64 Eq_642) rcx, Register uint64 rdx)
// Called from:
//      fn0000000140001850
struct Eq_641 * fn0000000140001800(struct Eq_642 * rcx, uint64 rdx)
{
	struct Eq_644 * r8_8 = rcx + (int64) rcx->dw003C /64 64;
	up32 r11d_17 = (word32) (uint64) (word32) r8_8->w0006;
	struct Eq_641 * rax_16 = r8_8 + ((uint64) ((word32) r8_8->w0014) + 0x18) /64 22;
	uint64 r9_39 = 0x00;
	if (r11d_17 != 0x00)
	{
		do
		{
			uint64 rdx_24 = (uint64) rax_16->dw000C;
			word32 r9d_37 = (word32) r9_39;
			word32 edx_31 = (word32) rdx_24;
			if (rdx >= rdx_24 && rdx < (uint64) ((word32) ((uint64) rax_16->dw0008) + edx_31))
				return rax_16;
			r9_39 = (uint64) (r9d_37 + 0x01);
			++rax_16;
		} while ((word32) r9_39 < r11d_17);
	}
	rax_16 = null;
	return rax_16;
}

// 0000000140001850: Register word32 fn0000000140001850(Register Eq_215 rcx)
// Called from:
//      Win32CrtStartup
word32 fn0000000140001850(Eq_215 rcx)
{
	struct Eq_697 * rax_14 = (uint64) fn00000001400018B0(&g_w40000000);
	if ((word32) rax_14 != 0x00)
	{
		rax_14 = fn0000000140001800(&g_w40000000, rcx - 0x140000000);
		if (rax_14 != null)
			rax_14 = (uint64) ((word32) (uint64) ~(word32) (uint64) ((word32) (uint64) rax_14->dw0024 >> 0x1F) & 0x01);
	}
	return (word32) rax_14;
}

// 00000001400018B0: Register word32 fn00000001400018B0(Register (ptr64 Eq_700) rcx)
// Called from:
//      fn0000000140001850
word32 fn00000001400018B0(struct Eq_700 * rcx)
{
	if (rcx->w0000 != 23117)
		return 0x00;
	struct Eq_738 * rdx_11 = rcx + (int64) rcx->dw003C /64 64;
	if (rdx_11->dw0000 != 0x4550)
		return 0x00;
	return (word32) (uint64) (int8) (rdx_11->w0018 == 0x020B);
}

// 00000001400018E4: void fn00000001400018E4(Stack word64 qwArg18)
// Called from:
//      Win32CrtStartup
void fn00000001400018E4(word64 qwArg18)
{
	word32 dwArg18 = (word32) qwArg18;
	ui64 rax_14 = g_qw4000C008;
	if (rax_14 == 0x2B992DDFA232)
	{
		GetSystemTimeAsFileTime(fp + 0x10);
		ui64 rax_44 = (uint64) GetTickCount() ^ (((uint64) GetCurrentProcessId() ^ (uint64) GetCurrentThreadId()) ^ (uint64) GetTickCount() << 0x18) ^ fp + 0x08;
		QueryPerformanceCounter(fp + 0x18);
		ui64 rax_53 = (uint64) dwArg18 << 0x20 ^ qwArg18 ^ rax_44;
		rax_14 = rax_53 & 0xFFFFFFFFFFFF;
		ui64 rcx_55 = rax_53 & 0xFFFFFFFFFFFF;
		if ((rax_53 & 0xFFFFFFFFFFFF) == 0x2B992DDFA232)
		{
			rax_14 = 0x2B992DDFA233;
			rcx_55 = 0x2B992DDFA233;
		}
		g_qw4000C008 = rcx_55;
	}
	g_qw4000C010 = ~rax_14;
}

// 0000000140001A08: Register word128 fn0000000140001A08()
// Called from:
//      fn000000014000721C
word128 fn0000000140001A08()
{
	ui64 rax_22 = g_qw4000C008 ^ fp - 0x02A8;
	memset(fp - 0x0248, 0x00, 0x0104);
	memset(fp - 0x0138, 0x00, 0x0104);
	if (RegCreateKeyExA(~0x7FFFFFFD, 0x14000C088, 0x00, 0x00, 0x00, 131103, null, fp - 600, fp - 0x0250) != 0x00)
	{
l0000000140001CF2:
		fn00000001400013E0(rax_22 ^ fp - 0x02A8);
		return xmm0;
	}
	int32 ebx_102 = 0x00;
	do
	{
		fn000000014000366C(0x14000C7D0, (byte *) 0x50, 0x14000C0C0);
		ui32 dwLoc0280_389 = (word32) (fp - 588);
		if (RegQueryValueExA(qwLoc0258, 0x14000C7D0, 0x00, 0x00, 0x00, fp - 588) != 0x00)
			goto l0000000140001B24;
		ebx_102 = (word32) (uint64) (ebx_102 + 0x01);
	} while (ebx_102 < 200);
	if (ebx_102 == 200)
	{
		RegCloseKey(qwLoc0258);
		g_b4000C7D0 = 0x00;
		goto l0000000140001CF2;
	}
l0000000140001B24:
	GetSystemDirectoryA(fp - 0x0138, 0x0104);
	fn000000014000887C(fp - 0x0138, 0x0104, 0x140009818);
	Eq_265 rax_131 = LoadLibraryA(fp - 0x0138);
	uint32 edi_146 = 0x00;
	if (rax_131 != 0x00)
	{
		int8 dil_142 = (int8) (GetProcAddress(rax_131, 0x140009828) != null);
		FreeLibrary(rax_131);
		edi_146 = (uint32) dil_142;
		if (edi_146 != 0x00)
		{
			if (GetSystemDirectoryA(fp - 0x0248, 0x0104) != 0x00)
				fn000000014000887C(fp - 0x0248, 0x0104, 0x140009770);
l0000000140001BC2:
			Eq_987 rbx_187 = ~0x00;
			struct Eq_989 * rax_191 = (struct Eq_989 *) ~0x00;
			do
				++rax_191;
			while (rax_191[0x4000D610] != 0x00);
			int64 rcx_202 = ~0x00;
			do
				++rcx_202;
			while (fp - 0x0248 + rcx_202 != 0x00);
			word32 eax_214 = (word32) (rax_191 + 80 + rcx_202);
			Eq_225 rax_219 = LocalAlloc(0x40, (uint64) eax_214);
			byte * r14_218 = (uint64) eax_214;
			ui32 eax_286 = (word32) rax_219;
			if (rax_219 == 0x00)
			{
				fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, dwLoc0280_389 & eax_286, out xmm0);
l0000000140001C53:
				RegCloseKey(qwLoc0258);
				goto l0000000140001CF2;
			}
			g_dw4000C820 = (word32) (uint64) ((word32) (uint64) edi_146 ^ 0x01);
			ptr64 r8_239 = 0x14000C058;
			if (edi_146 == 0x00)
				r8_239 = 0x14000C150;
			fn000000014000366C(rax_219, r14_218, r8_239);
			do
			{
				rbx_187 = (word64) rbx_187 + 1;
				word32 ebx_268 = (word32) rbx_187;
			} while (Mem241[rax_219 + rbx_187:byte] != 0x00);
			RegSetValueExA(qwLoc0258, 0x14000C7D0, 0x00, 0x01, rax_219, (word32) (uint64) (ebx_268 + 0x01));
			RegCloseKey(qwLoc0258);
			LocalFree(rax_219);
			goto l0000000140001CF2;
		}
	}
	if (GetModuleFileNameA(g_t4000DE70, fp - 0x0248, 0x0104) == 0x00)
		goto l0000000140001C53;
	goto l0000000140001BC2;
}

// 0000000140001D28: Register word32 fn0000000140001D28(Register Eq_1098 rcx, Register Eq_1099 r8, Register Eq_1100 r9, Register out Eq_1101 xmm0Out)
// Called from:
//      fn000000014000721C
word32 fn0000000140001D28(Eq_1098 rcx, Eq_1099 r8, Eq_1100 r9, union Eq_1101 & xmm0Out)
{
	ui64 rax_29 = g_qw4000C008 ^ fp - 0x06A8;
	Eq_1098 rsi_32 = rcx;
	int64 r10_37 = rcx - (fp - 0x0558);
	Eq_1114 rcx_38 = fp - 0x0558;
	uint64 rdx_50 = 0x0104;
	while (rdx_50 != 0x7FFFFEFA)
	{
		byte al_59 = *((word64) rcx_38 + r10_37);
		if (al_59 == 0x00)
			break;
		*rcx_38 = al_59;
		++rcx_38;
		--rdx_50;
		if (rdx_50 == 0x00)
			break;
	}
	Eq_1114 rax_72 = rcx_38 - 0x01;
	if (rdx_50 != 0x00)
		rax_72 = rcx_38;
	byte * rdx_86;
	Eq_225 rax_87;
	*rax_72 = 0x00;
	if (bLoc0558 == 0x22)
	{
		rdx_86 = &g_b400097A0;
		rax_87 = fp - 0x0557;
	}
	else
	{
		rdx_86 = &g_b400097A4;
		rax_87 = fp - 0x0558;
	}
	Eq_225 rax_99 = fn0000000140002C98(fp - 1656, rdx_86);
	if (rax_87 != 0x00)
	{
		Eq_1175 rax_115 = ~0x00;
		do
			rax_115 = (word64) rax_115 + 1;
		while (Mem96[rax_87 + rax_115:byte] != 0x00);
		if (rax_115 >= 0x03)
		{
			byte al_125 = *((word128) rax_87 + 1);
			if (al_125 == 0x3A && *((word128) rax_87 + 2) == 0x5C || *rax_87 == 0x5C && al_125 == 0x5C)
			{
				Eq_1201 r8_216 = rax_87 - (fp - 0x0668);
				Eq_1205 rcx_218 = fp - 0x0668;
				uint64 rdx_220 = 0x0104;
				while (rdx_220 != 0x7FFFFEFA)
				{
					byte al_229 = Mem228[rcx_218 + r8_216:byte];
					if (al_229 == 0x00)
						break;
					*rcx_218 = al_229;
					++rcx_218;
					--rdx_220;
					if (rdx_220 == 0x00)
						break;
				}
				Eq_1205 rax_242 = rcx_218 - 0x01;
				if (rdx_220 != 0x00)
					rax_242 = rcx_218;
				*rax_242 = 0x00;
				goto l0000000140001EA6;
			}
		}
	}
	uint64 rdx_147 = 0x0104;
	Eq_1167 r8_152 = 0x14000D610 - (fp - 0x0668);
	Eq_1172 rcx_154 = fp - 0x0668;
	while (rdx_147 != 0x7FFFFEFA)
	{
		byte al_163 = Mem162[rcx_154 + r8_152:byte];
		if (al_163 == 0x00)
			break;
		*rcx_154 = al_163;
		++rcx_154;
		--rdx_147;
		if (rdx_147 == 0x00)
			break;
	}
	Eq_1172 rax_176 = rcx_154 - 0x01;
	if (rdx_147 != 0x00)
		rax_176 = rcx_154;
	*rax_176 = 0x00;
	fn000000014000887C(fp - 0x0668, 0x0104, rax_87);
l0000000140001EA6:
	Eq_225 rbx_335;
	Eq_405 rdx_600;
	Eq_225 r8_598;
	Eq_1270 rax_260 = fn0000000140008A2C(rax_87, 0x2E);
	if (rax_260 != 0x00 && CompareStringA(0x7F, 0x01, rax_260, 0xFFFFFFFF, 0x1400097A8, ~0x00) == 0x02)
	{
		Eq_126 eax_585 = GetFileAttributesA(fp - 0x0668);
		byte al_588 = (byte) eax_585;
		if (eax_585 == ~0x00 || (al_588 & 0x10) != 0x00)
		{
			r8_598 = fp - 0x0668;
			rdx_600.u0 = 0x0525;
			goto l00000001400020E7;
		}
		Eq_225 qwLoc0678_1021 = rax_99;
		Eq_225 rax_605 = fn0000000140002C98(fp - 1656, &g_b400097B0);
		if (rax_605 != 0x00)
		{
			Eq_225 rax_617 = rax_99;
			if (*rax_605 != 0x00)
				rax_617 = rax_605;
			fn0000000140002C98(fp - 1656, &g_b400097B4);
			qwLoc0678_1021 = rax_617;
		}
		Eq_225 rax_639 = LocalAlloc(0x40, 0x0200);
		uint64 r14_633 = 0x0200;
		rbx_335 = rax_639;
		if (rax_639 != 0x00)
		{
			Eq_225 rdi_716 = 5368758568;
			Eq_225 rcx_717 = 5368758568;
			if (*qwLoc0678_1021 != 0x00)
				rcx_717 = qwLoc0678_1021;
			Eq_405 eax_728 = GetPrivateProfileIntA(rcx_717, 0x1400097B8, 0x00, fp - 0x0668);
			*r9 = 0x01;
			g_t4000D540 = eax_728;
			word64 r15_831 = 0x0104;
			if (GetPrivateProfileStringA(0x1400097D0, 0x1400097C0, 0x140009770, rax_639, 0x08, fp - 0x0668) != 0x00)
			{
				g_t4000DE64 |= 0x04;
				if (*qwLoc0678_1021 != 0x00)
					rdi_716 = qwLoc0678_1021;
				ptr64 rdi_829 = rdi_716 - rcx;
				while (r15_831 != 0x7FFFFEFA)
				{
					byte al_839 = *((word64) rsi_32 + rdi_829);
					if (al_839 == 0x00)
						break;
					*rsi_32 = al_839;
					rsi_32 = (word64) rsi_32 + 1;
					--r15_831;
					if (r15_831 == 0x00)
						break;
				}
				Eq_1098 rax_852 = rsi_32 - 0x01;
				Eq_225 rcx_860 = rax_639;
				if (r15_831 != 0x00)
					rax_852 = rsi_32;
				*rax_852 = 0x00;
				Eq_1511 rdx_865 = fp - 0x0668 - rax_639;
				while (r14_633 != 0x7FFFFDFE)
				{
					byte al_881 = Mem880[rdx_865 + rcx_860:byte];
					if (al_881 == 0x00)
						break;
					*rcx_860 = al_881;
					++rcx_860;
					--r14_633;
					if (r14_633 == 0x00)
						break;
				}
				Eq_225 rax_894 = rcx_860 - 0x01;
				if (r14_633 != 0x00)
					rax_894 = rcx_860;
				*rax_894 = 0x00;
			}
			else
			{
				g_t4000DE64 &= ~0x04;
				if (g_w4000DE78 == 0x00)
					GetShortPathNameA(fp - 0x0668, fp - 0x0668, 0x0104);
				*qwLoc0678_1021 == 0x00;
				fn000000014000366C(rax_639, (byte *) 0x0200, 0x14000C0D8);
			}
			goto l00000001400022B1;
		}
	}
	else
	{
		Eq_1270 rax_303 = fn0000000140008A2C(rax_87, 0x2E);
		Eq_1283 rbx_545 = ~0x00;
		if (rax_303 != 0x00 && CompareStringA(0x7F, 0x01, rax_303, 0xFFFFFFFF, 0x1400097F8, ~0x00) == 0x02)
		{
			int64 rax_546 = ~0x00;
			do
				++rax_546;
			while (0x14000C138 + rax_546 != 0x00);
			do
				rbx_545 = (word64) rbx_545 + 1;
			while (Mem318[fp - 0x0668 + rbx_545:byte] != 0x00);
			int64 rdi_564 = (word64) rbx_545 + rax_546;
			Eq_225 rax_568 = LocalAlloc(0x40, rdi_564 + 0x08);
			rbx_335 = rax_568;
			if (rax_568 != 0x00)
			{
				fn000000014000366C(rax_568, rdi_564 + 0x08, 0x14000C138);
				goto l00000001400022B1;
			}
		}
		else
		{
			Eq_225 rax_334 = LocalAlloc(0x40, 0x0400);
			uint64 rdi_328 = 0x0400;
			rbx_335 = rax_334;
			if (rax_334 != 0x00)
			{
				Eq_126 eax_341 = GetFileAttributesA(fp - 0x0668);
				byte al_344 = (byte) eax_341;
				if (eax_341 != ~0x00 && (al_344 & 0x10) == 0x00)
				{
					uint64 rdx_420 = 0x0400;
					Eq_1585 r8_422 = fp - 0x0668 - (fp - 0x0448);
					Eq_1591 rcx_424 = fp - 0x0448;
					while (rdx_420 != 0x7FFFFBFE)
					{
						byte al_433 = Mem432[r8_422 + rcx_424:byte];
						if (al_433 == 0x00)
							break;
						*rcx_424 = al_433;
						++rcx_424;
						--rdx_420;
						if (rdx_420 == 0x00)
							break;
					}
					Eq_1591 rax_446 = rcx_424 - 0x01;
					if (rdx_420 != 0x00)
						rax_446 = rcx_424;
					*rax_446 = 0x00;
					if (rax_99 != 0x00 && *rax_99 != 0x00)
					{
						fn00000001400035A8(fp - 0x0448, 0x0400, 0x1400097A4);
						fn00000001400035A8(fp - 0x0448, 0x0400, rax_99);
					}
				}
				else
				{
					int64 rsi_382 = rcx - (fp - 0x0448);
					Eq_1576 rdx_384 = fp - 0x0448;
					while (rdi_328 != 0x7FFFFBFE)
					{
						byte al_393 = *((word64) rdx_384 + rsi_382);
						if (al_393 == 0x00)
							break;
						*rdx_384 = al_393;
						++rdx_384;
						--rdi_328;
						if (rdi_328 == 0x00)
							break;
					}
					Eq_1576 rcx_406 = rdx_384 - 0x01;
					if (rdi_328 != 0x00)
						rcx_406 = rdx_384;
					*rcx_406 = 0x00;
				}
				fn0000000140002A10(fp - 0x0448, rax_334);
l00000001400022B1:
				*r8 = rbx_335;
l00000001400022BE:
				word64 rax_951 = fn00000001400013E0(rax_29 ^ fp - (struct Eq_11391 *) 0x06A8);
				xmm0Out = xmm0;
				return (word32) rax_951;
			}
		}
	}
	rdx_600.u0 = 0x04B5;
	r8_598.u0 = 0x00;
l00000001400020E7:
	fn00000001400061E8(null, rdx_600, r8_598, null, 0x10, 0x00, out xmm0);
	goto l00000001400022BE;
}

// 00000001400022F0: Register word32 fn00000001400022F0(Register Eq_225 rcx, Register Eq_225 rdx, Register (ptr64 int32) r9, Stack word32 dwArg08, Stack word32 dwArg20)
// Called from:
//      fn0000000140003DF0
word32 fn00000001400022F0(Eq_225 rcx, Eq_225 rdx, int32 * r9, word32 dwArg08, word32 dwArg20)
{
	word32 esi_323;
	word32 r15d_376 = 0x00;
	Eq_225 rdi_104 = 0x00;
	int32 ebx_110 = 0x00;
	if (*((word128) rcx + 0x007C) > 0x00)
	{
		uint64 rax_272 = 0x00;
		word64 qwLoc58_396 = 0x3C;
		do
		{
			struct Eq_1711 * rsi_57 = (uint64) *((word128) rcx + 0x0080) + rax_272;
			if (SLICE(CONVERT(fn0000000140002D34(rdx, rcx + 0x84 + CONVERT(Mem52[(rsi_57 + 188) + rcx:word32], word32, uint64)), uint32, uint64), word32, 0) == 0x00)
			{
l000000014000250B:
				esi_323 = 0x00;
				goto l000000014000250E;
			}
			Eq_126 eax_82 = GetFileVersionInfoSizeA(rdx, (word64) fp + 8);
			word32 r14d_98 = (word32) (uint64) eax_82;
			if (eax_82 != 0x00)
			{
				Eq_225 rax_103 = GlobalAlloc(66, (uint64) r14d_98);
				rdi_104 = rax_103;
				if (rax_103 == 0x00)
				{
					*r9 = ebx_110;
					esi_323 = 0x00;
					return (word32) (uint64) esi_323;
				}
				Eq_225 rax_114 = GlobalLock(rax_103);
				if (rax_114 == 0x00)
				{
					*r9 = ebx_110;
					esi_323 = 0x00;
					goto l0000000140002517;
				}
				if (GetFileVersionInfoA(rdx, (uint64) dwArg08, (uint64) r14d_98, rax_114) != 0x00 && (VerQueryValueA(rax_114, 0x14000988C, fp - 0x50, (word64) fp + 32) != 0x00 && dwArg20 != 0x00))
				{
					struct Eq_1774 * rcx_153 = rsi_57 + ((word128) rcx + 144) /128 0x0084;
					Eq_1778 rdx_156 = 0x00;
					up32 r9d_381 = (word32) (uint64) qwLoc50->dw000C;
					up32 r8d_378 = (word32) (uint64) qwLoc50->dw0008;
					do
					{
						Eq_1797 eax_181;
						if (r8d_378 < rcx_153->dwFFFFFFF4)
						{
l000000014000242F:
							eax_181 = (Eq_1797) ~0x00;
							goto l0000000140002449;
						}
						if (r8d_378 > rcx_153->dwFFFFFFF4)
						{
							eax_181 = (Eq_1797) 0x01;
							goto l0000000140002449;
						}
						if (r9d_381 < rcx_153->dwFFFFFFF8)
							goto l000000014000242F;
						eax_181 = (Eq_1797) (uint32) (int8) (r9d_381 > rcx_153->dwFFFFFFF8);
l0000000140002449:
						uint32 eax_217;
						Mem194[fp - 0x68 + rdx_156:word32] = eax_181;
						if (r8d_378 < rcx_153->dw0000)
						{
l0000000140002452:
							eax_217 = ~0x00;
							goto l000000014000246C;
						}
						if (r8d_378 > rcx_153->dw0000)
						{
							eax_217 = 0x01;
							goto l000000014000246C;
						}
						if (r9d_381 < rcx_153->dw0004)
							goto l0000000140002452;
						eax_217 = (uint32) (int8) (r9d_381 > rcx_153->dw0004);
l000000014000246C:
						Mem228[fp - 0x60 + rdx_156:word32] = eax_217;
						++rcx_153;
						rdx_156 = (word64) rdx_156 + 4;
					} while (rdx_156 < 0x08);
					if ((dwLoc68 < 0x00 || dwLoc60 > 0x00) && (dwLoc64 < 0x00 || dwLoc5C > 0x00))
					{
						GlobalUnlock(rax_103);
						*r9 = ebx_110;
						esi_323 = 0x00;
						goto l0000000140002517;
					}
				}
				GlobalUnlock(rax_103);
				r15d_376 = 0x00;
				goto l00000001400024DA;
			}
			if (Mem52[rsi_57 + 0x84 + rcx:word32] != r15d_376 || Mem52[(rsi_57 + 0x88) + rcx:word32] != r15d_376)
				goto l000000014000250B;
l00000001400024DA:
			ebx_110 = (word32) (uint64) (ebx_110 + 0x01);
			rax_272 = qwLoc58_396 + 0x00;
			qwLoc58_396 += 0x3C;
		} while (ebx_110 < *((word128) rcx + 0x007C));
	}
	esi_323 = 0x01;
l000000014000250E:
	*r9 = ebx_110;
	if (rdi_104 != 0x00)
	{
l0000000140002517:
		GlobalFree(rdi_104);
	}
	return (word32) (uint64) esi_323;
}

// 0000000140002540: Register word32 fn0000000140002540()
// Called from:
//      fn0000000140007010
//      fn0000000140007FE4
word32 fn0000000140002540()
{
	uint64 rax_15;
	if (g_t4000D540 == 0x00)
		rax_15 = (uint64) ((word32) (uint64) ((word32) (uint64) (0x00 - ((word32) ((uint64) (-((uint32) ((int8) ((word32) ((uint64) g_dw4000DE7C) != (word32) ((uint64) fn00000001400034D8((uint64) ((word32) g_w4000DE78), qwLoc20))))))) == 0x00)) & 0x03) - 0x01);
	else
		rax_15 = 0x02;
	return (word32) rax_15;
}

// 0000000140002590: Register word64 fn0000000140002590(Register (ptr64 word32) rcx)
// Called from:
//      fn0000000140003118
word64 fn0000000140002590(word32 * rcx)
{
	ui64 rax_18 = g_qw4000C008 ^ fp - 0x98;
	Eq_265 rax_30 = LoadLibraryA(0x140009778);
	if (rax_30 != 0x00)
	{
		word56 rdx_56_8_59 = SLICE(0x140009788, word56, 8);
		if (GetProcAddress(rax_30, 0x140009788) != null)
		{
			*rcx = 0x00;
			if (AllocateAndInitializeSid(fp - 0x30, SEQ(rdx_56_8_59, 0x02), 0x20, 0x0220, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, fp - 0x38) != 0x00)
			{
				fn0000000140008E50();
				FreeSid(qwLoc38);
			}
		}
		FreeLibrary(rax_30);
	}
	return fn00000001400013E0(rax_18 ^ fp - 0x98);
}

// 00000001400026B8: void fn00000001400026B8(Register Eq_225 rcx)
// Called from:
//      fn00000001400026B8
//      fn00000001400043CC
//      fn0000000140005810
void fn00000001400026B8(Eq_225 rcx)
{
	if (rcx != 0x00)
	{
		ui64 rax_23 = g_qw4000C008 ^ fp - 664;
		if (*rcx != 0x00)
		{
			byte * rcx_32 = fp - 0x0138;
			uint64 rdx_35 = 0x0104;
			int64 rdi_36 = rcx - (fp - 0x0138);
			while (rdx_35 != 0x7FFFFEFA)
			{
				byte al_46 = rcx_32[rdi_36];
				if (al_46 == 0x00)
					break;
				*rcx_32 = al_46;
				++rcx_32;
				--rdx_35;
				if (rdx_35 == 0x00)
					break;
			}
			byte * rax_59 = rcx_32 - 0x01;
			if (rdx_35 != 0x00)
				rax_59 = rcx_32;
			*rax_59 = 0x00;
			fn00000001400035A8(fp - 0x0138, 0x0104, 0x140009838);
			Eq_384 rax_90 = FindFirstFileA(fp - 0x0138, fp - 0x0278);
			if (rax_90 != (void *) ~0x00)
			{
				do
				{
					uint64 r8_112 = 0x0104;
					byte * rdx_104 = fp - 0x0138;
					while (r8_112 != 0x7FFFFEFA)
					{
						byte al_106 = rdx_104[rdi_36];
						if (al_106 == 0x00)
							break;
						*rdx_104 = al_106;
						++rdx_104;
						--r8_112;
						if (r8_112 == 0x00)
							break;
					}
					byte * rax_119 = rdx_104 - 0x01;
					if (r8_112 != 0x00)
						rax_119 = rdx_104;
					*rax_119 = 0x00;
					if ((bLoc0278 & 0x10) != 0x00)
					{
						if (lstrcmpA(fp - 588, 0x14000983C) != 0x00 && lstrcmpA(fp - 588, 0x140009840) != 0x00)
						{
							fn00000001400035A8(fp - 0x0138, 0x0104, fp - 588);
							fn000000014000887C(fp - 0x0138, 0x0104, 0x140009770);
							fn00000001400026B8(fp - 0x0138);
						}
					}
					else
					{
						fn00000001400035A8(fp - 0x0138, 0x0104, fp - 588);
						SetFileAttributesA(fp - 0x0138, 0x80);
						DeleteFileA(fp - 0x0138);
					}
				} while (FindNextFileA(rax_90, fp - 0x0278) != 0x00);
				FindClose(rax_90);
				RemoveDirectoryA(rcx);
			}
		}
		fn00000001400013E0(rax_23 ^ fp - 664);
	}
}

// 00000001400028B8: Register word128 fn00000001400028B8(Register Eq_2209 ecx, Register Eq_1052 r9)
// Called from:
//      fn0000000140005B50
word128 fn00000001400028B8(Eq_2209 ecx, Eq_1052 r9)
{
	Eq_2209 ecx = (word32) rcx;
	ui64 rax_10 = g_qw4000C008 ^ fp - 88;
	g_dw4000D544 = 0x70;
	if (ecx == 0x01)
	{
		fn000000014000366C(fp - 0x28, (byte *) 0x0A, 0x140009854);
		fn00000001400061E8(null, 0x04FA, fp - 0x28, null, 0x10, 0x00, out xmm0);
	}
	else if (ecx == 0x04)
	{
		fn000000014000366C(fp - 0x28, (uint64) (word32) (rcx + 0x06), 0x140009854);
		fn00000001400061E8(null, 1213, fp - 0x28, null, 0x20, 0x05, out xmm0);
	}
	else if (ecx == 0x02)
	{
		fn000000014000366C(fp - 0x28, (uint64) (word32) (rcx + 0x08), 0x140009854);
		if ((word32) (uint64) fn00000001400061E8(null, 0x04CC, fp - 0x28, r9, 0x40, 0x0104, out xmm0) == 0x06)
			g_dw4000D544 = 0x00;
	}
	fn00000001400013E0(rax_10 ^ fp - 88);
	return xmm0;
}

// 00000001400029DC: void fn00000001400029DC()
// Called from:
//      fn0000000140006768
void fn00000001400029DC()
{
	word128 xmm0_39;
	fn00000001400061E8(null, 1313, 0x140009770, null, 0x40, 0x00, out xmm0_39);
}

// 0000000140002A10: void fn0000000140002A10(Register Eq_225 rcx, Register Eq_225 rdx)
// Called from:
//      fn0000000140001D28
void fn0000000140002A10(Eq_225 rcx, Eq_225 rdx)
{
	ui64 rax_16 = g_qw4000C008 ^ fp - 344;
	*rdx = 0x00;
	Eq_225 rdi_22 = rcx;
	Eq_225 rbx_23 = rdx;
	if (rcx != 0x00 && *rcx != 0x00)
	{
		Eq_265 rcx_29 = g_t4000DE70;
		GetModuleFileNameA(rcx_29, fp - 0x0138, 0x0104);
		word56 rcx_56_8_343 = SLICE(rcx_29, word56, 8);
		byte al_34 = *rcx;
		if (al_34 != 0x00)
		{
			Eq_1995 rcx_56_8_al_528 = SEQ(rcx_56_8_343, al_34);
			do
			{
				Eq_407 eax_45 = IsDBCSLeadByte(rcx_56_8_al_528);
				*rbx_23 = *rdi_22;
				if (eax_45 != 0x00)
					*((word128) rbx_23 + 1) = *((word128) rdi_22 + 1);
				if (*rdi_22 == 0x23)
				{
					Eq_2364 rax_152;
					Eq_225 rax_61 = CharNextA(rdi_22);
					rdi_22 = rax_61;
					if ((byte) CharUpperA((int64) *rax_61) == 0x44)
					{
						fn0000000140008914(fp - 0x0138);
						int64 rax_168 = ~0x00;
						do
							++rax_168;
						while (fp - 0x0138 + rax_168 != 0x00);
						Eq_225 rax_179 = CharPrevA(fp - 0x0138, fp - 0x0138 + rax_168);
						if (rax_179 != 0x00 && *rax_179 == 0x5C)
							*rax_179 = 0x00;
						Eq_2417 rax_197;
						if (rbx_23 >= rdx && rbx_23 - rdx <= 0x0400)
						{
							Eq_2432 rcx_202 = rdx - rbx_23;
							word64 rcx_203 = rcx_202 + 0x0400;
							rax_197 = rcx_202 + 0x0400;
							if (rcx_202 == 0x0400 || rcx_202 > 0x7FFFFBFF)
								goto l0000000140002B7C;
							word64 r8_220 = 0x7FFFFFFE - (rcx_202 + 0x0400);
							Eq_225 rdx_221 = rbx_23;
							int64 r9_222 = fp - 0x0138 - rbx_23;
							while ((word64) rcx_203 + r8_220 != 0x00)
							{
								byte al_233 = *((word128) rdx_221 + r9_222);
								if (al_233 == 0x00)
									break;
								*rdx_221 = al_233;
								++rdx_221;
								--rcx_203;
								if (rcx_203 == 0x00)
									break;
							}
							Eq_225 rax_246 = rdx_221 - 0x01;
							if (rcx_203 != 0x00)
								rax_246 = rdx_221;
							*rax_246 = 0x00;
						}
						else
						{
							&rax_197.u0->b0000 = 0x00;
l0000000140002B7C:
							if (rax_197 != 0x00)
								*rbx_23 = 0x00;
						}
						&rax_152.u0->b0000 = ~0x00;
						do
							&rax_152.u0->b0000 = rax_152.u0 + 1;
						while (Mem379[rbx_23 + rax_152:byte] != 0x00);
						goto l0000000140002C31;
					}
					if ((byte) CharUpperA((int64) *rax_61) == 0x45)
					{
						Eq_2484 rax_101;
						if (rbx_23 >= rdx && rbx_23 - rdx <= 0x0400)
						{
							Eq_2490 rcx_94 = rdx - rbx_23;
							word64 rcx_118 = rcx_94 + 0x0400;
							rax_101 = rcx_94 + 0x0400;
							if (rcx_94 == 0x0400 || rcx_94 > 0x7FFFFBFF)
								goto l0000000140002C1D;
							word64 r8_113 = 0x7FFFFFFE - (rcx_94 + 0x0400);
							Eq_225 rdx_114 = rbx_23;
							int64 r9_115 = fp - 0x0138 - rbx_23;
							while ((word64) rcx_118 + r8_113 != 0x00)
							{
								byte al_126 = *((word128) rdx_114 + r9_115);
								if (al_126 == 0x00)
									break;
								*rdx_114 = al_126;
								++rdx_114;
								--rcx_118;
								if (rcx_118 == 0x00)
									break;
							}
							Eq_225 rax_139 = rdx_114 - 0x01;
							if (rcx_118 != 0x00)
								rax_139 = rdx_114;
							*rax_139 = 0x00;
						}
						else
						{
							&rax_101.u0->b0000 = 0x00;
l0000000140002C1D:
							if (rax_101 != 0x00)
								*rbx_23 = 0x00;
						}
						&rax_152.u0->b0000 = ~0x00;
						do
							++rax_152;
						while (Mem371[rbx_23 + rax_152:byte] != 0x00);
l0000000140002C31:
						rbx_23 += rax_152;
						goto l0000000140002C4D;
					}
					if (*rax_61 == 0x23)
						goto l0000000140002C3B;
				}
				else
				{
l0000000140002C3B:
					rbx_23 = CharNextA(rbx_23);
				}
l0000000140002C4D:
				Eq_225 rax_290 = CharNextA(rdi_22);
				Eq_2351 al_295 = *rax_290;
				rdi_22 = rax_290;
				rcx_56_8_al_528 = SEQ(SLICE(rdi_22, word56, 8), al_295);
			} while (al_295 != 0x00);
		}
		*rbx_23 = 0x00;
	}
	fn00000001400013E0(rax_16 ^ fp - 344);
}

// 0000000140002C98: Register (ptr64 byte) fn0000000140002C98(Register Eq_1158 rcx, Register (ptr64 byte) rdx)
// Called from:
//      fn0000000140001D28
byte * fn0000000140002C98(Eq_1158 rcx, byte * rdx)
{
	byte * rbx_14 = *rcx;
	while (true)
	{
		byte * rax_138;
		uip32 ebp_70 = 0x00;
		if (fn00000001400089BC(rdx, (word16) (int32) *rbx_14) == 0x00)
			break;
		if (*rbx_14 == 0x00)
		{
			rax_138 = null;
			return rax_138;
		}
		++rbx_14;
	}
	word16 dx_52 = (word16) (int32) *rbx_14;
	*rcx = rbx_14;
	if (fn00000001400089BC(rdx, dx_52) == 0x00)
	{
		byte * rdi_62 = rbx_14;
		while (*rdi_62 != 0x00)
		{
			++rdi_62;
			ebp_70 = (word32) (uint64) (ebp_70 + 0x01);
			if (fn00000001400089BC(rdx, (word16) (int32) *rdi_62) != 0x00)
				break;
		}
	}
	rax_138 = rbx_14 + (int64) ebp_70;
	if (*rax_138 != 0x00)
	{
		*rax_138 = 0x00;
		++rax_138;
	}
	return rax_138;
}

// 0000000140002D34: Register word32 fn0000000140002D34(Register Eq_225 rcx, Register Eq_225 r8)
// Called from:
//      fn00000001400022F0
word32 fn0000000140002D34(Eq_225 rcx, Eq_225 r8)
{
	ui64 rax_23 = g_qw4000C008 ^ fp - 0x0188;
	*rcx = 0x00;
	uip32 edi_174 = 0x00;
	Eq_225 rsi_243 = r8;
	if (*r8 != 0x23)
	{
		GetSystemDirectoryA(rcx, 0x0104);
		goto l0000000140002F4E;
	}
	byte r14b_49 = (byte) CharUpperA((int64) *((word128) r8 + 1));
	Eq_225 rax_47 = CharNextA(CharNextA((word128) r8 + 1));
	rsi_243 = rax_47;
	if (r14b_49 != 0x41)
	{
		if (r14b_49 == 0x53)
		{
			GetSystemDirectoryA(rcx, 0x0104);
			goto l0000000140002F37;
		}
		if (r14b_49 == 0x57)
		{
			GetWindowsDirectoryA(rcx, 0x0104);
			goto l0000000140002F37;
		}
	}
	uint64 rdx_65 = 0x0104;
	int64 r8_66 = 0x140009858 - (fp - 0x0148);
	Eq_2705 rcx_68 = fp - 0x0148;
	while (rdx_65 != 0x7FFFFEFA)
	{
		byte al_77 = *((word64) rcx_68 + r8_66);
		if (al_77 == 0x00)
			break;
		*rcx_68 = al_77;
		++rcx_68;
		--rdx_65;
		if (rdx_65 == 0x00)
			break;
	}
	Eq_2705 rax_108 = rcx_68 - 0x01;
	if (rdx_65 != 0x00)
		rax_108 = rcx_68;
	*rax_108 = 0x00;
	fn000000014000887C(fp - 0x0148, 0x0104, rax_47);
	edi_174 = 0x00;
	if (RegOpenKeyExA(~0x7FFFFFFD, fp - 0x0148, 0x00, 0x00020019, fp - 336) != 0x00)
	{
l0000000140002F37:
		if (edi_174 != 0x00)
			return (word32) fn00000001400013E0(rax_23 ^ fp - (CHAR *) 0x0188);
l0000000140002F4E:
		fn000000014000887C(rcx, 0x0104, rsi_243);
		return (word32) fn00000001400013E0(rax_23 ^ fp - (CHAR *) 0x0188);
	}
	if (RegQueryValueExA(qwLoc0150, 0x140009770, 0x00, fp - 344, rcx, fp - 0x0154) != 0x00)
	{
l0000000140002F26:
		RegCloseKey(qwLoc0150);
		goto l0000000140002F37;
	}
	else
	{
		word32 eax_153 = (word32) (uint64) dwLoc0158;
		if (eax_153 == 0x02)
		{
			if (ExpandEnvironmentStringsA(rcx, fp - 0x0148, 0x0104) != 0x00)
			{
				uint64 rdx_177 = 0x0104;
				Eq_2815 r8_178 = fp - 0x0148 - rcx;
				Eq_225 rcx_180 = rcx;
				while (rdx_177 != 0x7FFFFEFA)
				{
					byte al_189 = Mem188[r8_178 + rcx_180:byte];
					if (al_189 == 0x00)
						break;
					*rcx_180 = al_189;
					++rcx_180;
					--rdx_177;
					if (rdx_177 == 0x00)
						break;
				}
				Eq_225 rax_203 = rcx_180 - 0x01;
				if (rdx_177 != 0x00)
					rax_203 = rcx_180;
				*rax_203 = 0x00;
				edi_174 = 0x01;
				goto l0000000140002F26;
			}
			eax_153 = (word32) (uint64) dwLoc0158;
		}
		if (eax_153 == 0x01)
			edi_174 = 0x01;
		goto l0000000140002F26;
	}
}

// 0000000140002F8C: Register word32 fn0000000140002F8C(Stack Eq_225 qwArg10)
// Called from:
//      fn00000001400034D8
word32 fn0000000140002F8C(Eq_225 qwArg10)
{
	if (RegOpenKeyExA(~0x7FFFFFFD, 0x14000C160, 0x00, 0x00020019, fp + 0x10) == 0x00)
	{
		RegQueryInfoKeyA(qwArg10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, fp + 0x08, 0x00, 0x00, 0x00, null) == 0x00;
		RegCloseKey(qwArg10);
	}
	return 0x00;
}

// 0000000140003044: Register word32 fn0000000140003044()
// Called from:
//      fn00000001400034D8
word32 fn0000000140003044()
{
	ui64 rax_10 = g_qw4000C008 ^ fp - 0x0148;
	if (GetWindowsDirectoryA(fp - 0x0128, 0x0104) != 0x00)
	{
		fn000000014000887C(fp - 0x0128, 0x0104, 0x140009848);
		WritePrivateProfileStringA(0x00, 0x00, 0x00, fp - 0x0128);
		Eq_2930 eax_50 = _lopen(fp - 0x0128, 0x40);
		word32 edi_65 = (word32) (uint64) eax_50;
		if (eax_50 != ~0x00)
		{
			_llseek((uint64) eax_50, 0x00, 0x02);
			_lclose((uint64) edi_65);
		}
	}
	return (word32) fn00000001400013E0(rax_10 ^ fp - 0x0148);
}

// 0000000140003118: Register word32 fn0000000140003118()
// Called from:
//      fn0000000140005810
word32 fn0000000140003118()
{
	ui64 rax_18 = g_qw4000C008 ^ fp - 0x98;
	if ((word32) (uint64) g_dw4000C14C == 0x02)
	{
		word64 rax_37 = fn0000000140002590(fp - 0x38);
		word32 rax_32_32_66 = SLICE(rax_37, word32, 32);
		if ((word32) rax_37 == 0x00)
		{
			if (OpenProcessToken(SEQ(rax_32_32_66, GetCurrentProcess()), 0x08, fp - 0x30) != 0x00)
			{
				if (GetTokenInformation(qwLoc30, 0x02, 0x00, 0x00, fp - 0x34) == 0x00 && GetLastError() == 122)
				{
					Eq_225 rax_96 = LocalAlloc(0x00, (uint64) dwLoc34);
					if (rax_96 != 0x00)
					{
						if (GetTokenInformation(qwLoc30, 0x02, rax_96, (uint64) dwLoc34, fp - 0x34) != 0x00 && AllocateAndInitializeSid(fp - 0x20, 0x02, 0x20, 0x0220, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, fp - 0x28) != 0x00)
						{
							up32 esi_143 = 0x00;
							if (*rax_96 > 0x00)
							{
								do
								{
									if (EqualSid(*((word128) rax_96 + ((uint64) esi_143 * 0x10 + 8)), qwLoc28) != 0x00)
									{
										g_dw4000C14C = 0x01;
										break;
									}
									esi_143 = (word32) (uint64) (esi_143 + 0x01);
								} while (esi_143 < *rax_96);
							}
							FreeSid(qwLoc28);
						}
						LocalFree(rax_96);
					}
				}
				CloseHandle(qwLoc30);
			}
		}
		else
		{
			word32 ecx_61 = (word32) (uint64) g_dw4000C14C;
			if (false)
				ecx_61 = 0x01;
			g_dw4000C14C = ecx_61;
		}
	}
	return (word32) fn00000001400013E0(rax_18 ^ fp - 0x98);
}

// 000000014000332C: Register word32 fn000000014000332C()
// Called from:
//      fn000000014000521C
word32 fn000000014000332C()
{
	ui64 rax_10 = g_qw4000C008 ^ fp - 344;
	if (GetWindowsDirectoryA(fp - 0x0128, 0x0104) == 0x00)
	{
		word128 xmm0_100;
		fn00000001400061E8(null, 0x04F0, 0x00, null, 0x10, 0x00, out xmm0_100);
	}
	return (word32) fn00000001400013E0(rax_10 ^ fp - 344);
}

// 00000001400033BC: void fn00000001400033BC()
// Called from:
//      fn0000000140007FE4
void fn00000001400033BC()
{
	Eq_1054 dwLoc30_138;
	Eq_405 rdx_60;
	ui64 rax_8 = g_qw4000C008 ^ fp - 88;
	Eq_407 eax_17 = OpenProcessToken(SEQ(SLICE(rax_8, word32, 32), GetCurrentProcess()), 0x28, fp - 0x28);
	if (eax_17 == 0x00)
	{
		dwLoc30_138 = dwLoc30 & eax_17;
		rdx_60.u0 = 0x04F5;
	}
	else
	{
		LookupPrivilegeValueA(0x00, 0x140009800, fp - 0x1C);
		word32 ebx_45 = (word32) (uint64) AdjustTokenPrivileges(qwLoc28, 0x00, fp - 0x20, 0x00, null, null);
		CloseHandle(qwLoc28);
		if (ebx_45 == 0x00)
			rdx_60.u0 = 0x04F6;
		else
		{
			if (ExitWindowsEx(0x02, 0x00) != 0x00)
				goto l00000001400034BD;
			rdx_60.u0 = 1271;
		}
		dwLoc30_138.u0 = 0x00;
	}
	word128 xmm0_160;
	fn00000001400061E8(null, rdx_60, 0x00, null, 0x10, dwLoc30_138, out xmm0_160);
l00000001400034BD:
	fn00000001400013E0(rax_8 ^ fp - 88);
}

// 00000001400034D8: Register word32 fn00000001400034D8(Register Eq_1930 cx, Stack Eq_225 qwArg10)
// Called from:
//      fn0000000140002540
//      fn00000001400046E8
word32 fn00000001400034D8(Eq_1930 cx, Eq_225 qwArg10)
{
	Eq_1930 cx = (word16) rcx;
	word32 eax_41;
	word32 ebx_100 = 0x00;
	word32 edx_12 = (word32) (uint64) (word32) cx;
	if (edx_12 != 0x00)
	{
		word32 edx_29 = (word32) (uint64) (edx_12 - 0x01);
		if (edx_29 != 0x00)
		{
			word32 edx_48 = (word32) (uint64) (edx_29 - 0x01);
			if (edx_48 == 0x00 || edx_48 == 0x01)
			{
				if (RegOpenKeyExA(~0x7FFFFFFD, 0x14000C020, 0x00, 0x00020019, fp + 0x10) == 0x00)
				{
					RegQueryValueExA(qwArg10, 0x14000C108, 0x00, 0x00, 0x00, fp + 0x08) == 0x00;
					RegCloseKey(qwArg10);
				}
				ebx_100 = 0x00;
			}
			return (word32) (uint64) ebx_100;
		}
		eax_41 = (word32) (uint64) fn0000000140002F8C(qwLoc30);
	}
	else
		eax_41 = (word32) (uint64) fn0000000140003044();
	ebx_100 = (word32) (uint64) eax_41;
	return (word32) (uint64) ebx_100;
}

// 00000001400035A8: Register word32 fn00000001400035A8(Register Eq_225 rcx, Register uint64 rdx, Register Eq_225 r8)
// Called from:
//      fn0000000140001D28
//      fn00000001400026B8
//      fn0000000140003BA8
//      fn000000014000887C
word32 fn00000001400035A8(Eq_225 rcx, uint64 rdx, Eq_225 r8)
{
	uint64 rdx_100;
	if (rdx <= 0x7FFFFFFF)
	{
		uint64 r10_16 = rdx;
		Eq_225 rax_17 = rcx;
		while (*rax_17 != 0x00)
		{
			rax_17 = (word128) rax_17 + 1;
			--r10_16;
			if (r10_16 == 0x00)
				break;
		}
		rdx_100 = (uint64) ((word32) (uint64) ~(word32) (uint64) (0x00 - (r10_16 == 0x00)) & 0x80070057);
		uint64 r8_47 = 0x00 - (r10_16 == 0x00) & rdx - r10_16;
		if (r10_16 != 0x00)
		{
			byte * rdx_54 = (word128) rcx + r8_47;
			uint64 rcx_55 = rdx - r8_47;
			if (rcx_55 != 0x00)
			{
				uint64 rax_60 = rcx_55 + 0x7FFFFFFE + (r8_47 - rdx);
				byte (* r11_63)[] = r8 - rdx_54;
				while (rax_60 != 0x00)
				{
					byte r8b_72 = Mem71[r11_63 + rdx_54:byte];
					if (r8b_72 == 0x00)
						break;
					*rdx_54 = r8b_72;
					--rax_60;
					++rdx_54;
					--rcx_55;
					if (rcx_55 == 0x00)
						break;
				}
			}
			byte * rax_104 = rdx_54 - 0x01;
			if (rcx_55 != 0x00)
				rax_104 = rdx_54;
			*rax_104 = 0x00;
			rdx_100 = (uint64) ((word32) (uint64) ~(word32) (uint64) (0x00 - (rcx_55 == 0x00)) & 0x8007007A);
		}
	}
	else
		rdx_100 = 0x80070057;
	return (word32) (uint64) (word32) rdx_100;
}

// 000000014000366C: void fn000000014000366C(Register Eq_225 rcx, Register (ptr64 byte) rdx, Register ptr64 r8)
// Called from:
//      fn0000000140001A08
//      fn0000000140001D28
//      fn00000001400028B8
//      fn0000000140004FD8
//      fn00000001400061E8
//      fn000000014000721C
//      fn0000000140007BB8
void fn000000014000366C(Eq_225 rcx, byte * rdx, ptr64 r8)
{
	if (rdx <= (byte *) 0x7FFFFFFF)
	{
		word64 rax_34;
		vsnprintf();
		int32 eax_37 = (word32) rax_34;
		if (eax_37 >= 0x00)
		{
			byte * rax_41 = (int64) eax_37;
			if (rax_41 <= rdx - (byte *) 0x01)
			{
				if (rax_41 == rdx - (byte *) 0x01)
					Mem52[rdx - 0x01 + rcx:byte] = 0x00;
				return;
			}
		}
		Mem48[rdx - 0x01 + rcx:byte] = 0x00;
	}
	else if (rdx != null)
		*rcx = 0x00;
}

// 00000001400036F0: void fn00000001400036F0(Register Eq_1049 rcx, Register word32 edx, Register Eq_3409 r8, Register word32 r9d)
void fn00000001400036F0(Eq_1049 rcx, word32 edx, Eq_3409 r8, word32 r9d)
{
	ui64 rax_10 = g_qw4000C008 ^ fp - 0x0238;
	word32 rax_32_32_23 = SLICE(rax_10, word32, 32);
	word32 edi_41 = (word32) r9;
	word32 edx_19 = (word32) (uint64) (edx - 0x0110);
	if (edx_19 != 0x00)
	{
		if (edx_19 != 0x01 || r8 != 0x083D && r8 != 2110)
			goto l00000001400037B1;
		EndDialog(rcx, r8);
	}
	else
	{
		fn0000000140003C8C(rcx, SEQ(rax_32_32_23, GetDesktopWindow()));
		LoadStringA(g_t4000DE70, (uint64) edi_41, fp - 0x0218, 0x0200);
		SetDlgItemTextA(rcx, 2111, fp - 0x0218);
		MessageBeep(0xFFFFFFFF);
	}
l00000001400037B1:
	fn00000001400013E0(rax_10 ^ fp - 0x0238);
}

// 00000001400037DC: Register word32 fn00000001400037DC(Register ptr64 rcx)
// Called from:
//      fn00000001400081D0
word32 fn00000001400037DC(ptr64 rcx)
{
	uint64 rax_156;
	Eq_225 rax_17 = LocalAlloc(0x40, 0x10);
	ui32 eax_128 = (word32) rax_17;
	if (rax_17 == 0x00)
	{
		word128 xmm0_266;
		fn00000001400061E8(g_t4000C828, 0x04B5, 0x00, null, 0x10, dwLoc10 & eax_128, out xmm0_266);
	}
	else
	{
		Eq_3493 rbx_22 = ~0x00;
		int64 rdx_25 = ~0x00;
		do
			++rdx_25;
		while (rcx + rdx_25 != 0x00);
		Eq_225 rax_35 = LocalAlloc(0x40, rdx_25 + 0x01);
		*rax_17 = rax_35;
		ui32 eax_99 = (word32) rax_35;
		Eq_225 rdx_38 = rax_35;
		if (rax_35 != 0x00)
		{
			do
				rbx_22 = (word64) rbx_22 + 1;
			while (*((word64) rbx_22 + rcx) != 0x00);
			int64 rbx_48 = (word64) rbx_22 + 1;
			if (rbx_22 != 0x01)
			{
				if (rbx_22 > 0x7FFFFFFE)
					*rax_35 = 0x00;
				else
				{
					uint64 rcx_55 = 0x7FFFFFFE - ((word64) rbx_22 + 1);
					int64 rsi_57 = rcx - rax_35;
					while (rcx_55 + rbx_48 != 0x00)
					{
						byte al_68 = *((word128) rdx_38 + rsi_57);
						if (al_68 == 0x00)
							break;
						*rdx_38 = al_68;
						++rdx_38;
						--rbx_48;
						if (rbx_48 == 0x00)
							break;
					}
					Eq_225 rcx_81 = rdx_38 - (void *) 0x01;
					if (rbx_48 != 0x00)
						rcx_81 = rdx_38;
					*rcx_81 = 0x00;
				}
			}
			*((word128) rax_17 + 8) = g_t4000D608;
			g_t4000D608 = rax_17;
			rax_156 = 0x01;
			return (word32) rax_156;
		}
		word128 xmm0_267;
		fn00000001400061E8(g_t4000C828, 0x04B5, 0x00, null, 0x10, dwLoc10 & eax_99, out xmm0_267);
		LocalFree(rax_17);
	}
	rax_156 = 0x00;
	return (word32) rax_156;
}

// 0000000140003920: void fn0000000140003920(Register Eq_1049 rcx, Register word32 edx, Register Eq_1053 r9)
void fn0000000140003920(Eq_1049 rcx, word32 edx, Eq_1053 r9)
{
	word32 edx = (word32) rdx;
	if (edx == 0x01)
		SendMessageA(rcx, 0x0466, 0x01, r9);
}

// 0000000140003950: Register word32 fn0000000140003950(Register Eq_1049 rcx)
// Called from:
//      fn00000001400078B0
word32 fn0000000140003950(Eq_1049 rcx)
{
	uint64 rax_239;
	Eq_405 rdx_39;
	Eq_265 rax_31 = LoadLibraryA(0x14000C1B0);
	if (rax_31 != 0x00)
	{
		Eq_969 rax_42 = GetProcAddress(rax_31, 0x14000C1D0);
		if (rax_42 != null && (GetProcAddress(rax_31, 0xC3) != null && GetProcAddress(rax_31, 0x14000C1E8) != null))
		{
			uint64 rbp_106 = 0x0104;
			if (g_b4000CBA0 == 0x00)
			{
				GetTempPathA(0x0104, 0x14000CBA0);
				int64 rdx_113 = ~0x00;
				do
					++rdx_113;
				while (0x14000CBA0 + rdx_113 != 0x00);
				Eq_225 rax_125 = CharPrevA(0x14000CBA0, rdx_113 + 0x14000CBA0);
				if (*rax_125 == 0x5C && *CharPrevA(0x14000CBA0, rax_125) != 0x3A)
					*rax_125 = 0x00;
			}
			g_b4000CA60 = 0x00;
			fn0000000140008E50();
			if (rax_42 != null)
			{
				fn0000000140008E50();
				if (g_b4000CBA0 != 0x00)
				{
					byte * rcx_172 = &g_b4000CA60;
					int64 rdi_173 = 0x14000CBA0 - 0x14000CA60;
					while (rbp_106 != 0x7FFFFEFA)
					{
						byte al_183 = rcx_172[rdi_173];
						if (al_183 == 0x00)
							break;
						*rcx_172 = al_183;
						++rcx_172;
						--rbp_106;
						if (rbp_106 == 0x00)
							break;
					}
					byte * rax_196 = rcx_172 - 0x01;
					if (rbp_106 != 0x00)
						rax_196 = rcx_172;
					*rax_196 = 0x00;
				}
				fn0000000140008E50();
			}
			FreeLibrary(rax_31);
			rax_239 = (uint64) (uint32) (int8) (g_b4000CA60 != 0x00);
			return (word32) rax_239;
		}
		FreeLibrary(rax_31);
		rdx_39.u0 = 1217;
	}
	else
		rdx_39.u0 = 1218;
	word128 xmm0_424;
	fn00000001400061E8(rcx, rdx_39, 0x00, null, 0x10, 0x00, out xmm0_424);
	rax_239 = 0x00;
	return (word32) rax_239;
}

// 0000000140003BA8: Register word32 fn0000000140003BA8(Register Eq_225 rcx, Register ptr64 r8, Register Eq_225 r9)
// Called from:
//      fn00000001400081D0
word32 fn0000000140003BA8(Eq_225 rcx, ptr64 r8, Eq_225 r9)
{
	byte * r10_12 = (byte *) ~0x00;
	int64 rcx_17 = ~0x00;
	do
	{
		++rcx_17;
		word32 ecx_41 = (word32) rcx_17;
	} while (r8 + rcx_17 != 0x00);
	int64 rax_27 = ~0x00;
	do
	{
		++rax_27;
		word32 eax_34 = (word32) rax_27;
	} while (*((word128) r9 + rax_27) != 0x00);
	uint64 rax_127;
	if ((word32) (uint64) ((word32) (uint64) (eax_34 + 0x01) + ecx_41) >= 0x0104)
	{
l0000000140003C71:
		rax_127 = 0x00;
		return (word32) rax_127;
	}
	else
	{
		uint64 rdx_49 = 0x0104;
		Eq_225 rcx_52 = rcx;
		ptr64 r8_54 = r8 - rcx;
		while (rdx_49 != 0x7FFFFEFA)
		{
			byte al_64 = *((word128) rcx_52 + r8_54);
			if (al_64 == 0x00)
				break;
			*rcx_52 = al_64;
			rcx_52 = (word128) rcx_52 + 1;
			--rdx_49;
			if (rdx_49 == 0x00)
				break;
		}
		Eq_225 rax_77 = rcx_52 - 0x01;
		if (rdx_49 != 0x00)
			rax_77 = rcx_52;
		*rax_77 = 0x00;
		int64 rax_86 = ~0x00;
		do
			++rax_86;
		while (*((word128) rcx + rax_86) != 0x00);
		if (*((word128) rcx + (rax_86 - 0x01)) != 0x5C)
		{
			do
				++r10_12;
			while (Mem81[rcx + r10_12:byte] != 0x00);
			if (Mem81[r10_12 - 0x01 + rcx:byte] != 0x2F && (word32) ((uint64) fn00000001400035A8(rcx, 0x0104, 0x14000988C)) < 0x00)
				goto l0000000140003C71;
		}
		fn00000001400035A8(rcx, 0x0104, r9);
		rax_127 = 0x01;
		return (word32) rax_127;
	}
}

// 0000000140003C8C: Register Eq_3863 fn0000000140003C8C(Register Eq_1049 rcx, Register Eq_1049 rdx)
// Called from:
//      fn00000001400036F0
//      fn00000001400049A0
//      fn0000000140006050
//      fn00000001400066A0
//      fn00000001400078B0
Eq_3863 fn0000000140003C8C(Eq_1049 rcx, Eq_1049 rdx)
{
	ui64 rax_29 = g_qw4000C008 ^ fp - 0xA8;
	GetWindowRect(rcx, fp - 0x50);
	GetWindowRect(rdx, fp - 0x60);
	Eq_3882 rax_62 = GetDC(rcx);
	int32 r12d_108 = (word32) (uint64) GetDeviceCaps(rax_62, 0x08);
	int32 r13d_159 = (word32) (uint64) GetDeviceCaps(rax_62, 0x0A);
	ReleaseDC(rcx, rax_62);
	uint64 r15_46 = (uint64) ((word32) (uint64) dwLoc48 - dwLoc50);
	word32 r15d_81 = (word32) r15_46;
	int64 edx_eax_88 = (int64) (word32) (uint64) (word32) (uint64) ((word32) (uint64) ((word32) (uint64) dwLoc58 - dwLoc60) - r15d_81);
	uint64 rsi_49 = (uint64) ((word32) (uint64) dwLoc44 - dwLoc4C);
	Eq_3937 r8_101 = (uint64) ((word32) (uint64) (word32) (uint64) ((word32) (uint64) ((word32) edx_eax_88 - SLICE(edx_eax_88, word32, 32)) >> 0x01) + dwLoc60);
	word32 esi_126 = (word32) rsi_49;
	word32 r14d_124 = (word32) (uint64) ((word32) (uint64) dwLoc54 - dwLoc5C);
	if ((word32) r8_101 < 0x00)
		r8_101.u1 = 0x00;
	else if ((word32) (uint64) (word32) ((word64) r8_101 + r15_46) > r12d_108)
		r8_101.u1 = (uint64) ((word32) (uint64) r12d_108 - r15d_81);
	int64 edx_eax_133 = (int64) (word32) (uint64) (word32) (uint64) (r14d_124 - esi_126);
	Eq_3863 r9_148 = (uint64) ((word32) (uint64) (word32) (uint64) ((word32) (uint64) ((word32) edx_eax_133 - SLICE(edx_eax_133, word32, 32)) >> 0x01) + dwLoc5C);
	if ((word32) r9_148 < 0x00)
		r9_148.u1 = 0x00;
	else if ((word32) (uint64) (word32) ((word64) r9_148 + rsi_49) > r13d_159)
		r9_148.u1 = (uint64) ((word32) (uint64) r13d_159 - esi_126);
	SetWindowPos(rcx, null, r8_101, r9_148, 0x00, 0x00, 0x05);
	fn00000001400013E0(rax_29 ^ fp - 0xA8);
	return r9_148;
}

// 0000000140003DF0: Register word32 fn0000000140003DF0(Register Eq_225 rcx)
// Called from:
//      fn0000000140005810
word32 fn0000000140003DF0(Eq_225 rcx)
{
	Eq_1053 dwLoc0208_760;
	Eq_225 r8_452;
	Eq_1052 r9_343;
	word32 edi_555;
	ui64 rax_28 = g_qw4000C008 ^ fp - 0x0228;
	if (GetVersionExA(fp - 488) == 0x00)
	{
		edi_555 = 0x04B4;
		goto l0000000140003E75;
	}
	word16 ax_116;
	up32 r11d_96 = (word32) (uint64) dwLoc01E0;
	up32 r8d_80 = (word32) (uint64) dwLoc01E4;
	word32 eax_54 = (word32) (uint64) ((word32) (uint64) dwLoc01D8 - 0x01);
	if (eax_54 != 0x00)
	{
		if (eax_54 != 0x01)
		{
			edi_555 = 1226;
l0000000140003E75:
			r9_343 = null;
			r8_452.u0 = 0x00;
			dwLoc0208_760.u0 = 0x10;
			goto l00000001400040F7;
		}
		g_t4000C1AC.u0 = 0x01;
		g_dw4000C1A8 = 0x01;
		g_w4000DE78 = 0x02;
		ax_116 = 0x02;
		if (r8d_80 <= 0x03)
		{
			g_w4000DE78 = 0x01;
			ax_116 = 0x01;
			if (r8d_80 < 0x03 || r8d_80 == 0x03 && r11d_96 < 0x33)
			{
				g_t4000C1AC.u0 = 0x00;
				g_dw4000C1A8 = 0x00;
			}
		}
		else if (r8d_80 >= 0x05)
		{
			g_w4000DE78 = 0x03;
			ax_116 = 0x03;
		}
	}
	else
	{
		g_w4000DE78 = 0x00;
		g_t4000C1AC.u0 = 0x01;
		g_dw4000C1A8 = 0x01;
		ax_116 = 0x00;
	}
	if (g_dw4000CD14 != 0x00 || rcx == 0x00)
		return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
	up32 esi_694 = (word32) (uint64) (word32) wLoc01DC;
	int32 dwLoc01F8_724 = 0x00;
	word32 ecx_149 = 0x00;
	struct Eq_4138 * rdx_129 = (word128) rcx + 64 + (0x00 - (ax_116 == 0x00) & ~0x3B);
	word32 eax_140 = 0x00;
	uint64 r10_1042 = 0x00;
	do
	{
		Eq_4157 ecx_198;
		word32 r10d_218 = (word32) r10_1042;
		int64 rax_141 = (int64) eax_140;
		if (r8d_80 < rdx_129[(rax_141 * 0x18) /64 56])
		{
l0000000140003F4D:
			ecx_198.u0 = ~0x00;
			goto l0000000140003F6C;
		}
		if (r8d_80 > rdx_129[(rax_141 * 0x18) /64 56])
		{
			ecx_198.u0 = 0x01;
			goto l0000000140003F6C;
		}
		int64 rax_150 = (int64) ecx_149;
		if (r11d_96 < ((rdx_129->a0000))[rax_150].dw0004)
			goto l0000000140003F4D;
		ecx_198.u1 = (uint32) (int8) (r11d_96 > ((rdx_129->a0000))[rax_150].dw0004);
l0000000140003F6C:
		Eq_4159 eax_206;
		if (r8d_80 < ((rdx_129->a0000))[rax_141].dw000C)
		{
l0000000140003F73:
			eax_206.u0 = ~0x00;
			goto l0000000140003F8B;
		}
		if (r8d_80 > ((rdx_129->a0000))[rax_141].dw000C)
		{
			eax_206.u0 = 0x01;
			goto l0000000140003F8B;
		}
		if (r11d_96 < ((rdx_129->a0000))[rax_141].dw0010)
			goto l0000000140003F73;
		eax_206.u1 = (uint32) (int8) (r11d_96 > ((rdx_129->a0000))[rax_141].dw0010);
l0000000140003F8B:
		if (ecx_198 >= 0x00 && eax_206 <= 0x00)
		{
			bool v136_702;
			if (ecx_198 == 0x00)
			{
				if (eax_206 == 0x00)
				{
					up32 eax_251 = (word32) (uint64) esi_694;
					if (esi_694 < ((rdx_129->a0000))[rax_141].dw0008)
						goto l0000000140003FBF;
					v136_702 = eax_251 <= ((rdx_129->a0000))[rax_141].dw0014;
					goto l0000000140003FBD;
				}
				if (esi_694 >= ((rdx_129->a0000))[rax_141].dw0008)
					break;
			}
			else
			{
				if (eax_206 != 0x00)
					break;
				v136_702 = esi_694 <= ((rdx_129->a0000))[rax_141].dw0014;
l0000000140003FBD:
				if (v136_702)
					break;
			}
l0000000140003FBF:
			if (r10d_218 != 0x00)
				goto l0000000140003FC4;
		}
		else if (r10d_218 == 0x01)
		{
l0000000140003FC4:
			r9_343 = null;
			edi_555 = 0x054C;
			goto l0000000140003FCC;
		}
		r10_1042 = (uint64) (r10d_218 + 0x01);
		int32 r10d_264 = (word32) r10_1042;
		dwLoc01F8_724 = r10d_264;
		eax_140 = (word32) (uint64) r10d_264;
		ecx_149 = (word32) (uint64) r10d_264;
	} while (r10d_264 < 0x02);
	if (*((word128) rcx + 0x007C) == 0x00 || (word32) ((uint64) fn00000001400022F0(rcx, fp - 0x0148, fp - 0x01F8, dwLoc0228, dwLoc0210)) != 0x00)
		return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
	r9_343 = fp - 0x0148;
	edi_555 = 0x054D;
	rdx_129 = (uint64) *((word128) rcx + 0x0080) + 0x84 + ((word128) rcx + (int64) dwLoc01F8_724 *s 0x3C);
l0000000140003FCC:
	Eq_225 r15_374 = 0x00;
	ui32 esi_421 = 0x00;
	if (rdx_129 != null)
	{
		r15_374 = (word128) rcx + 0x0084 + (uint64) rdx_129->dw0034;
		byte al_405 = (byte) (uint64) rdx_129->dw0030;
		if ((al_405 & 0x01) != 0x00)
			esi_421 = 0x0104;
		else
			esi_421 = (word32) (uint64) ((word32) (uint64) (0x00 - ((al_405 & 0x02) == 0x00)) & 0x0101);
	}
	byte sil_510 = (byte) esi_421;
	if ((g_t4000CD18 & 0x01) != 0x00 || (r15_374 == 0x00 || *r15_374 == 0x00))
	{
		dwLoc0208_760.u0 = 0x30;
		r8_452.u0 = 5368763768;
l00000001400040F7:
		word128 xmm0_1044;
		fn00000001400061E8(null, (uint64) edi_555, r8_452, r9_343, dwLoc0208_760, 0x00, out xmm0_1044);
		return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
	}
	ui32 eax_490;
	MessageBeep(0x00);
	if ((word32) (uint64) fn0000000140008BB4() != 0x00)
	{
		eax_490 = 0x00180030;
		if ((word32) (uint64) fn0000000140008AE4() != 0x00)
		{
l00000001400040AD:
			bool v139_705;
			int32 eax_509 = MessageBoxA(null, r15_374, 5368763768, (uint64) (word32) (uint64) (eax_490 | esi_421));
			if ((sil_510 & 0x04) == 0x00)
			{
				if ((sil_510 & 0x01) == 0x00)
					return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
				v139_705 = eax_509 != 0x01;
				return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
			}
			else
			{
				v139_705 = eax_509 != 0x06;
				return (word32) fn00000001400013E0(rax_28 ^ fp - 0x0228);
			}
		}
	}
	eax_490 = 0x30;
	goto l00000001400040AD;
}

// 0000000140004140: Register word32 fn0000000140004140(Register Eq_225 rcx)
// Called from:
//      fn00000001400081D0
word32 fn0000000140004140(Eq_225 rcx)
{
	Eq_126 eax_13 = GetFileAttributesA(rcx);
	word32 ebx_56 = 0x01;
	byte al_16 = (byte) eax_13;
	if (eax_13 == ~0x00 || (al_16 & 0x10) != 0x00)
		return (word32) (uint64) ebx_56;
	if (g_dw4000D600 == 0x00 && (g_t4000CD18 & 0x01) == 0x00)
	{
		Eq_1049 r8_26 = g_t4000C828;
		g_t4000D830 = rcx;
		word128 xmm0_111;
		word64 rax_39 = fn00000001400064B0(2003, r8_26, &g_t400066A0, 0x00, out xmm0_111);
		if (rax_39 != 0x06)
		{
			if (rax_39 == 0x07)
			{
				ebx_56 = 0x00;
				return (word32) (uint64) ebx_56;
			}
			if (rax_39 == 0x0839)
				g_dw4000D600 = 0x01;
		}
	}
	SetFileAttributesA(rcx, 0x80);
	return (word32) (uint64) ebx_56;
}

// 00000001400041EC: Register word32 fn00000001400041EC(Register Eq_225 rcx, Register word32 edx, Register word32 r8d, Register out Eq_4459 xmm0Out)
// Called from:
//      fn000000014000521C
word32 fn00000001400041EC(Eq_225 rcx, word32 edx, word32 r8d, union Eq_4459 & xmm0Out)
{
	ui64 rax_12 = g_qw4000C008 ^ fp - (struct _SYSTEM_INFO *) 0x0178;
	word32 esi_223 = (word32) (uint64) r8d;
	if (edx == 0x00)
	{
		uint64 rdi_25 = 0x0104;
		byte * rcx_26 = g_a4000D610;
		int64 r9_27 = rcx - 0x14000D610;
		while (rdi_25 != 0x7FFFFEFA)
		{
			byte al_37 = rcx_26[r9_27];
			if (al_37 == 0x00)
				break;
			*rcx_26 = al_37;
			++rcx_26;
			--rdi_25;
			if (rdi_25 == 0x00)
				break;
		}
		byte * rax_50 = rcx_26 - 0x01;
		if (rdi_25 != 0x00)
			rax_50 = rcx_26;
		*rax_50 = 0x00;
l0000000140004326:
		if ((word32) (uint64) fn0000000140005ED8(0x14000D610, out xmm0) == 0x00)
		{
			if (CreateDirectoryA(0x14000D610, null) == 0x00)
			{
				g_dw4000D544 = (word32) (uint64) fn0000000140006590();
				goto l000000014000439C;
			}
			g_dw4000CD00 = 0x01;
		}
		if ((word32) (uint64) fn0000000140005B50(0x14000D610, (uint64) esi_223, 0x00, out xmm0) != 0x00)
		{
			g_dw4000D544 = 0x00;
l000000014000439E:
			word64 rax_288 = fn00000001400013E0(rax_12 ^ fp - (struct _SYSTEM_INFO *) 0x0178);
			xmm0Out = xmm0;
			return (word32) rax_288;
		}
		if (g_dw4000CD00 != 0x00)
		{
			g_dw4000CD00 = 0x00;
			RemoveDirectoryA(0x14000D610);
		}
l000000014000439C:
		goto l000000014000439E;
	}
	if ((word32) (uint64) fn0000000140004FD8(rcx, fp - 0x0128) == 0x00)
		goto l000000014000439C;
	uint64 rdx_77 = 0x0104;
	byte * rcx_101 = g_a4000D610;
	int64 r8_79 = fp - (struct _SYSTEM_INFO *) 0x0128 - g_a4000D610;
	while (rdx_77 != 0x7FFFFEFA)
	{
		byte al_89 = rcx_101[r8_79];
		if (al_89 == 0x00)
			break;
		*rcx_101 = al_89;
		++rcx_101;
		--rdx_77;
		if (rdx_77 == 0x00)
			break;
	}
	byte * rax_102 = rcx_101 - 0x01;
	if (rdx_77 != 0x00)
		rax_102 = rcx_101;
	*rax_102 = 0x00;
	if ((g_t4000DE64 & 0x20) != 0x00)
	{
		Eq_225 r8_120;
		GetSystemInfo(fp - (struct _SYSTEM_INFO *) 344);
		word32 ecx_116 = (word32) (uint64) (word32) wLoc0158;
		if (ecx_116 != 0x00)
		{
			word32 ecx_123 = (word32) (uint64) (ecx_116 - 0x01);
			if (ecx_123 != 0x00)
			{
				word32 ecx_129 = (word32) (uint64) (ecx_123 - 0x01);
				if (ecx_129 != 0x00)
				{
					if (ecx_129 != 0x01)
						goto l00000001400042D4;
					r8_120.u0 = 0x140009A08;
				}
				else
					r8_120.u0 = 0x140009A00;
			}
			else
				r8_120.u0 = 0x1400099F8;
		}
		else
			r8_120.u0 = 0x1400099F0;
		fn000000014000887C(0x14000D610, 0x0104, r8_120);
	}
l00000001400042D4:
	fn000000014000887C(0x14000D610, 0x0104, 0x140009770);
	goto l0000000140004326;
}

// 00000001400043CC: void fn00000001400043CC()
// Called from:
//      fn0000000140007FE4
void fn00000001400043CC()
{
	ui64 rax_10 = g_qw4000C008 ^ fp - 0x0168;
	Eq_225 rbx_14 = g_t4000D608;
	while (rbx_14 != 0x00)
	{
		if (g_t4000CD04 == 0x00 && g_dw4000DE60 == 0x00)
		{
			SetFileAttributesA(*rbx_14, 0x80);
			DeleteFileA(*rbx_14);
		}
		rbx_14 = *((word128) rbx_14 + 8);
		LocalFree(*rbx_14);
		LocalFree(rbx_14);
	}
	word32 eax_130 = (word32) (uint64) g_dw4000CD00;
	if (eax_130 != 0x00 && (g_t4000CD04 == 0x00 && g_dw4000DE60 == 0x00))
	{
		uint64 rdx_53 = 0x0104;
		int64 r8_57 = 0x14000D610 - (fp - 0x0128);
		Eq_4705 rcx_59 = fp - 0x0128;
		while (rdx_53 != 0x7FFFFEFA)
		{
			byte al_68 = *((word64) rcx_59 + r8_57);
			if (al_68 == 0x00)
				break;
			*rcx_59 = al_68;
			++rcx_59;
			--rdx_53;
			if (rdx_53 == 0x00)
				break;
		}
		Eq_4705 rax_82 = rcx_59 - 0x01;
		if (rdx_53 != 0x00)
			rax_82 = rcx_59;
		*rax_82 = 0x00;
		if ((g_t4000DE64 & 0x20) != 0x00)
			fn0000000140008914(fp - 0x0128);
		SetCurrentDirectoryA(0x140009840);
		fn00000001400026B8(fp - 0x0128);
		eax_130 = (word32) (uint64) g_dw4000CD00;
	}
	if (g_w4000DE78 != 0x01 && (eax_130 != 0x00 && (g_b4000C7D0 != 0x00 && RegOpenKeyExA(~0x7FFFFFFD, 0x14000C088, 0x00, 0x00020006, fp - 0x0138) == 0x00)))
	{
		RegDeleteValueA(qwLoc0138, 0x14000C7D0);
		RegCloseKey(qwLoc0138);
	}
	g_dw4000CD00 = 0x00;
	fn00000001400013E0(rax_10 ^ fp - (byte *) 0x0168);
}

// 0000000140004598: Register word32 fn0000000140004598()
// Called from:
//      fn00000001400046E8
word32 fn0000000140004598()
{
	uint64 rax_102;
	uint64 rax_17 = (uint64) fn0000000140005140(0x140009910, 0x00, 0x00);
	Eq_225 rax_32 = LocalAlloc(0x40, (uint64) (word32) (rax_17 + 0x01));
	g_t4000D030 = rax_32;
	word32 ebx_37 = (word32) (uint64) (word32) rax_17;
	ui32 eax_134 = (word32) rax_32;
	if (rax_32 == 0x00)
	{
		word128 xmm0_223;
		fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, dwLoc10 & eax_134, out xmm0_223);
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		goto l00000001400045FA;
	}
	ui32 eax_52 = (word32) (uint64) fn0000000140005140(0x140009910, rax_32, (word32) (uint64) ebx_37);
	if (eax_52 != 0x00)
	{
		if (lstrcmpA(g_t4000D030, 0x140009918) != 0x00)
		{
			word128 xmm0_225;
			word64 rax_81 = fn00000001400064B0(2001, null, &g_t40006050, 0x00, out xmm0_225);
			LocalFree(g_t4000D030);
			if (rax_81 == 0x00)
			{
				g_dw4000D544 = 0x800704C7;
l00000001400045FA:
				rax_102 = 0x00;
				return (word32) rax_102;
			}
		}
		else
			LocalFree(g_t4000D030);
		g_dw4000D544 = 0x00;
		rax_102 = 0x01;
		return (word32) rax_102;
	}
	else
	{
		word128 xmm0_224;
		fn00000001400061E8(null, 1201, 0x00, null, 0x10, dwLoc10 & eax_52, out xmm0_224);
		LocalFree(g_t4000D030);
		g_dw4000D544 = 0x80070714;
		goto l00000001400045FA;
	}
}

// 00000001400046E8: Register word32 fn00000001400046E8()
// Called from:
//      fn0000000140007FE4
word32 fn00000001400046E8()
{
	ui64 rax_10 = g_qw4000C008 ^ fp - 616;
	if (g_t4000CD18 == 0x00)
	{
		if (g_t4000CD04 != 0x00)
		{
l0000000140004730:
			if ((word32) (uint64) fn0000000140004598() == 0x00)
				return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
			goto l000000014000473D;
		}
		if ((word32) (uint64) fn00000001400056C8() == 0x00)
			return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
		if (g_t4000CD18 == 0x00)
			goto l0000000140004730;
	}
l000000014000473D:
	if ((word32) (uint64) fn0000000140004F18() == 0x00)
		return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
	Eq_4964 xmm0_165;
	if ((word32) (uint64) fn000000014000521C(out xmm0_165) == 0x00)
		return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
	GetSystemDirectoryA(fp - 0x0238, 0x0105);
	fn000000014000887C(fp - 0x0238, 0x0105, 0x140009778);
	Eq_265 rax_113 = LoadLibraryA(fp - 0x0238);
	if (rax_113 != 0x00 && GetProcAddress(rax_113, 0x140009900) != null)
		fn0000000140008E50();
	Eq_405 rdx_366;
	FreeLibrary(rax_113);
	if (g_t4000CD04 == 0x00 && g_dw4000DE60 == 0x00)
	{
		if (GetWindowsDirectoryA(fp - 0x0128, 0x0104) == 0x00)
		{
			rdx_366.u0 = 0x04F0;
			goto l0000000140004818;
		}
		if ((word32) (uint64) fn0000000140005B50(fp - 0x0128, 0x02, 0x02, out xmm0_165) == 0x00)
			return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
	}
	if (SetCurrentDirectoryA(0x14000D610) == 0x00)
	{
		rdx_366.u0 = 1212;
l0000000140004818:
		word128 xmm0_560;
		fn00000001400061E8(null, rdx_366, 0x00, null, 0x10, 0x00, out xmm0_560);
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
	}
	if (g_dw4000CD0C != 0x00)
	{
l0000000140004917:
		word32 eax_309;
		ci8 al_282 = (byte) (uint64) g_dw4000D028;
		if ((al_282 & 0x40) == 0x00 && al_282 >= 0x00)
			eax_309 = (word32) (uint64) fn00000001400034D8((uint64) (word32) g_w4000DE78, qwLoc0260);
		else
			eax_309 = 0x00;
		g_dw4000DE7C = eax_309;
		word32 eax_315 = (word32) (uint64) g_t4000CD04;
		if (eax_315 == 0x00 && g_dw4000DE60 == 0x00)
		{
			if ((word32) (uint64) fn000000014000721C() == 0x00)
				return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
			eax_315 = (word32) (uint64) g_t4000CD04;
		}
		if (g_t4000CD18 == 0x00 && eax_315 == 0x00)
			fn0000000140004E34();
		return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
	}
	struct Eq_5064 * rax_184 = &g_t4000D040;
	uint64 rcx_186;
	for (rcx_186 = 0x28; rcx_186 != 0x00; --rcx_186)
	{
		rax_184->dw0000 = 0x01;
		++rax_184;
	}
	if ((g_t4000CD18 & 0x01) == 0x00 && (g_t4000DE64 & 0x01) == 0x00)
	{
		word128 xmm0_561;
		if (fn00000001400064B0(0x00 - ((word32) ((uint64) (-((word32) ((uint64) g_t4000C1AC)))) == 0x00) + 2005, null, &g_t400049A0, 0x00, out xmm0_561) != 0x00)
		{
l00000001400048FD:
			if ((word32) (uint64) fn0000000140007BB8(0x140006E50) == 0x00)
				return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
			g_dw4000D544 = 0x00;
			goto l0000000140004917;
		}
	}
	else if ((word32) (uint64) fn0000000140004BE0(xmm0_165) != 0x00)
		goto l00000001400048FD;
	g_dw4000D544 = 0x8007042B;
	return (word32) fn00000001400013E0(rax_10 ^ fp - 616);
}

// 00000001400049A0: void fn00000001400049A0(Register word32 rax_32_32, Register Eq_1049 rcx, Register word32 edx, Register word64 r8)
void fn00000001400049A0(word32 rax_32_32, Eq_1049 rcx, word32 edx, word64 r8)
{
	Eq_3409 rdx_187;
	word32 esi_202 = (word32) r8;
	word32 edx_20 = (word32) (uint64) (edx - 0x10);
	if (edx_20 != 0x00)
	{
		word32 edx_25 = (word32) (uint64) (edx_20 - 242);
		if (edx_25 != 0x00)
		{
			word32 edx_35 = (word32) (uint64) (edx_25 - 0x0E);
			if (edx_35 != 0x00)
			{
				word32 edx_133 = (word32) (uint64) (edx_35 - 0x01);
				if (edx_133 != 0x00)
				{
					if (edx_133 != 0x0E90)
						return;
					TerminateThread(g_t4000CA58, 0x00);
					rdx_187.u0 = (int64) esi_202;
l0000000140004BAA:
					EndDialog(rcx, rdx_187);
					return;
				}
				if (r8 != 0x02)
					return;
				ResetEvent(g_t4000C838);
				word128 xmm0_327;
				word32 eax_163 = (word32) (uint64) fn00000001400061E8(g_t4000C828, 1202, 0x140009770, null, 0x20, 0x04, out xmm0_327);
				if (eax_163 != 0x06 && eax_163 != 0x01)
				{
					SetEvent(g_t4000C838);
					return;
				}
				Eq_384 rcx_169 = g_t4000C838;
				g_dw4000D5FC = 0x01;
				SetEvent(rcx_169);
				fn0000000140007F58();
			}
			else
			{
				g_t4000C828 = rcx;
				fn0000000140003C8C(rcx, SEQ(rax_32_32, GetDesktopWindow()));
				if (g_t4000C1AC != 0x00)
				{
					SendMessageA(GetDlgItem(rcx, 0x083B), 0x0464, 0x00, 0x0BB9);
					SendMessageA(GetDlgItem(rcx, 0x083B), 1125, ~0x00, ~0xFFFF);
				}
				SetWindowTextA(rcx, 5368763768);
				Eq_384 rax_99 = CreateThread(null, 0x00, &g_t40004BE0, 0x00, 0x00, 0x14000CA50);
				g_t4000CA58 = rax_99;
				ui32 dwLoc10_249 = (word32) 0x14000CA50;
				ui32 eax_104 = (word32) rax_99;
				if (rax_99 != null)
					return;
				word128 xmm0_328;
				fn00000001400061E8(rcx, 0x04B8, 0x00, null, 0x10, dwLoc10_249 & eax_104, out xmm0_328);
			}
l0000000140004BA8:
			rdx_187.u1 = 0x00;
			goto l0000000140004BAA;
		}
		if (r8 != 0x1B)
			return;
	}
	g_dw4000D5FC = 0x01;
	goto l0000000140004BA8;
}

// 0000000140004BE0: Register word32 fn0000000140004BE0(Register Eq_4964 xmm0)
// Called from:
//      fn00000001400046E8
word32 fn0000000140004BE0(Eq_4964 xmm0)
{
	g_dw4000D568 = (word32) (uint64) fn0000000140005140(0x1400099B0, 0x00, 0x00);
	Eq_225 rax_262 = LockResource(LoadResource(0x00, FindResourceA(0x00, 0x1400099B0, 0x0A)));
	g_t4000D560 = rax_262;
	if (rax_262 == 0x00)
		return (word32) rax_262;
	Eq_1049 rcx_45 = g_t4000C828;
	if (rcx_45 != null)
	{
		ShowWindow(GetDlgItem(rcx_45, 2114), 0x00);
		ShowWindow(GetDlgItem(g_t4000C828, 2113), 0x05);
	}
	word32 ebx_191;
	Eq_405 rdx_155;
	if ((word32) (uint64) fn0000000140007E28(xmm0) == 0x00)
	{
		rdx_155.u0 = 1210;
		goto l0000000140004D84;
	}
	word64 rax_104;
	word64 r11_106;
	Cabinet.dll!Ordinal_20();
	if (rax_104 == 0x00)
	{
l0000000140004D78:
		rdx_155.u0 = (uint64) ((word32) (uint64) g_dw4000D56C + 1300);
l0000000140004D84:
		word128 xmm0_347;
		fn00000001400061E8(g_t4000C828, rdx_155, 0x00, null, 0x10, 0x00, out xmm0_347);
		ebx_191 = 0x00;
		goto l0000000140004DA5;
	}
	else
	{
		word64 rax_128;
		word64 r11_130;
		Cabinet.dll!Ordinal_22();
		word32 eax_132 = (word32) rax_128;
		ebx_191 = (word32) (uint64) eax_132;
		if (eax_132 != 0x00)
		{
			word64 rax_142;
			word64 r11_144;
			Cabinet.dll!Ordinal_23();
			if ((word32) rax_142 == 0x00)
				goto l0000000140004D78;
		}
l0000000140004DA5:
		Eq_225 rcx_195 = g_t4000D560;
		if (rcx_195 != 0x00)
		{
			FreeResource(rcx_195);
			g_t4000D560.u0 = 0x00;
		}
		if (ebx_191 == 0x00 && g_dw4000D5FC == ebx_191)
		{
			word128 xmm0_348;
			fn00000001400061E8(null, 1272, 0x00, null, 0x10, 0x00, out xmm0_348);
		}
		if ((g_t4000CD18 & 0x01) == 0x00 && (g_t4000DE64 & 0x01) == 0x00)
			SendMessageA(g_t4000C828, 4001, (int64) ebx_191, 0x00);
		rax_262 = (uint64) ebx_191;
		return (word32) rax_262;
	}
}

// 0000000140004E34: void fn0000000140004E34()
// Called from:
//      fn00000001400046E8
void fn0000000140004E34()
{
	uint64 rax_19 = (uint64) fn0000000140005140(0x140009968, 0x00, 0x00);
	Eq_225 rax_35 = LocalAlloc(0x40, (uint64) (word32) (rax_19 + 0x01) << 0x03);
	word32 edi_40 = (word32) (uint64) (word32) rax_19;
	ui32 eax_111 = (word32) rax_35;
	if (rax_35 == 0x00)
	{
		word128 xmm0_186;
		fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, dwLoc10 & eax_111, out xmm0_186);
		return;
	}
	Eq_1054 dwLoc10_150;
	Eq_1053 dwLoc18_151;
	Eq_405 rdx_72;
	Eq_225 r8_69;
	ui32 eax_55 = (word32) (uint64) fn0000000140005140(0x140009968, rax_35, (word32) (uint64) edi_40);
	if (eax_55 == 0x00)
	{
		dwLoc10_150 = dwLoc10 & eax_55;
		rdx_72.u0 = 1201;
		r8_69.u0 = 0x00;
		dwLoc18_151.u0 = 0x10;
	}
	else
	{
		if (lstrcmpA(rax_35, 0x140009918) == 0x00)
			goto l0000000140004EF6;
		dwLoc10_150.u0 = 0x00;
		r8_69 = rax_35;
		dwLoc18_151.u0 = 0x40;
		rdx_72.u0 = 1001;
	}
	word128 xmm0_187;
	fn00000001400061E8(null, rdx_72, r8_69, null, dwLoc18_151, dwLoc10_150, out xmm0_187);
l0000000140004EF6:
	LocalFree(rax_35);
}

// 0000000140004F18: Register word32 fn0000000140004F18()
// Called from:
//      fn00000001400046E8
word32 fn0000000140004F18()
{
	uint64 rax_122;
	Eq_405 rdx_107;
	if ((word32) (uint64) fn0000000140005140(0x1400099B8, 0x14000CCC0, 0x24) != 0x24)
		rdx_107.u0 = 1201;
	else
	{
		word32 eax_25 = (word32) (uint64) g_dw4000CCE0;
		g_dw4000D824 = eax_25;
		if (eax_25 != 0x00)
		{
			fn0000000140005140(5368748488, 5368766056, 0x04);
			ui32 eax_55 = (word32) (uint64) fn0000000140007BB8(0x140006DF0);
			if (eax_55 != 0x00)
			{
				rax_122 = 0x01;
				return (word32) rax_122;
			}
			word128 xmm0_162;
			fn00000001400061E8(null, 1222, 0x00, null, 0x10, dwLoc10 & eax_55, out xmm0_162);
l0000000140004F63:
			rax_122 = 0x00;
			return (word32) rax_122;
		}
		rdx_107.u0 = 1222;
	}
	word128 xmm0_161;
	fn00000001400061E8(null, rdx_107, 0x00, null, 0x10, 0x00, out xmm0_161);
	g_dw4000D544 = 0x80070714;
	goto l0000000140004F63;
}

// 0000000140004FD8: Register word32 fn0000000140004FD8(Register Eq_225 rcx, Register Eq_225 rdx)
// Called from:
//      fn00000001400041EC
word32 fn0000000140004FD8(Eq_225 rcx, Eq_225 rdx)
{
	ui64 rax_18 = g_qw4000C008 ^ fp - 344;
	int32 esi_190 = 0x00;
	ptr64 r14_28 = rcx - rdx;
	do
	{
		fn000000014000366C(fp - 0x0138, (byte *) 0x0104, 0x1400099E0);
		esi_190 = (word32) (uint64) (esi_190 + 0x01);
		uint64 rdx_49 = 0x0104;
		Eq_225 rcx_51 = rdx;
		while (rdx_49 != 0x7FFFFEFA)
		{
			byte al_60 = *((word64) rcx_51 + r14_28);
			if (al_60 == 0x00)
				break;
			*rcx_51 = al_60;
			rcx_51 = (word64) rcx_51 + 1;
			--rdx_49;
			if (rdx_49 == 0x00)
				break;
		}
		Eq_225 rax_73 = rcx_51 - 0x01;
		if (rdx_49 != 0x00)
			rax_73 = rcx_51;
		*rax_73 = 0x00;
		fn000000014000887C(rdx, 0x0104, fp - 0x0138);
		RemoveDirectoryA(rdx);
		if (GetFileAttributesA(rdx) == ~0x00)
		{
			if (CreateDirectoryA(rdx, null) == 0x00)
				break;
			g_dw4000CD00 = 0x01;
			return (word32) fn00000001400013E0(rax_18 ^ fp - 344);
		}
	} while (esi_190 < 400);
	if (GetTempFileNameA(rcx, 0x1400099EC, 0x00, rdx) != 0x00)
	{
		DeleteFileA(rdx);
		CreateDirectoryA(rdx, null);
	}
	return (word32) fn00000001400013E0(rax_18 ^ fp - 344);
}

// 0000000140005140: Register word32 fn0000000140005140(Register Eq_225 rcx, Register Eq_225 rdx, Register word32 r8d)
// Called from:
//      fn0000000140004598
//      fn0000000140004BE0
//      fn0000000140004E34
//      fn0000000140004F18
//      fn000000014000521C
//      fn00000001400056C8
//      fn0000000140005810
//      fn000000014000721C
word32 fn0000000140005140(Eq_225 rcx, Eq_225 rdx, word32 r8d)
{
	uint64 rax_113;
	Eq_126 eax_29 = SizeofResource(0x00, FindResourceA(0x00, rcx, 0x0A));
	Eq_126 ebp_32 = (word32) (uint64) r8d;
	word32 ebx_62 = (word32) (uint64) eax_29;
	if (eax_29 > ebp_32 || rdx == 0x00)
	{
l00000001400051F9:
		rax_113 = (uint64) ebx_62;
		return (word32) rax_113;
	}
	else
	{
		if (eax_29 != 0x00)
		{
			Eq_225 rax_52 = LockResource(LoadResource(0x00, FindResourceA(0x00, rcx, 0x0A)));
			if (rax_52 != 0x00)
			{
				memcpy_s(rdx, (uint64) ebp_32, rax_52, (uint64) ebx_62);
				FreeResource(rax_52);
				goto l00000001400051F9;
			}
		}
		rax_113 = 0x00;
		return (word32) rax_113;
	}
}

// 000000014000521C: Register word32 fn000000014000521C(Register out Eq_4967 xmm0Out)
// Called from:
//      fn00000001400046E8
word32 fn000000014000521C(union Eq_4967 & xmm0Out)
{
	Eq_4967 xmm0_1205;
	ui64 rax_24 = g_qw4000C008 ^ fp - 0x0178;
	uint64 rax_36 = (uint64) fn0000000140005140(0x140009948, 0x00, 0x00);
	word32 esi_58 = (word32) (uint64) (word32) rax_36;
	Eq_225 rax_51 = LocalAlloc(0x40, (uint64) (word32) (rax_36 + 0x01));
	if (rax_51 == 0x00)
	{
		fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, 0x00, out xmm0_1205);
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		goto l00000001400052A7;
	}
	if ((word32) (uint64) fn0000000140005140(0x140009948, rax_51, (word32) (uint64) esi_58) == 0x00)
	{
		fn00000001400061E8(null, 1201, 0x00, null, 0x10, 0x00, out xmm0_1205);
		LocalFree(rax_51);
		g_dw4000D544 = 0x80070714;
		goto l00000001400052A7;
	}
	int32 eax_79 = lstrcmpA(rax_51, 0x140009918);
	word32 ecx_88 = (word32) (uint64) g_dw4000DE60;
	if (eax_79 == 0x00)
		ecx_88 = 0x01;
	g_dw4000DE60 = ecx_88;
	LocalFree(rax_51);
	byte al_95 = g_b4000CE1E;
	int64 r14_859 = 0x01;
	if (al_95 == 0x00)
	{
		if (g_t4000CD04 != 0x00 || g_dw4000DE60 != 0x00)
		{
			fn00000001400064B0(2002, null, &g_t400078B0, 0x00, out xmm0_1205);
			goto l0000000140005692;
		}
		if (GetTempPathA(0x0104, 0x14000D610) == 0x00 || (word32) ((uint64) fn00000001400041EC(0x14000D610, 0x01, 0x03, out xmm0_1205)) == 0x00 && ((word32) ((uint64) fn000000014000332C()) != 0x00 || (word32) ((uint64) fn00000001400041EC(0x14000D610, 0x01, 0x01, out xmm0_1205)) == 0x00))
		{
			Eq_5918 rsi_221 = 0x140009A0C - (fp - 0x0138);
			do
			{
				uint64 rdx_224;
				Eq_5950 rcx_226 = fp - 0x0138;
				for (rdx_224 = 0x0104; rdx_224 != 0x00; rdx_224 -= r14_859)
				{
					word32 r14_32_32_870 = SLICE(r14_859, word32, 32);
					if (rdx_224 == 0x7FFFFEFA)
						break;
					byte al_235 = Mem234[rsi_221 + rcx_226:byte];
					if (al_235 == 0x00)
						break;
					*rcx_226 = al_235;
					rcx_226 = (word64) rcx_226 + r14_859;
				}
				Eq_5950 rax_249 = rcx_226 - 0x01;
				if (rdx_224 != 0x00)
					rax_249 = rcx_226;
				*rax_249 = 0x00;
				if (bLoc0138 <= 0x5A)
				{
					do
					{
						int64 r14_1212;
						int64 r14_1216;
						ci8 cl_565;
						Eq_405 eax_265 = GetDriveTypeA(fp - 0x0138);
						word24 r14d_24_8_384 = SLICE(r14_859, word24, 8);
						cu8 r14b_295 = (byte) r14_859;
						word56 rcx_56_8_287 = SLICE(fp - (CHAR *) 0x0138, word56, 8);
						word32 edi_278 = (word32) (uint64) eax_265;
						if (eax_265 != 0x06 && eax_265 != 0x03)
						{
l0000000140005488:
							r14_1216 = SEQ(SEQ(r14_32_32_870, r14d_24_8_384), r14b_295);
							if (edi_278 != 0x02)
								goto l0000000140005505;
							word56 r14_56_8_874 = SEQ(r14_32_32_870, r14d_24_8_384);
							r14_1212 = SEQ(r14_56_8_874, r14b_295);
							if ((byte) (uint64) (word32) (SEQ(rcx_56_8_287, bLoc0138) - 0x41) <= r14b_295)
								goto l0000000140005509;
							r14_1212 = SEQ(r14_56_8_874, r14b_295);
							if (bLoc0138 == 0x00)
								goto l0000000140005509;
							r14_1216 = SEQ(r14_56_8_874, r14b_295);
							if (GetDiskFreeSpaceA(fp - 0x0138, fp - 0x0144, fp - 0x0148, fp - 0x013C, fp - 0x0140) == 0x00)
								goto l0000000140005505;
							Eq_6095 eax_328 = MulDiv(0x00, 0x00, 0x0400);
							r14_1216 = SEQ(r14_56_8_874, r14b_295);
							if (eax_328 == 0x00)
								goto l0000000140005505;
							r14_1216 = SEQ(r14_56_8_874, r14b_295);
							if (eax_328 < 0x00019000)
								goto l0000000140005505;
							goto l0000000140005515;
						}
						rcx_56_8_287 = SLICE(fp - 0x0138, word56, 8);
						if (GetFileAttributesA(fp - (CHAR *) 0x0138) == ~0x00)
							goto l0000000140005488;
l0000000140005515:
						word24 r14d_24_8_878 = SLICE(r14_859, word24, 8);
						byte r14b_574 = (byte) r14_859;
						word56 r14_56_8_880 = SEQ(r14_32_32_870, r14d_24_8_878);
						word128 xmm0_1224;
						if ((word32) (uint64) fn0000000140005B50(fp - 0x0138, 0x03, 0x00, out xmm0_1224) == 0x00)
						{
							r14_1216 = SEQ(SEQ(r14_32_32_870, r14d_24_8_878), r14b_574);
							if ((word32) (uint64) fn000000014000332C() == 0x00)
							{
								r14_56_8_880 = SEQ(r14_32_32_870, r14d_24_8_878);
								r14_1221 = SEQ(r14_56_8_880, r14b_574);
								word128 xmm0_1225;
								if ((word32) (uint64) fn0000000140005B50(fp - 0x0138, (uint64) r14d_1211, 0x00, out xmm0_1225) != 0x00)
									goto l000000014000554C;
							}
l0000000140005505:
							r14_1212 = r14_1216;
l0000000140005509:
							cl_565 = bLoc0138 + (byte) r14_1212;
							bLoc0138 = cl_565;
							r14_859 = r14_1212;
						}
						else
						{
l000000014000554C:
							if ((word32) (uint64) fn000000014000332C() != 0x00)
								GetWindowsDirectoryA(fp - 0x0138, 0x0104);
							word32 eax_456;
							fn000000014000887C(fp - 0x0138, 0x0104, 0x140009A10);
							Eq_126 eax_451 = GetFileAttributesA(fp - 0x0138);
							if (eax_451 == ~0x00)
								eax_465 = CreateDirectoryA(fp - 0x0138, null);
							else
								eax_456 = (word32) (uint64) (eax_451 & 0x10);
							r14_886 = SEQ(r14_56_8_884, r14b_574);
							if (eax_466 == 0x00)
							{
								cl_575 = bLoc0138_945 + r14b_574;
								bLoc0138_960 = cl_575;
							}
							else
							{
								SetFileAttributesA(fp - 0x0138, 0x02);
								uint64 rdx_484 = 0x0104;
								ptr64 r8_492 = fp - 0x0138 - 0x14000D610;
								ptr64 rcx_494 = 0x14000D610;
								do
								{
									word32 r14d_519 = (word32) r14_886;
									if (rdx_495 == 0x7FFFFEFA)
										break;
									byte al_503 = rcx_501[r8_492];
									if (al_503 == 0x00)
										break;
									*rcx_501 = al_503;
									rcx_509 = rcx_501 + r14_886;
									rdx_510 = rdx_495 - r14_886;
								} while (rdx_510 != 0x00);
								word64 rax_517 = rcx_516 - 0x01;
								word32 edx_544 = (word32) (uint64) r14d_519;
								if (rdx_513 != 0x00)
									rax_523 = rcx_516;
								*rax_541 = 0x00;
								r14_890 = r14_886;
								if ((word32) (uint64) fn00000001400041EC(0x14000D610, edx_544, 0x00, out xmm0_552) != 0x00)
									goto l0000000140005667;
								cl_565 = bLoc0138_945;
							}
						}
						r14_32_32_870 = SLICE(r14_859, word32, 32);
					} while (cl_565 <= 0x5A);
				}
				GetWindowsDirectoryA(fp - 0x0138, 0x0104);
			} while ((word32) (uint64) fn0000000140005B50(fp - 0x0138, 0x03, 0x04, out xmm0_1205) != 0x00);
l00000001400052A7:
			goto l0000000140005692;
		}
l0000000140005667:
l0000000140005692:
		word64 rax_807 = fn00000001400013E0(rax_24 ^ fp - 0x0178);
		xmm0Out = xmm0_1205;
		return (word32) rax_807;
	}
	word32 r8d_647;
	if (al_95 == 0x5C)
	{
		r8d_647 = 0x00;
		if (g_b4000CE1F == al_95)
		{
l0000000140005356:
			if ((word32) (uint64) fn00000001400041EC(0x14000CE1E, 0x00, r8d_647, out xmm0_1205) == 0x00)
			{
				fn00000001400061E8(null, 1214, 0x00, null, 0x10, 0x00, out xmm0_1205);
				goto l00000001400052A7;
			}
			goto l0000000140005667;
		}
	}
	r8d_647 = 0x01;
	goto l0000000140005356;
}

// 00000001400056C8: Register word32 fn00000001400056C8()
// Called from:
//      fn00000001400046E8
word32 fn00000001400056C8()
{
	uint64 rax_104;
	uint64 rax_19 = (uint64) fn0000000140005140(0x1400099D8, 0x00, 0x00);
	Eq_225 rax_34 = LocalAlloc(0x40, (uint64) (word32) (rax_19 + 0x01));
	word32 ebx_39 = (word32) (uint64) (word32) rax_19;
	ui32 eax_135 = (word32) rax_34;
	if (rax_34 == 0x00)
	{
		word128 xmm0_230;
		fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, dwLoc10 & eax_135, out xmm0_230);
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		goto l00000001400057F9;
	}
	ui32 eax_54 = (word32) (uint64) fn0000000140005140(0x1400099D8, rax_34, (word32) (uint64) ebx_39);
	if (eax_54 != 0x00)
	{
		if (lstrcmpA(rax_34, 0x140009918) == 0x00)
			LocalFree(rax_34);
		else
		{
			word128 xmm0_232;
			word32 ebx_93 = (word32) (uint64) (word32) (uint64) fn00000001400061E8(null, 1001, rax_34, null, 0x20, 0x04, out xmm0_232);
			LocalFree(rax_34);
			if (ebx_93 != 0x06)
			{
				g_dw4000D544 = 0x800704C7;
l00000001400057F9:
				rax_104 = 0x00;
				return (word32) rax_104;
			}
			g_dw4000D544 = 0x00;
		}
		rax_104 = 0x01;
		return (word32) rax_104;
	}
	else
	{
		word128 xmm0_231;
		fn00000001400061E8(null, 1201, 0x00, null, 0x10, dwLoc10 & eax_54, out xmm0_231);
		LocalFree(rax_34);
		g_dw4000D544 = 0x80070714;
		goto l00000001400057F9;
	}
}

// 0000000140005810: Register word32 fn0000000140005810(Register Eq_265 rcx, Register Eq_225 rdx, Register out Eq_480 siOut)
// Called from:
//      fn0000000140007FE4
word32 fn0000000140005810(Eq_265 rcx, Eq_225 rdx, union Eq_480 & siOut)
{
	Eq_405 rdx_354;
	g_t4000DE70 = rcx;
	memset(0x14000D560, 0x00, 0x0910);
	memset(0x14000CD00, 0x00, 0x032C);
	memset(0x14000CBA0, 0x00, 0x0104);
	g_dw4000D818 = 0x01;
	struct Eq_6373 * rsp_16 = fp - 0x0168;
	Eq_1054 ebx_228 = 0x00;
	if ((word32) (uint64) ((word32) (uint64) fn0000000140005140(0x1400098C4, 5368763768, 0x7F) - 0x01) > 0x7F)
	{
		rdx_354.u0 = 1201;
		goto l0000000140005B09;
	}
	Eq_384 rax_85 = CreateEventA(null, 0x01, 0x01, 0x00);
	g_t4000C838 = rax_85;
	SetEvent(rax_85);
	if ((word32) (uint64) fn0000000140005140(0x1400098D0, 0x14000DE64, 0x04) == 0x00)
	{
l0000000140005901:
		word128 xmm0_572;
		fn00000001400061E8(null, 1201, 0x00, null, 0x10, 0x00, out xmm0_572);
		g_dw4000D544 = 0x80070714;
		goto l0000000140005B1D;
	}
	ci8 al_109 = (byte) (uint64) g_t4000DE64;
	if ((al_109 & 0x40) != 0x00 || al_109 < 0x00)
	{
		if ((word32) (uint64) fn0000000140005140(0x1400098E0, fp - 0x0138, 0x0104) == 0x00)
			goto l0000000140005901;
		Eq_384 rax_141 = CreateMutexA(null, 0x01, fp - 0x0138);
		g_t4000C830 = rax_141;
		if (rax_141 != null && GetLastError() == 0xB7)
		{
			if ((g_t4000DE64 & 0x80) != 0x00)
			{
				word128 xmm0_574;
				fn00000001400061E8(null, 1355, 5368763768, null, 0x10, 0x00, out xmm0_574);
			}
			else
			{
				word128 xmm0_573;
				if ((word32) (uint64) fn00000001400061E8(null, 1316, 5368763768, null, 0x20, 0x04, out xmm0_573) == 0x06)
					goto l0000000140005A02;
			}
			CloseHandle(g_t4000C830);
			g_dw4000D544 = 0x800700B7;
			goto l0000000140005B1D;
		}
	}
l0000000140005A02:
	g_t4000D540.u0 = 0x00;
	struct Eq_6373 * r14_196 = (struct Eq_6373 *) <invalid>;
	struct Eq_6373 * rbx_199 = (struct Eq_6373 *) <invalid>;
	cup16 r14w_277 = (word16) r14_196;
	rsp_16 = (struct Eq_6373 *) <invalid>;
	byte bl_211 = (byte) rbx_199;
	ebx_228 = (word32) rbx_199;
	byte r14b_284 = (byte) r14w_277;
	Eq_265 rdi_200;
	word16 r14w_571;
	word32 ebx_570;
	Eq_225 rsi_201;
	if ((word32) (uint64) fn0000000140006768(rdx, out ebx_570, out rsi_201, out rdi_200, out r14w_571) == 0x00)
	{
		rdx_354.u0 = 0x0520;
l0000000140005B09:
		rsp_16->t0028 = ebx_228;
		rsp_16->t0020.u0 = 0x10;
		word128 xmm0_575;
		fn00000001400061E8(null, rdx_354, 0x00, null, rsp_16->t0020, rsp_16->t0028, out xmm0_575);
		goto l0000000140005B1D;
	}
	if (g_b4000CD1A != bl_211)
	{
		fn00000001400026B8(0x14000CD1A);
		goto l0000000140005B1D;
	}
	Eq_5369 rdx_216 = &g_t400098F0;
	Eq_5369 rax_218 = FindResourceA(rdi_200, 0x1400098F0, 0x0A);
	if (rax_218 != null)
	{
		rdx_216 = rax_218;
		rsi_201 = LoadResource(rdi_200, rax_218);
	}
	if (g_t4000C1AC != ebx_228)
	{
		word64 r10_248;
		COMCTL32.dll!Ordinal_17();
	}
	if (g_t4000CD04 == ebx_228)
	{
		if ((word32) (uint64) fn0000000140003DF0(rsi_201) == 0x00)
		{
l0000000140005B1D:
			goto l0000000140005B1F;
		}
		if ((word16) (uint64) (word32) g_w4000DE78 - r14w_277 <= 0x02 && ((g_t4000DE64 & 0x0100) != 0x00 && ((g_t4000CD18 & r14b_284) == 0x00 && (word32) ((uint64) fn0000000140003118()) == 0x00)))
		{
			rsp_16->t0028.u1 = 2110;
			rsp_16->t0020.u0 = 1351;
			word128 xmm0_576;
			fn00000001400064B0(2006, null, &g_t400036F0, rsp_16->t0020, out xmm0_576);
l0000000140005B1F:
			word64 rax_459 = fn00000001400013E0(rsp_16->qw0140 ^ rsp_16);
			siOut.u0 = <invalid>;
			return (word32) rax_459;
		}
	}
	goto l0000000140005B1F;
}

// 0000000140005B50: Register word32 fn0000000140005B50(Register Eq_225 rcx, Register Eq_4601 edx, Register word32 r8d, Register out Eq_4603 xmm0Out)
// Called from:
//      fn00000001400041EC
//      fn00000001400046E8
//      fn000000014000521C
//      fn00000001400078B0
word32 fn0000000140005B50(Eq_225 rcx, Eq_4601 edx, word32 r8d, union Eq_4603 & xmm0Out)
{
	Eq_4601 edx = (word32) rdx;
	word32 r15d_254 = (word32) (uint64) edx;
	ui64 rax_28 = g_qw4000C008 ^ fp - 0x03A8;
	word32 r12d_339 = (word32) (uint64) r8d;
	byte r15b_268 = (byte) r15d_254;
	if (edx == 0x00)
	{
l0000000140005E9E:
		word64 rax_507 = fn00000001400013E0(rax_28 ^ fp - 0x03A8);
		xmm0Out = xmm0;
		return (word32) rax_507;
	}
	GetCurrentDirectoryA(0x0104, fp - 0x0348);
	if (SetCurrentDirectoryA(rcx) == 0x00)
	{
		fn00000001400061E8(null, 1212, 0x00, null, 0x10, 0x00, out xmm0);
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		goto l0000000140005E9C;
	}
	Eq_405 rdx_126;
	if (GetDiskFreeSpaceA(0x00, fp - 868, fp - 0x0368, fp - 0x0360, fp - 0x035C) != 0x00)
	{
		Eq_6095 eax_80 = MulDiv(0x00, 0x00, 0x0400);
		up32 esi_280 = (word32) (uint64) eax_80;
		if (eax_80 != 0x00)
		{
			if (GetVolumeInformationA(0x00, 0x00, 0x00, 0x00, fp - 0x0354, fp - 0x0358, 0x00, 0x00) != 0x00)
			{
				SetCurrentDirectoryA(fp - 0x0348);
				uint64 r8_148 = 0x06;
				byte * rdx_150 = fp - 848;
				int64 rdi_151 = rcx - (fp - (CHAR *) 848);
				while (r8_148 != 0x04)
				{
					byte al_163 = rdx_150[rdi_151];
					if (al_163 == 0x00)
						break;
					*rdx_150 = al_163;
					++rdx_150;
					--r8_148;
					if (r8_148 == 0x00)
						break;
				}
				byte * rax_177 = rdx_150 - 0x01;
				ui32 ebx_196 = 0x0200;
				if (r8_148 != 0x00)
					rax_177 = rdx_150;
				*rax_177 = 0x00;
				cup16 ax_201;
				for (ax_201 = 0x00; ax_201 < 0x08; ++ax_201)
				{
					if (ebx_196 == 0x00)
						goto l0000000140005D8C;
					ebx_196 = (word32) (uint64) (ebx_196 * 0x02);
				}
				if (ax_201 != 0x08)
				{
l0000000140005D8C:
					uint64 r8_222;
					uint64 rdx_229;
					if ((g_t4000DE64 & 0x08) != 0x00 && (dwLoc0358 & 0x8000) != 0x00)
					{
						rdx_229 = (uint64) ((word32) (uint64) g_a4000CCC0[(uint64) (word32) ax_201 * 0x04] * 0x02);
						r8_222 = (uint64) ((word32) (uint64) ((word32) (uint64) g_dw4000DE68 >> 0x02) + g_dw4000DE68);
					}
					else
					{
						r8_222 = (uint64) g_dw4000DE68;
						rdx_229 = (uint64) g_a4000CCC0[(uint64) (word32) ax_201 * 0x04];
					}
					bool v82_539;
					up32 edx_283 = (word32) rdx_229;
					up32 r8d_272 = (word32) r8_222;
					if ((byte) (uint64) ((word32) (uint64) r15d_254 & 0x03) == 0x03)
						v82_539 = (word32) (uint64) (word32) (r8_222 + rdx_229) <= esi_280;
					else if ((r15b_268 & 0x01) != 0x00)
						v82_539 = edx_283 <= esi_280;
					else
						v82_539 = r8d_272 <= esi_280;
					if (!v82_539)
						xmm0 = fn00000001400028B8((uint64) r12d_339, fp - (CHAR *) 848);
					else
						g_dw4000D544 = 0x00;
					goto l0000000140005E9E;
				}
				fn00000001400061E8(null, 1221, 0x00, null, 0x10, 0x00, out xmm0);
l0000000140005E9C:
				goto l0000000140005E9E;
			}
			memset(fp - (CHAR *) 0x0238, 0x00, 0x0200);
			g_dw4000D544 = (word32) (uint64) fn0000000140006590();
			FormatMessageA(0x1000, 0x00, (uint64) GetLastError(), 0x00, fp - (CHAR *) 0x0238, 0x0200, null);
			rdx_126.u0 = 0x04F9;
l0000000140005E70:
			fn00000001400061E8(null, rdx_126, rcx, fp - (CHAR *) 0x0238, 0x10, 0x00, out xmm0);
			SetCurrentDirectoryA(fp - (CHAR *) 0x0348);
			goto l0000000140005E9C;
		}
	}
	memset(fp - 0x0238, 0x00, 0x0200);
	g_dw4000D544 = (word32) (uint64) fn0000000140006590();
	FormatMessageA(0x1000, 0x00, (uint64) GetLastError(), 0x00, fp - 0x0238, 0x0200, null);
	rdx_126.u0 = 0x04B0;
	goto l0000000140005E70;
}

// 0000000140005ED8: Register word32 fn0000000140005ED8(Register Eq_225 rcx, Register out Eq_4655 xmm0Out)
// Called from:
//      fn00000001400041EC
//      fn00000001400078B0
word32 fn0000000140005ED8(Eq_225 rcx, union Eq_4655 & xmm0Out)
{
	ptr64 rdi_15 = ~0x00;
	do
	{
		++rdi_15;
		word32 edi_24 = (word32) rdi_15;
	} while (*((word128) rcx + rdi_15) != 0x00);
	uint64 rax_145;
	word32 edi_29 = (word32) (uint64) (edi_24 + 0x14);
	Eq_225 rax_34 = LocalAlloc(0x40, (uint64) edi_29);
	uint64 rbx_33 = (uint64) edi_29;
	ui32 eax_146 = (word32) rax_34;
	if (rax_34 == 0x00)
		fn00000001400061E8(null, 0x04B5, 0x00, null, 0x10, dwLoc20 & eax_146, out xmm0);
	else
	{
		if (edi_29 != 0x00)
		{
			Eq_225 rax_74;
			rax_74 = rax_34;
			if (rbx_33 <= 0x7FFFFFFF)
			{
				uint64 rdx_48 = 0x7FFFFFFE - rbx_33;
				Eq_225 rcx_49 = rax_34;
				int64 r8_50 = rcx - rax_34;
				while (rdx_48 + rbx_33 != 0x00)
				{
					byte al_61 = *((word128) rcx_49 + r8_50);
					if (al_61 == 0x00)
						break;
					*rcx_49 = al_61;
					++rcx_49;
					--rbx_33;
					if (rbx_33 == 0x00)
						break;
				}
				rax_74 = rcx_49 - 0x01;
				if (rbx_33 != 0x00)
					rax_74 = rcx_49;
			}
			*rax_74 = 0x00;
		}
		fn000000014000887C(rax_34, (uint64) edi_29, 0x140009A20);
		Eq_384 rax_120 = CreateFileA(rax_34, 0x40000000, 0x00, null, 0x01, 0x04000080, null);
		LocalFree(rax_34);
		if (rax_120 != (void *) ~0x00)
		{
			CloseHandle(rax_120);
			Eq_126 eax_133 = GetFileAttributesA(rcx);
			byte al_136 = (byte) eax_133;
			if (eax_133 != ~0x00 && (al_136 & 0x10) != 0x00)
			{
				g_dw4000D544 = 0x00;
				rax_145 = 0x01;
l0000000140005F47:
				xmm0Out = xmm0;
				return (word32) rax_145;
			}
		}
	}
	g_dw4000D544 = (word32) (uint64) fn0000000140006590();
	rax_145 = 0x00;
	goto l0000000140005F47;
}

// 0000000140006050: void fn0000000140006050(Register word32 rax_32_32, Register Eq_1049 rcx, Register word32 edx, Register word64 r8)
void fn0000000140006050(word32 rax_32_32, Eq_1049 rcx, word32 edx, word64 r8)
{
	word32 edx_12 = (word32) (uint64) (edx - 0x0F);
	if (edx_12 == 0x00)
	{
		if (g_dw4000C840 == 0x00)
		{
			SendDlgItemMessageA(rcx, 2100, 177, ~0x00, 0);
			g_dw4000C840 = 0x01;
		}
		return;
	}
	Eq_3409 rdx_103;
	word32 edx_32 = (word32) (uint64) (edx_12 - 0x01);
	if (edx_32 != 0x00)
	{
		word32 edx_37 = (word32) (uint64) (edx_32 - 0x0100);
		if (edx_37 == 0x00)
		{
			word64 r9_46 = fn0000000140003C8C(rcx, SEQ(rax_32_32, GetDesktopWindow()));
			Eq_225 r8_54 = g_t4000D030;
			SetDlgItemTextA(rcx, 2100, r8_54);
			SetWindowTextA(rcx, 5368763768);
			SetForegroundWindow(rcx);
			Eq_1049 rax_67 = GetDlgItem(rcx, 2100);
			word64 r9_75;
			Eq_7140 rax_76;
			USER32.dll!GetWindowLongPtrA();
			g_t4000CB90 = rax_76;
			USER32.dll!SetWindowLongPtrA();
			return;
		}
		if (edx_37 != 0x01)
			return;
		if (r8 == 0x06)
		{
			rdx_103.u1 = (uint64) (word32) (r8 - 0x05);
l0000000140006090:
			EndDialog(rcx, rdx_103);
			return;
		}
		if (r8 != 0x07)
			return;
	}
	rdx_103.u1 = 0x00;
	goto l0000000140006090;
}

// 00000001400061A0: void fn00000001400061A0(Register Eq_1049 rcx, Register word32 edx, Register Eq_3612 r8, Register word64 r9)
void fn00000001400061A0(Eq_1049 rcx, word32 edx, Eq_3612 r8, word64 r9)
{
	word32 edx = (word32) rdx;
	if (edx != 177 || (r8 != 0x00 || r9 != ~0x01))
		CallWindowProcA(g_t4000CB90, rcx, (uint64) edx, r8, (LPARAM) r9);
}

// 00000001400061E8: Register word32 fn00000001400061E8(Register Eq_1049 rcx, Register Eq_405 rdx, Register Eq_225 r8, Register Eq_1052 r9, Stack Eq_1053 dwArg28, Stack Eq_1054 dwArg30, Register out Eq_1055 xmm0Out)
// Called from:
//      fn0000000140001A08
//      fn0000000140001D28
//      fn00000001400028B8
//      fn00000001400029DC
//      fn000000014000332C
//      fn00000001400033BC
//      fn00000001400037DC
//      fn0000000140003950
//      fn0000000140003DF0
//      fn0000000140004598
//      fn00000001400046E8
//      fn00000001400049A0
//      fn0000000140004BE0
//      fn0000000140004E34
//      fn0000000140004F18
//      fn000000014000521C
//      fn00000001400056C8
//      fn0000000140005810
//      fn0000000140005B50
//      fn0000000140005ED8
//      fn00000001400064B0
//      fn0000000140007010
//      fn000000014000721C
//      fn00000001400078B0
//      fn0000000140007FE4
//      fn0000000140008400
word32 fn00000001400061E8(Eq_1049 rcx, Eq_405 rdx, Eq_225 r8, Eq_1052 r9, Eq_1053 dwArg28, Eq_1054 dwArg30, union Eq_1055 & xmm0Out)
{
	ui64 rax_27 = g_qw4000C008 ^ fp - 696;
	Eq_1055 xmm0_46 = g_t40009998;
	if ((g_t4000CD18 & 0x01) != 0x00)
	{
l0000000140006485:
		word64 rax_386 = fn00000001400013E0(rax_27 ^ fp - 696);
		xmm0Out = xmm0_46;
		return (word32) rax_386;
	}
	LoadStringA(g_t4000DE70, rdx, fp - 0x0248, 0x0200);
	if (true)
	{
		Eq_405 r9_341;
		if ((word32) (uint64) fn0000000140008BB4() != 0x00)
		{
			r9_341.u0 = 0x00190010;
			if ((word32) (uint64) fn0000000140008AE4() != 0x00)
			{
l00000001400062A9:
				MessageBoxA(rcx, fp - 0x0288, 5368763768, r9_341);
				goto l0000000140006485;
			}
		}
		r9_341.u0 = 0x00010010;
		goto l00000001400062A9;
	}
	Eq_225 rdi_151;
	int64 rax_167 = ~0x00;
	if (r9 == null)
	{
		do
		{
			++rax_167;
			word32 eax_77 = (word32) rax_167;
		} while ((&(&(&(&(&(&(&(&(&(&(&(&(&(&(&(&(&(&(&(fp - 0x0248)[rax_167].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0].a0000)[0] != 0x00);
		if (r8 != 0x00)
		{
			int64 rcx_133 = ~0x00;
			do
				++rcx_133;
			while (*((word128) r8 + rcx_133) != 0x00);
			word32 eax_145 = (word32) (rax_167 + 100 + rcx_133);
			Eq_225 rax_150 = LocalAlloc(0x40, (uint64) eax_145);
			word32 r14d_158 = (word32) (uint64) eax_145;
			rdi_151 = rax_150;
			if (rax_150 == 0x00)
			{
l00000001400063C1:
				goto l0000000140006485;
			}
			fn000000014000366C(rax_150, (uint64) r14d_158, fp - 0x0248);
		}
		else
		{
			word32 eax_82 = (word32) (uint64) (eax_77 + 0x01);
			Eq_225 rax_127 = LocalAlloc(0x40, (uint64) eax_82);
			uint64 rsi_106 = (uint64) eax_82;
			rdi_151 = rax_127;
			if (rax_127 == 0x00)
				goto l00000001400063C1;
			if (rsi_106 != 0x00)
			{
				if (rsi_106 <= 0x7FFFFFFF)
				{
					uint64 rdx_101 = 0x7FFFFFFE - rsi_106;
					Eq_225 rcx_102 = rax_127;
					int64 r8_103 = fp - 0x0248 - rax_127;
					while (rdx_101 + rsi_106 != 0x00)
					{
						byte al_114 = *((word128) rcx_102 + r8_103);
						if (al_114 == 0x00)
							break;
						*rcx_102 = al_114;
						++rcx_102;
						--rsi_106;
						if (rsi_106 == 0x00)
							break;
					}
					rax_127 = rcx_102 - 0x01;
					if (rsi_106 != 0x00)
						rax_127 = rcx_102;
				}
				*rax_127 = 0x00;
			}
		}
l0000000140006413:
		ui32 r9d_270;
		MessageBeep((uint64) dwArg28);
		if ((word32) (uint64) fn0000000140008BB4() != 0x00)
		{
			r9d_270 = 0x00190000;
			if ((word32) (uint64) fn0000000140008AE4() != 0x00)
			{
l0000000140006443:
				MessageBoxA(rcx, rdi_151, 5368763768, (uint64) ((word32) (uint64) (r9d_270 | dwArg28) | dwArg30));
				LocalFree(rdi_151);
				goto l00000001400063C1;
			}
		}
		r9d_270 = 0x00010000;
		goto l0000000140006443;
	}
	else
	{
		do
			++rax_167;
		while (r9[rax_167] != 0x00);
		int64 rcx_174 = ~0x00;
		do
			++rcx_174;
		while (*((word128) r8 + rcx_174) != 0x00);
		int64 rax_182 = rax_167 + rcx_174;
		int64 rcx_188 = ~0x00;
		do
			++rcx_188;
		while (fp - 0x0248 + rcx_188 != 0x00);
		word32 eax_200 = (word32) (rax_182 + 100 + rcx_188);
		Eq_225 rax_205 = LocalAlloc(0x40, (uint64) eax_200);
		word32 r15d_217 = (word32) (uint64) eax_200;
		rdi_151 = rax_205;
		if (rax_205 != 0x00)
		{
			fn000000014000366C(rax_205, (uint64) r15d_217, fp - 0x0248);
			goto l0000000140006413;
		}
		goto l00000001400063C1;
	}
}

// 00000001400064B0: Register word64 fn00000001400064B0(Register Eq_225 rdx, Register Eq_1049 r8, Register Eq_4437 r9, Stack Eq_1053 qwArg28, Register out Eq_4439 xmm0Out)
// Called from:
//      fn0000000140004140
//      fn0000000140004598
//      fn00000001400046E8
//      fn000000014000521C
//      fn0000000140005810
word64 fn00000001400064B0(Eq_225 rdx, Eq_1049 r8, Eq_4437 r9, Eq_1053 qwArg28, union Eq_4439 & xmm0Out)
{
	word64 rbx_58;
	Eq_265 rbx_13 = g_t4000DE70;
	Eq_5369 rax_22 = FindResourceA(rbx_13, rdx, 0x05);
	if (rax_22 != null)
	{
		Eq_225 rax_28 = LoadResource(rbx_13, rax_22);
		if (rax_28 != 0x00)
		{
			Eq_1053 tLoc18_111;
			word32 rax_32_32_56 = SLICE(qwArg28, word32, 32);
			if (qwArg28 == 0x00)
				tLoc18_111 = (LPARAM) (qwLoc18 & qwArg28);
			else
				tLoc18_111 = (LPARAM) qwArg28;
			word64 rax_57 = SEQ(rax_32_32_56, DialogBoxIndirectParamA(rbx_13, rax_28, r8, r9, tLoc18_111));
			FreeResource(rax_28);
			rbx_58 = rax_57;
			if (rax_57 != ~0x00)
			{
l000000014000656F:
				xmm0Out = xmm0;
				return rbx_58;
			}
		}
	}
	fn00000001400061E8(null, 0x04FB, 0x00, null, 16, 0x00, out xmm0);
	rbx_58 = qwArg30;
	goto l000000014000656F;
}

// 0000000140006590: Register word32 fn0000000140006590()
// Called from:
//      fn00000001400041EC
//      fn0000000140004598
//      fn00000001400046E8
//      fn000000014000521C
//      fn00000001400056C8
//      fn0000000140005B50
//      fn0000000140005ED8
//      fn0000000140007010
//      fn000000014000721C
word32 fn0000000140006590()
{
	Eq_126 eax_4 = GetLastError();
	word16 ax_7 = (word16) eax_4;
	uint64 rax_12 = SEQ(rax_32_32, eax_4);
	if (eax_4 > 0x00)
		rax_12 = (uint64) ((word32) (uint64) (word32) ax_7 | 0x80070000);
	return (word32) rax_12;
}

// 00000001400065B8: Register word64 fn00000001400065B8()
// Called from:
//      fn000000014000721C
word64 fn00000001400065B8()
{
	ui64 rax_6 = g_qw4000C008 ^ fp - (CHAR *) 0x0148;
	uint64 r8_14 = 0x0104;
	int64 r9_15 = 0x14000D610 - (fp - (CHAR *) 0x0128);
	Eq_7502 rcx_17 = fp - (CHAR *) 0x0128;
	while (r8_14 != 0x7FFFFEFA)
	{
		byte al_26 = rcx_17[r9_15];
		if (al_26 == 0x00)
			break;
		*rcx_17 = al_26;
		++rcx_17;
		--r8_14;
		if (r8_14 == 0x00)
			break;
	}
	Eq_7502 rax_39 = rcx_17 - (CHAR *) 0x01;
	if (r8_14 != 0x00)
		rax_39 = rcx_17;
	*rax_39 = 0x00;
	fn000000014000887C(fp - (CHAR *) 0x0128, 0x0104, 0x140009818);
	Eq_126 eax_65 = GetFileAttributesA(fp - (CHAR *) 0x0128);
	byte al_68 = (byte) eax_65;
	if (eax_65 != ~0x00 && (al_68 & 0x10) == 0x00)
		LoadLibraryExA(fp - (CHAR *) 0x0128, null, 0x08);
	else
		LoadLibraryA(0x140009818);
	return fn00000001400013E0(rax_6 ^ fp - (CHAR *) 0x0148);
}

// 00000001400066A0: void fn00000001400066A0(Register word32 rax_32_32, Register Eq_1049 rcx, Register word32 edx, Register Eq_3409 r8)
void fn00000001400066A0(word32 rax_32_32, Eq_1049 rcx, word32 edx, Eq_3409 r8)
{
	Eq_3409 rdx_16;
	word32 edx_12 = (word32) (uint64) (edx - 0x10);
	if (edx_12 != 0x00)
	{
		word32 edx_19 = (word32) (uint64) (edx_12 - 0x0100);
		if (edx_19 == 0x00)
		{
			fn0000000140003C8C(rcx, SEQ(rax_32_32, GetDesktopWindow()));
			SetWindowTextA(rcx, 5368763768);
			SetDlgItemTextA(rcx, 0x0838, g_t4000D830);
			SetForegroundWindow(rcx);
			return;
		}
		if (edx_19 != 0x01)
			return;
		if (r8 != 0x06 && r8 != 0x07)
		{
			if (r8 != 0x0839)
				return;
			g_dw4000D600 = 0x01;
		}
		rdx_16 = r8;
	}
	else
		rdx_16.u1 = 0x02;
	EndDialog(rcx, rdx_16);
}

// 0000000140006768: Register word32 fn0000000140006768(Register Eq_225 rcx, Register out Eq_480 ebxOut, Register out Eq_6460 rsiOut, Register out Eq_6461 rdiOut, Register out Eq_480 r14wOut)
// Called from:
//      fn0000000140005810
word32 fn0000000140006768(Eq_225 rcx, union Eq_480 & ebxOut, union Eq_6460 & rsiOut, union Eq_6461 & rdiOut, union Eq_480 & r14wOut)
{
	ui64 rax_27 = g_qw4000C008 ^ fp - 0x0188;
	Eq_225 r14_1179 = rcx;
	if (rcx != 0x00 && *rcx != 0x00)
	{
		Eq_6461 rdi_1294 = 0x02;
		Eq_225 rbx_1007 = 0x14000CE1E;
		Eq_6460 rsi_2180 = 0x01;
		do
		{
			byte bh_1413 = SLICE(rbx_1007, byte, 8);
			if ((word32) rsi_2180 == 0x00)
				break;
			while (true)
			{
				byte bLoc0145_1472 = (byte) qwLoc0145;
				if (*r14_1179 != 0x20 && *r14_1179 > 0x0D)
					break;
				r14_1179 = CharNextA(r14_1179);
			}
			if (*r14_1179 == 0x00)
				break;
			uint8 * rcx_113 = null;
			word32 r8d_1250 = 0x00;
			uint64 r9_138 = 0x00;
			up32 edx_101 = 0x01;
			do
			{
				Eq_4245 di_543 = (word16) rdi_1294;
				word32 r9d_83 = (word32) r9_138;
				if (r8d_1250 == 0x00)
				{
					uint8 al_89 = *r14_1179;
					if (al_89 == 0x20 || al_89 <= 0x0D)
						break;
				}
				else if (r9d_83 != 0x00)
					break;
				Eq_6461 rax_132;
				uint8 al_97 = *r14_1179;
				if (al_97 == 0x22)
				{
					if (*((word128) r14_1179 + 1) != al_97)
					{
						if (r8d_1250 == 0x00)
							r8d_1250 = 0x01;
						else
							r9_138 = 0x01;
						goto l000000014000686E;
					}
					if (edx_101 >= 0x0104)
						goto l0000000140006C68;
					Mem126[fp - 0x0148 + rcx_113:byte] = 0x22;
					edx_101 = (word32) (uint64) (edx_101 + 0x01);
					++rcx_113;
					rax_132 = rdi_1294;
				}
				else
				{
					if (edx_101 >= 0x0104)
						goto l0000000140006C68;
					Mem114[fp - 0x0148 + rcx_113:byte] = al_97;
					edx_101 = (word32) (uint64) (edx_101 + 0x01);
					++rcx_113;
l000000014000686E:
					&rax_132.u0->b0000 = 0x01;
				}
				r14_1179 += rax_132;
			} while (*r14_1179 != 0x00);
			word32 r9d_244 = (word32) r9_138;
			if (rcx_113 >= (uint8 *) 0x0104)
			{
				struct Eq_6373 * rcx_176 = (struct Eq_6373 *) <invalid>;
				int16 * rax_175;
				word32 ecx_2220;
				bool O_181 = fn00000001400015B8(out rax_175, out ecx_2220);
				int3();
				int3();
				int3();
				int3();
				int3();
				int3();
				int3();
				word32 ecx_211 = (word32) rcx_176;
				if (!O_181)
				{
					*Top = (real64) *rax_175 / *Top;
					*rdi_1294 = *rdi_1294 ^ bh_1413;
					word32 r11d_219 = (word32) (uint64) ecx_211;
					word32 ebx_2221;
					uint64 rax_224 = (uint64) fn0000000140006E0A(0x08, 0x0200, g_a4000CCC0, r11d_219, out ebx_2221);
					ebxOut.u0 = <invalid>;
					rsiOut = rsi_2180;
					rdiOut = rdi_1294;
					r14wOut.u0 = <invalid>;
					return (word32) rax_224;
				}
				goto l0000000140006D95;
			}
			Mem236[fp - 0x0148 + rcx_113:byte] = 0x00;
			if (r8d_1250 != 0x00)
			{
				if (r9d_244 == 0x00)
					goto l0000000140006891;
			}
			else if (r9d_244 != 0x00)
			{
l0000000140006891:
				break;
			}
			int32 edi_572 = (word32) rdi_1294;
			if ((bLoc0148 - 0x2D & ~0x02) != 0x00)
			{
l0000000140006C68:
				goto l0000000140006DAE;
			}
			word32 ecx_268 = (word32) (uint64) ((int32) (byte) CharUpperA((int64) bLoc0147) - 0x3F);
			if (ecx_268 == 0x00)
			{
				fn00000001400029DC();
				Eq_384 rcx_283 = g_t4000C830;
				if (rcx_283 != null)
					CloseHandle(rcx_283);
l0000000140006D95:
				ExitProcess(0x00);
			}
			word32 ecx_295 = (word32) (uint64) (ecx_268 - 0x04);
			if (ecx_295 != 0x00)
			{
				word32 ecx_471 = (word32) (uint64) (ecx_295 - 0x01);
				if (ecx_471 != 0x00)
				{
					word32 ecx_476 = (word32) (uint64) (ecx_471 - 0x0A);
					if (ecx_476 != 0x00)
					{
						word32 ecx_521 = (word32) (uint64) (ecx_476 - 0x03);
						if (ecx_521 != 0x00)
						{
							int32 ecx_547 = (word32) (uint64) (ecx_521 - 0x01);
							if (ecx_547 != 0x00)
							{
								if (ecx_547 != edi_572)
									goto l0000000140006947;
								goto l0000000140006B03;
							}
							if (bLoc0146 == 0x00)
							{
								g_dw4000DE5C = 0x03;
								g_dw4000CD08 = 0x01;
								goto l000000014000694A;
							}
							if (bLoc0146 == 0x3A)
							{
								g_dw4000DE5C = 0x01;
								byte al_577 = (byte) qwLoc0145;
								if (al_577 == 0x00)
									goto l000000014000694A;
								byte * rbx_581 = fp - 0x0145;
								do
								{
									ui32 edi_592 = (word32) rdi_1294;
									byte al_588 = (byte) CharUpperA((int64) al_577);
									++rbx_581;
									if (al_588 != 0x41)
									{
										if (al_588 != 0x44)
										{
											if (al_588 != 0x49)
											{
												if (al_588 != 0x4E)
												{
													if (al_588 != 0x50)
													{
														if (al_588 != 0x53)
														{
															rsi_2180.u0 = 0x00;
															goto l00000001400069FB;
														}
														g_dw4000DE5C |= 0x04;
														goto l00000001400069F4;
													}
													__bts(g_dw4000D028, 0x07, out g_dw4000D028);
													goto l00000001400069FB;
												}
												g_dw4000DE5C &= ~0x01;
											}
											else
												g_dw4000DE5C &= ~0x02;
											goto l00000001400069F4;
										}
										g_dw4000D028 |= 0x40;
									}
									else
									{
										g_dw4000DE5C |= edi_592;
l00000001400069F4:
										g_dw4000CD08 = 0x01;
									}
l00000001400069FB:
									al_577 = *rbx_581;
								} while (al_577 != 0x00);
								goto l0000000140006D6C;
							}
							if (CompareStringA(0x7F, 0x01, 0x140009A30, 0xFFFFFFFF, fp - 0x0147, ~0x00) != edi_572)
								goto l0000000140006947;
							goto l000000014000694A;
						}
						if (bLoc0146 != 0x00)
						{
							if (bLoc0146 != 0x3A)
								goto l0000000140006947;
							byte al_532 = (byte) CharUpperA((int64) bLoc0145_1472);
							if (al_532 == 0x31)
								goto l0000000140006A49;
							if (al_532 == 0x41)
							{
								g_t4000CD18.u1 = 0x01;
								goto l000000014000694A;
							}
							if (al_532 != 0x55)
								goto l0000000140006947;
						}
l0000000140006A49:
						g_t4000CD18 = di_543;
						goto l000000014000694A;
					}
					if (bLoc0146 == 0x00)
					{
						g_dw4000CD0C = 0x01;
						goto l000000014000694A;
					}
					if (bLoc0146 != 0x3A)
						goto l0000000140006947;
					byte al_486 = (byte) qwLoc0145;
					if (al_486 == 0x00)
						goto l000000014000694A;
					byte * rbx_490 = fp - 0x0145;
					do
					{
						byte al_497 = (byte) CharUpperA((int64) al_486);
						++rbx_490;
						if (al_497 != 0x45)
						{
							if (al_497 != 0x47)
							{
								if (al_497 != 0x56)
									rsi_2180.u0 = 0x00;
								else
									g_dw4000CD14 = 0x01;
							}
							else
								g_dw4000CD10 = 0x01;
						}
						else
							g_dw4000CD0C = 0x01;
						al_486 = *rbx_490;
					} while (al_486 != 0x00);
					goto l0000000140006D6C;
				}
l0000000140006B03:
				if (bLoc0146 != 0x3A)
					goto l0000000140006947;
				word32 ebx_657 = (word32) (uint64) ((word32) (uint64) (0x00 - ((byte) qwLoc0145 == 0x22)) + 0x04);
				byte * rcx_660 = fp - 0x0148 + (uint64) ebx_657;
				int64 rax_661 = ~0x00;
				do
					++rax_661;
				while (rcx_660[rax_661] != 0x00);
				if (rax_661 == 0x00 || (word32) ((uint64) fn0000000140006F90(rcx_660, fp - 344)) == 0x00)
					goto l0000000140006B38;
				struct Eq_8063 * rcx_1423;
				byte dl_767;
				word64 r8_697 = 0x0104;
				word32 eax_704 = (word32) (uint64) ebx_657;
				if ((byte) CharUpperA((int64) bLoc0147) == 0x54)
				{
					byte * rdx_772 = &g_b4000CE1E;
					Eq_8090 rcx_777 = fp - 0x0148 + ((int64) ((word32) ((uint64) (eax_704 + ebx_657))) - 0x14000CE1E);
					while (r8_697 != 0x7FFFFEFA)
					{
						byte al_787 = Mem786[rcx_777 + rdx_772:byte];
						if (al_787 == 0x00)
							break;
						*rdx_772 = al_787;
						++rdx_772;
						--r8_697;
						if (r8_697 == 0x00)
							break;
					}
					byte * rax_801 = rdx_772 - 0x01;
					if (r8_697 != 0x00)
						rax_801 = rdx_772;
					*rax_801 = 0x00;
					fn000000014000887C(0x14000CE1E, 0x0104, 0x140009770);
					dl_767 = g_b4000CE1E;
					rcx_1423 = (struct Eq_8063 *) &g_b4000CE1E;
				}
				else
				{
					byte * rdx_710 = &g_b4000CD1A;
					Eq_8078 rcx_712 = fp - 0x0148 + ((int64) ((word32) ((uint64) (eax_704 + ebx_657))) - 0x14000CD1A);
					while (r8_697 != 0x7FFFFEFA)
					{
						byte al_722 = Mem721[rcx_712 + rdx_710:byte];
						if (al_722 == 0x00)
							break;
						*rdx_710 = al_722;
						++rdx_710;
						--r8_697;
						if (r8_697 == 0x00)
							break;
					}
					byte * rax_736 = rdx_710 - 0x01;
					if (r8_697 != 0x00)
						rax_736 = rdx_710;
					*rax_736 = 0x00;
					fn000000014000887C(0x14000CD1A, 0x0104, 0x140009770);
					dl_767 = g_b4000CD1A;
					rcx_1423 = (struct Eq_8063 *) &g_b4000CD1A;
				}
				rbx_1007.u0 = 0x14000CE1E;
				Eq_8141 rax_835 = ~0x00;
				do
					rax_835 = (word64) rax_835 + 1;
				while (Mem1424[rcx_1423 + rax_835:byte] != 0x00);
				if (rax_835 < 0x03)
					goto l0000000140006C68;
				byte al_847 = rcx_1423->b0001;
				if (al_847 != 0x3A && (dl_767 != 0x5C || al_847 != dl_767))
					goto l0000000140006C68;
				goto l000000014000694A;
			}
			if (bLoc0146 == 0x00)
			{
				g_t4000CD04.u0 = 0x01;
				goto l000000014000694A;
			}
			if (bLoc0146 == 0x3A)
			{
				word32 edi_315 = (word32) (uint64) ((word32) (uint64) (0x00 - ((byte) qwLoc0145 == 0x22)) + 0x04);
				byte * rbx_318 = fp - 0x0148 + (uint64) edi_315;
				int64 rax_319 = ~0x00;
				do
					++rax_319;
				while (rbx_318[rax_319] != 0x00);
				if (rax_319 == 0x00 || fn00000001400089BC(rbx_318, 0x5B) != 0x00 && fn00000001400089BC(rbx_318, 0x5D) == 0x00 || (fn00000001400089BC(rbx_318, 0x5D) != 0x00 && fn00000001400089BC(rbx_318, 0x5B) == 0x00 || (word32) ((uint64) fn0000000140006F90(rbx_318, fp - 344)) == 0x00))
				{
					&rdi_1294.u0->b0000 = 0x02;
l0000000140006B38:
					rbx_1007.u0 = 0x14000CE1E;
					goto l0000000140006947;
				}
				word64 r8_423 = 0x0104;
				byte * rdx_425 = &g_b4000CF22;
				Eq_8271 rcx_426 = fp - 0x0148 + ((int64) ((word32) ((uint64) ((word32) ((uint64) edi_315) + edi_315))) - 0x14000CF22);
				while (r8_423 != 0x7FFFFEFA)
				{
					byte al_436 = Mem435[rcx_426 + rdx_425:byte];
					if (al_436 == 0x00)
						break;
					*rdx_425 = al_436;
					++rdx_425;
					--r8_423;
					if (r8_423 == 0x00)
						break;
				}
				byte * rax_450 = rdx_425 - 0x01;
				&rdi_1294.u0->b0000 = 0x02;
				if (r8_423 != 0x00)
					rax_450 = rdx_425;
				*rax_450 = 0x00;
l0000000140006D6C:
				rbx_1007.u0 = 0x14000CE1E;
			}
			else
			{
l0000000140006947:
				rsi_2180.u0 = 0x00;
			}
l000000014000694A:
		} while (*r14_1179 != 0x00);
		if (g_dw4000CD0C != 0x00 && (g_b4000CE1E == 0x00 && GetModuleFileNameA(g_t4000DE70, rbx_1007, 0x0104) != 0x00))
			*((word64) fn0000000140008A2C(rbx_1007, 0x5C) + 1) = 0x00;
	}
l0000000140006DAE:
	word64 rax_1154 = fn00000001400013E0(rax_27 ^ fp - 0x0188);
	ebxOut.u0 = <invalid>;
	rsiOut = rsi;
	rdiOut = rdi;
	r14wOut.u0 = <invalid>;
	return (word32) rax_1154;
}

// 0000000140006DF0: void fn0000000140006DF0(Register word32 ecx)
void fn0000000140006DF0(word32 ecx)
{
	word32 r11d_13 = (word32) (uint64) ecx;
	word32 ebx_27;
	fn0000000140006E0A(0x08, 0x0200, g_a4000CCC0, r11d_13, out ebx_27);
}

// 0000000140006E0A: Register word32 fn0000000140006E0A(Register uint64 rbx, Register ui32 r9d, Register (ptr64 word32) r10, Register word32 r11d, Register out Eq_480 ebxOut)
// Called from:
//      fn0000000140006768
//      fn0000000140006DF0
word32 fn0000000140006E0A(uint64 rbx, ui32 r9d, word32 * r10, word32 r11d, union Eq_480 & ebxOut)
{
	do
	{
		uint32 edx_12 = (uint32) (0x00 % r9d);
		*r10 += (word32) (uint64) ((word32) (uint64) ((word32) (uint64) ((word32) (uint64) (0x00 - ((word32) ((uint64) (-((word32) ((uint64) edx_12)))) == 0x00)) & r9d) - edx_12) + r11d);
		r9d = (word32) (uint64) (r9d * 0x02);
		++r10;
		--rbx;
	} while (rbx != 0x00);
	ebxOut.u0 = <invalid>;
	return (word32) (uint64) (word32) (rbx + 0x01);
}

// 0000000140006E50: void fn0000000140006E50(Register word32 ecx, Register Eq_225 r8, Register Eq_225 r9)
void fn0000000140006E50(word32 ecx, Eq_225 r8, Eq_225 r9)
{
	ui64 rax_16 = g_qw4000C008 ^ fp - 0x0188;
	word32 esi_113 = (word32) (uint64) ecx;
	byte * rdx_25 = fp - 0x0138;
	int64 rcx_31 = 0x14000D610 - (fp - 0x0138);
	uint64 r9_37 = 0x0104;
	while (r9_37 != 0x7FFFFEFA)
	{
		byte al_46 = rdx_25[rcx_31];
		if (al_46 == 0x00)
			break;
		*rdx_25 = al_46;
		++rdx_25;
		--r9_37;
		if (r9_37 == 0x00)
			break;
	}
	byte * rax_57 = rdx_25 - 0x01;
	if (r9_37 != 0x00)
		rax_57 = rdx_25;
	*rax_57 = 0x00;
	fn000000014000887C(fp - 0x0138, 0x0104, r8);
	Eq_384 rax_102 = CreateFileA(fp - 0x0138, 0x40000000, 0x00, null, 0x02, 0x80, null);
	if (rax_102 == (void *) ~0x00)
		g_dw4000D544 = 0x80070052;
	else
	{
		if (WriteFile(rax_102, r9, (uint64) esi_113, fp - 0x0148, null) == 0x00 || esi_113 != 0x00)
			g_dw4000D544 = 0x80070052;
		CloseHandle(rax_102);
	}
	fn00000001400013E0(rax_16 ^ fp - (CHAR *) 0x0188);
}

// 0000000140006F90: Register word32 fn0000000140006F90(Register (ptr64 byte) rcx, Register (ptr64 word32) rdx)
// Called from:
//      fn0000000140006768
word32 fn0000000140006F90(byte * rcx, word32 * rdx)
{
	cu8 al_15 = *rcx;
	uint64 r8_152 = 0x00;
	if (al_15 != 0x00)
	{
		byte * rdx_14 = rcx;
		r8_152 = 0x00;
		do
		{
			word32 r8d_25 = (word32) r8_152;
			if (al_15 != 0x20 && (al_15 > 0x0D || al_15 < 0x09))
				break;
			++rdx_14;
			r8_152 = (uint64) (r8d_25 + 0x01);
			al_15 = *rdx_14;
		} while (al_15 != 0x00);
	}
	word32 r8d_34 = (word32) r8_152;
	byte r10_41[] = rcx + (int64) r8d_34;
	if (r10_41[0] == 0x00)
		return 0x00;
	int64 rcx_48 = ~0x00;
	do
	{
		++rcx_48;
		word32 ecx_57 = (word32) rcx_48;
	} while (r10_41[rcx_48] != 0x00);
	int32 ecx_60 = (word32) (uint64) (ecx_57 - 0x01);
	int64 rdx_62 = (int64) ecx_60;
	if (ecx_60 >= 0x00)
	{
		do
		{
			cu8 al_67 = r10_41[rdx_62];
			if (al_67 != 0x20 && al_67 > 0x0D)
				break;
			ecx_60 = (word32) (uint64) (ecx_60 - 0x01);
			--rdx_62;
		} while (rdx_62 >= 0x00);
	}
	*rdx = r8d_34;
	rcx[(int64) (word32) (uint64) (ecx_60 + r8d_34) + 0x01] = 0x00;
	return 0x01;
}

// 0000000140007010: Register word32 fn0000000140007010(Register Eq_225 rcx, Register Eq_8594 rdx, Register Eq_4964 xmm0)
// Called from:
//      fn000000014000721C
word32 fn0000000140007010(Eq_225 rcx, Eq_8594 rdx, Eq_4964 xmm0)
{
	ui64 rax_13 = g_qw4000C008 ^ fp - 0x0288;
	if (rcx == 0x00)
		return (word32) fn00000001400013E0(rax_13 ^ fp - 0x0288);
	Eq_8605 xmm0_27 = __xorps(xmm0, xmm0);
	Eq_384 qwLoc0230_267 = (word64) xmm0_27;
	Eq_384 qwLoc0228_272 = SLICE(xmm0_27, word64, 64);
	if (CreateProcessA(0x00, rcx, null, null, 0x00, 0x20, 0x00, 0x00, rdx, fp - 0x0230) == 0x00)
	{
		g_dw4000D544 = (word32) (uint64) fn0000000140006590();
		FormatMessageA(0x1000, 0x00, (uint64) GetLastError(), 0x00, fp - 0x0218, 0x0200, null);
		word128 xmm0_363;
		fn00000001400061E8(null, 0x04C4, rcx, fp - 0x0218, 0x10, 0x00, out xmm0_363);
		return (word32) fn00000001400013E0(rax_13 ^ fp - 0x0288);
	}
	WaitForSingleObject(qwLoc0230_267, 0xFFFFFFFF);
	GetExitCodeProcess(qwLoc0230_267, fp - 0x0238);
	int32 ebx_125 = (word32) (uint64) dwLoc0238;
	byte bl_168 = (byte) ebx_125;
	if (g_dw4000CD08 == 0x00)
	{
		uint64 rcx_116 = (uint64) g_dw4000DE5C;
		byte cl_118 = (byte) rcx_116;
		int32 ecx_134 = (word32) rcx_116;
		if ((cl_118 & 0x01) != 0x00 && (cl_118 & 0x02) == 0x00)
		{
			if ((word32) (uint64) ((word32) (uint64) ebx_125 & 0xFF000000) == 0xAA000000)
				ecx_134 = ebx_125;
			g_dw4000DE5C = ecx_134;
		}
	}
	if ((g_t4000DE64 & 0x0800) == 0x00)
	{
		if ((word32) (uint64) fn0000000140002540() != 0x02 && ((word32) ((uint64) ((word32) ((uint64) ebx_125) & 0xFF000000)) != 0xAA000000 || (bl_168 & 0x01) == 0x00))
		{
			if ((g_t4000DE64 & 0x0200) != 0x00)
				goto l000000014000710D;
		}
		else
			g_dw4000D544 = 3010;
l000000014000714A:
		CloseHandle(qwLoc0228_272);
		CloseHandle(qwLoc0230_267);
		if ((g_t4000DE64 & 0x0400) == 0x00 || dwLoc0238 >= 0x00)
			return (word32) fn00000001400013E0(rax_13 ^ fp - 0x0288);
		return (word32) fn00000001400013E0(rax_13 ^ fp - 0x0288);
	}
	else
	{
l000000014000710D:
		g_dw4000D544 = ebx_125;
		goto l000000014000714A;
	}
}

// 000000014000721C: Register word32 fn000000014000721C()
// Called from:
//      fn00000001400046E8
word32 fn000000014000721C()
{
	ui64 rax_28 = g_qw4000C008 ^ fp - 0x0588;
	g_dw4000D544 = 0x00;
	word32 r15d_295 = 0x00;
	word32 r12d_391 = 0x00;
	if (g_dw4000CD08 == 0x00 && (word32) ((uint64) ((word32) ((uint64) fn0000000140005140(0x140009920, 0x14000DE5C, 0x04)) - 0x01)) > 0x03)
	{
l00000001400073B6:
		word128 xmm0_1487;
		fn00000001400061E8(null, 1201, 0x00, null, 0x10, 0x00, out xmm0_1487);
		g_dw4000D544 = 0x80070714;
		return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
	}
	up32 r14d_167 = 0x00;
	Eq_8790 rdi_1481 = 0x01;
l000000014000729D:
	up32 edi_175;
	up32 edi_147 = (word32) rdi_1481;
	memset(fp - 0x0504, 0x00, 100);
	byte dil_244 = (byte) edi_147;
	if (g_b4000CF22 == 0x00)
	{
		if ((word32) (uint64) ((word32) (uint64) fn0000000140005140(0x140009928, fp - 0x0548, 0x04) - 0x01) > 0x03)
			goto l00000001400073B6;
		up32 eax_146 = (word32) (uint64) dwLoc0548;
		if (eax_146 == edi_147 || (eax_146 == 0x02 || eax_146 == 0x03))
			;
		if (r14d_167 == 0x00)
		{
			uint64 rax_239 = (uint64) (word32) g_t4000CD18;
			byte al_245 = (byte) rax_239;
			if ((word16) rax_239 != 0x00)
			{
				Eq_225 rcx_252;
				if ((dil_244 & al_245) != 0x00)
					rcx_252.u0 = 0x140009938;
				else
				{
					if ((al_245 & 0x02) == 0x00)
						return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
					rcx_252.u0 = 0x140009940;
				}
				if ((word32) (uint64) fn0000000140005140(rcx_252, fp - 1176, 0x0104) == 0x00)
					goto l00000001400073B6;
				if ((word32) (uint64) (CompareStringA(0x7F, (uint64) edi_147, fp - 1176, 0xFFFFFFFF, 0x140009918, ~0x00) - 0x02) != ~0x01)
				{
					r15d_295 = (word32) (uint64) edi_147;
l000000014000748A:
					word16 di_400 = (word16) edi_147;
					Eq_4964 xmm0_373;
					if ((word32) (uint64) fn0000000140001D28(fp - 1176, fp - 0x0550, fp - 0x0558, out xmm0_373) == 0x00)
						return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
					Eq_8790 rdi_1484;
					if (r12d_391 == 0x00 && (g_w4000DE78 != di_400 && g_dw4000CD00 != 0x00))
					{
						if (false)
						{
l00000001400074D4:
							if (g_dw4000C1A8 == 0x00)
							{
								word128 xmm0_1488;
								fn00000001400061E8(null, 1223, 0x00, null, 0x10, 0x00, out xmm0_1488);
								LocalFree(qwLoc0550);
								g_dw4000D544 = 0x8007042B;
								return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
							}
							if (false && (g_t4000DE64 & 0x04) != 0x00)
							{
								Eq_265 rax_512 = fn00000001400065B8();
								if (rax_512 != 0x00)
								{
									Eq_969 rax_549 = GetProcAddress(rax_512, 0x14000C1C0);
									if (rax_549 != null)
									{
										ui32 ecx_620 = (word32) (uint64) (word32) g_t4000CD18;
										if (g_dw4000CD10 != 0x00)
											__bts(ecx_620, 0x10, out ecx_620);
										byte al_629 = (byte) (uint64) g_t4000DE64;
										if ((al_629 & 0x08) != 0x00)
											__bts(ecx_620, 0x11, out ecx_620);
										if ((al_629 & 0x10) != 0x00)
											__bts(ecx_620, 0x12, out ecx_620);
										ci8 al_651 = (byte) (uint64) g_dw4000D028;
										if ((al_651 & 0x40) != 0x00)
											__bts(ecx_620, 0x13, out ecx_620);
										if (al_651 < 0x00)
										{
											word32 ecx_665;
											__bts(ecx_620, 0x14, out ecx_665);
										}
										fn0000000140008E50();
										int32 eax_684 = (word32) rax_549;
										g_dw4000D544 = eax_684;
										if (eax_684 >= 0x00)
										{
											FreeLibrary(rax_512);
											rdi_1484.u0 = 0x01;
l0000000140007614:
											LocalFree(qwLoc0550);
											edi_175 = (word32) rdi_1484;
											r14d_167 = (word32) (uint64) (r14d_167 + edi_175);
											if (r14d_167 < 0x02)
											{
												rdi_1481 = rdi_1484;
												goto l000000014000729D;
											}
											goto l000000014000773F;
										}
										FreeLibrary(rax_512);
l0000000140007646:
										LocalFree(qwLoc0550);
										return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
									}
									word128 xmm0_1490;
									fn00000001400061E8(null, 1225, 0x14000C1C0, null, 0x10, 0x00, out xmm0_1490);
									FreeLibrary(rax_512);
								}
								else
								{
									word128 xmm0_1489;
									fn00000001400061E8(null, 1224, 0x140009818, null, 0x10, 0x00, out xmm0_1489);
								}
								LocalFree(qwLoc0550);
								g_dw4000D544 = (word32) (uint64) fn0000000140006590();
								return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
							}
l00000001400075FF:
							rdi_1484 = rdi_1481;
							if ((word32) (uint64) fn0000000140007010(qwLoc0550, fp - 0x0508, xmm0_373) != 0x00)
								goto l0000000140007614;
							goto l0000000140007646;
						}
						r12d_391 = (word32) (uint64) edi_147;
						xmm0_373 = fn0000000140001A08();
					}
					if (true)
						goto l00000001400075FF;
					goto l00000001400074D4;
				}
			}
			if (r15d_295 == 0x00 && (word32) ((uint64) fn0000000140005140(0x140009948, fp - 1176, 0x0104)) == 0x00)
				goto l00000001400073B6;
			goto l000000014000748A;
		}
	}
	else
	{
		uint64 rdx_108 = 0x0104;
		int64 r8_90 = 0x14000CF22 - (fp - 1176);
		Eq_8825 rcx_107 = fp - 1176;
		while (rdx_108 != 0x7FFFFEFA)
		{
			byte al_101 = *((word64) rcx_107 + r8_90);
			if (al_101 == 0x00)
				break;
			*rcx_107 = al_101;
			rcx_107 += rdi_1481;
			rdx_108 -= rdi_1481;
			if (rdx_108 == 0x00)
				break;
		}
		Eq_8825 rax_115 = rcx_107 - 0x01;
		if (rdx_108 != 0x00)
			rax_115 = rcx_107;
		*rax_115 = 0x00;
	}
	edi_175 = edi_147;
	if (r14d_167 == edi_147)
	{
		if ((word32) (uint64) fn0000000140005140(0x140009958, fp - 1176, 0x0104) == 0x00)
			goto l00000001400073B6;
		if (g_b4000CF22 != 0x00 || CompareStringA(0x7F, (uint64) edi_147, fp - 1176, 0xFFFFFFFF, 0x140009918, ~0x00) == 0x02)
		{
l000000014000773F:
			Eq_9094 rsi_838 = ~0x00;
			if (g_dw4000C820 != 0x00 && (g_b4000C7D0 != 0x00 && RegOpenKeyExA(~0x7FFFFFFD, 0x14000C088, 0x00, 131103, fp - 0x0550) == 0x00))
			{
				if (RegQueryValueExA(qwLoc0550, 0x14000C7D0, 0x00, 0x00, fp - 0x0278, fp - 0x0558) == 0x00)
				{
					memset(fp - 0x0388, 0x00, 0x0104);
					if (GetSystemDirectoryA(fp - 0x0388, 0x0104) != 0x00)
						fn000000014000887C(fp - 0x0388, 0x0104, 0x140009770);
					fn000000014000366C(fp - 0x0278, (byte *) 0x0238, 0x14000C058);
					do
					{
						rsi_838 = (word64) rsi_838 + 1;
						word32 esi_845 = (word32) rsi_838;
					} while (Mem829[fp - 0x0278 + rsi_838:byte] != 0x00);
					RegSetValueExA(qwLoc0550, 0x14000C7D0, 0x00, (uint64) edi_175, fp - 0x0278, (word32) (uint64) (esi_845 + edi_175));
				}
				RegCloseKey(qwLoc0550);
			}
			return (word32) fn00000001400013E0(rax_28 ^ fp - (BYTE *) 0x0588);
		}
	}
	goto l000000014000748A;
}

// 00000001400078B0: void fn00000001400078B0(Register word32 rax_32_32, Register Eq_1049 rcx, Register word32 edx, Register uint64 r8)
void fn00000001400078B0(word32 rax_32_32, Eq_1049 rcx, word32 edx, uint64 r8)
{
	word32 edx_21 = (word32) (uint64) (edx - 0x10);
	if (edx_21 == 0x00)
	{
		EndDialog(rcx, 0x00);
		return;
	}
	word32 edx_36 = (word32) (uint64) (edx_21 - 0x0100);
	if (edx_36 == 0x00)
	{
		fn0000000140003C8C(rcx, SEQ(rax_32_32, GetDesktopWindow()));
		SetWindowTextA(rcx, 5368763768);
		SendDlgItemMessageA(rcx, 2101, 0xC5, 0x0103, 0);
		if (g_w4000DE78 == 0x01)
			EnableWindow(GetDlgItem(rcx, 2102), 0x00);
		return;
	}
	if (edx_36 != 0x01)
		return;
	Eq_3409 rdx_243;
	if (r8 != 0x01)
	{
		if (r8 == 0x02)
		{
			EndDialog(rcx, 0x00);
			g_dw4000D544 = 0x800704C7;
			return;
		}
		if (r8 != 2102)
			return;
		Eq_405 rdx_350;
		if (LoadStringA(g_t4000DE70, 1000, 0x14000C850, 0x0200) == 0x00)
			rdx_350.u0 = 1201;
		else
		{
			if ((word32) (uint64) fn0000000140003950(rcx) == 0x00 || SetDlgItemTextA(rcx, 2101, 0x14000CA60) != 0x00)
				return;
			rdx_350.u0 = 0x04C0;
		}
		word128 xmm0_531;
		fn00000001400061E8(rcx, rdx_350, 0x00, null, 16, 0x00, out xmm0_531);
		rdx_243.u1 = 0x00;
l0000000140007ACF:
		EndDialog(rcx, rdx_243);
		return;
	}
	Eq_1054 dwLoc10_434;
	Eq_405 rdx_118;
	Eq_225 r8_257;
	if (GetDlgItemTextA(rcx, 2101, 0x14000D610, 0x0104) != 0x00)
	{
		struct Eq_9347 * rax_102 = (struct Eq_9347 *) ~0x00;
		do
			++rax_102;
		while (rax_102[0x4000D610] != 0x00);
		if (rax_102 >= (struct Eq_9347 *) 0x03)
		{
			byte al_110 = g_b4000D611;
			if (al_110 == 0x3A || g_a4000D610[0] == 0x5C && al_110 == 0x5C)
			{
				if (GetFileAttributesA(0x14000D610) == ~0x00)
				{
					word128 xmm0_529;
					if ((word32) (uint64) fn00000001400061E8(rcx, 0x054A, 0x14000D610, null, 32, 0x04, out xmm0_529) != 0x06)
						return;
					Eq_407 eax_157 = CreateDirectoryA(0x14000D610, null);
					if (eax_157 == 0x00)
					{
						dwLoc10_434 = eax_157 & 0x04;
						r8_257.u0 = 0x14000D610;
						rdx_118.u0 = 1227;
						goto l0000000140007AF3;
					}
				}
				fn000000014000887C(0x14000D610, 0x0104, 0x140009770);
				word128 xmm0_528;
				if ((word32) (uint64) fn0000000140005ED8(0x14000D610, out xmm0_528) != 0x00)
				{
					Eq_4601 rdx_206;
					if (g_a4000D610[0] == 0x5C && g_b4000D611 == 0x5C)
						rdx_206.u0 = 0x00;
					else
						rdx_206.u0 = 0x01;
					word128 xmm0_532;
					if ((word32) (uint64) fn0000000140005B50(0x14000D610, rdx_206, 0x01, out xmm0_532) == 0x00)
						return;
					rdx_243.u0 = 0x01;
					goto l0000000140007ACF;
				}
				rdx_118.u0 = 1214;
l0000000140007AE8:
				dwLoc10_434.u0 = 0x00;
				r8_257.u0 = 0x00;
l0000000140007AF3:
				word128 xmm0_530;
				fn00000001400061E8(rcx, rdx_118, r8_257, null, 16, dwLoc10_434, out xmm0_530);
				return;
			}
		}
	}
	rdx_118.u0 = 1215;
	goto l0000000140007AE8;
}

// 0000000140007BB8: Register word32 fn0000000140007BB8(Register Eq_5125 ecx)
// Called from:
//      fn00000001400046E8
//      fn0000000140004F18
word32 fn0000000140007BB8(Eq_5125 ecx)
{
	ui64 rax_14 = g_qw4000C008 ^ fp - 88;
	while (true)
	{
		fn000000014000366C(fp - 0x28, (byte *) 0x14, 0x140009A40);
		Eq_5369 rax_42 = FindResourceA(0x00, fp - 0x28, 0x0A);
		if (rax_42 == null)
			break;
		Eq_225 rax_51 = LockResource(LoadResource(0x00, rax_42));
		if (rax_51 == 0x00)
		{
			g_dw4000D544 = 0x80070714;
			return (word32) fn00000001400013E0(rax_14 ^ fp - 88);
		}
		Eq_9498 rax_63 = ~0x00;
		do
			rax_63 = (word64) rax_63 + 1;
		while (Mem15[rax_51 + 0x08 + rax_63:byte] != 0x00);
		fn0000000140008E50();
		if ((word32) rcx == 0x00)
		{
			FreeResource(rax_51);
			return (word32) fn00000001400013E0(rax_14 ^ fp - 88);
		}
		FreeResource(rax_51);
	}
	return (word32) fn00000001400013E0(rax_14 ^ fp - 88);
}

// 0000000140007CE0: void fn0000000140007CE0(Register (ptr64 Eq_9518) rcx)
// Called from:
//      fn00000001400081D0
void fn0000000140007CE0(struct Eq_9518 * rcx)
{
	struct Eq_9519 * rax_14 = (char *) &g_t4000D830 + 0x0C;
	uint64 rcx_33;
	struct Eq_9523 * rdx_11 = &g_t4000DB4C;
	for (rcx_33 = 0x06; rcx_33 != 0x00; --rcx_33)
	{
		rax_14->ow0000 = rdx_11->ow0000;
		rax_14->ow0010 = rdx_11->ow0010;
		rax_14->ow0020 = rdx_11->ow0020;
		rax_14->ow0030 = rdx_11->ow0030;
		rax_14->ow0040 = rdx_11->ow0040;
		rax_14->ow0050 = rdx_11->ow0050;
		rax_14->ow0060 = rdx_11->ow0060;
		++rax_14;
		rax_14->owFFFFFFF0 = rdx_11->ow0070;
		++rdx_11;
	}
	rax_14->ow0000 = rdx_11->ow0000;
	uint64 rdx_126 = 0x0104;
	byte * rcx_40 = &g_t4000DB4C;
	uint64 r8_43 = 0x0104;
	byte * r9_51 = rcx->ptr0018;
	while (r8_43 != 0x7FFFFEFA)
	{
		byte al_59 = *r9_51;
		if (al_59 == 0x00)
			break;
		*rcx_40 = al_59;
		++r9_51;
		++rcx_40;
		--r8_43;
		if (r8_43 == 0x00)
			break;
	}
	byte * rax_74 = rcx_40 - 0x01;
	uint64 r8_106 = 0x0104;
	if (r8_43 != 0x00)
		rax_74 = rcx_40;
	*rax_74 = 0x00;
	byte * rcx_102 = &g_b4000DC50;
	Eq_225 r9_104 = rcx->t0008;
	while (r8_106 != 0x7FFFFEFA)
	{
		byte al_98 = *r9_104;
		if (al_98 == 0x00)
			break;
		*rcx_102 = al_98;
		r9_104 = (word128) r9_104 + 1;
		++rcx_102;
		--r8_106;
		if (r8_106 == 0x00)
			break;
	}
	byte * rax_113 = rcx_102 - 0x01;
	if (r8_106 != 0x00)
		rax_113 = rcx_102;
	*rax_113 = 0x00;
	byte * rcx_116 = &g_b4000DD54;
	byte * r8_125 = rcx->ptr0010;
	while (rdx_126 != 0x7FFFFEFA)
	{
		byte al_133 = *r8_125;
		if (al_133 == 0x00)
			break;
		*rcx_116 = al_133;
		++r8_125;
		++rcx_116;
		--rdx_126;
		if (rdx_126 == 0x00)
			break;
	}
	byte * rax_148 = rcx_116 - 0x01;
	if (rdx_126 != 0x00)
		rax_148 = rcx_116;
	*rax_148 = 0x00;
	g_w4000DE58 = (word16) (uint64) (word32) rcx->w0036;
	g_w4000DE5A = (word16) (uint64) (word32) rcx->w0038;
}

// 0000000140007E28: Register word32 fn0000000140007E28(Register Eq_4964 xmm0)
// Called from:
//      fn0000000140004BE0
word32 fn0000000140007E28(Eq_4964 xmm0)
{
	ui64 rax_11 = g_qw4000C008 ^ fp - 0x88;
	Eq_8605 xmm0_22 = __xorps(xmm0, xmm0);
	word64 rax_38;
	Cabinet.dll!Ordinal_20();
	word32 dwLoc38_152 = (word32) xmm0_22;
	if (rax_38 == 0x00)
		return (word32) fn00000001400013E0(rax_11 ^ fp - 0x88);
	ui64 rax_56 = fn0000000140008400(0x14000C200, 0x8000);
	if (rax_56 == ~0x00)
		return (word32) fn00000001400013E0(rax_11 ^ fp - 0x88);
	word64 rax_73;
	Cabinet.dll!Ordinal_21();
	if ((word32) rax_73 == 0x00 || (dwLoc38_152 != (word32) ((uint64) g_dw4000D568) || (false || (false || (word32) ((uint64) fn0000000140008160(rax_56)) == ~0x00))))
		return (word32) fn00000001400013E0(rax_11 ^ fp - 0x88);
	word64 rax_104;
	Cabinet.dll!Ordinal_23();
	if ((word32) rax_104 == 0x00)
		return (word32) fn00000001400013E0(rax_11 ^ fp - 0x88);
	return (word32) fn00000001400013E0(rax_11 ^ fp - 0x88);
}

// 0000000140007F58: void fn0000000140007F58()
// Called from:
//      fn00000001400049A0
//      fn00000001400087A0
void fn0000000140007F58()
{
	word32 ebx_11 = 0x00;
	while (MsgWaitForMultipleObjects(0x01, fp + 0x08, 0x00, 0xFFFFFFFF, 0x04FF) != 0x00)
	{
		while (PeekMessageA(fp - 0x38, null, 0x00, 0x00, 0x01) != 0x00)
		{
			if (dwLoc30 == 0x12)
				ebx_11 = 0x01;
			else
				DispatchMessageA(fp - 0x38);
		}
		if (ebx_11 != 0x00)
			return;
	}
}

// 0000000140007FE4: Register word32 fn0000000140007FE4(Register Eq_265 rcx, Register Eq_225 r8)
// Called from:
//      Win32CrtStartup
word32 fn0000000140007FE4(Eq_265 rcx, Eq_225 r8)
{
	Eq_126 eax_15 = GetVersion();
	cu8 al_21 = (byte) eax_15;
	if (eax_15 >= 0x00 && al_21 >= 0x06)
	{
		Eq_265 rax_25 = GetModuleHandleW(&g_t40009890);
		if (rax_25 != 0x00 && GetProcAddress(rax_25, 0x1400098B0) != null)
			fn0000000140008E50();
	}
	g_dw4000D544 = 0x00;
	struct Eq_6373 * rsi_66 = (struct Eq_6373 *) <invalid>;
	byte sil_112 = (byte) rsi_66;
	word16 si_174 = (word16) rsi_66;
	word16 si_290;
	if ((word32) (uint64) fn0000000140005810(rcx, r8, out si_290) != 0x00)
	{
		word32 ebx_108 = (word32) (uint64) (word32) (uint64) fn00000001400046E8();
		fn00000001400043CC();
		if (ebx_108 == 0x00 || g_b4000CD1A != sil_112)
			goto l00000001400080FA;
		byte bl_117 = (byte) (uint64) g_dw4000DE5C;
		if ((bl_117 & 0x01) != 0x00 && ((bl_117 & 0x02) != 0x00 || (word32) ((uint64) fn0000000140002540()) == 0x02))
		{
			if ((bl_117 & 0x04) == 0x00)
			{
				word128 xmm0_291;
				if ((word32) (uint64) fn00000001400061E8(null, 0x0522, 0x140009770, null, 0x40, 0x04, out xmm0_291) != 0x06)
					goto l00000001400080FA;
			}
			if (g_w4000DE78 == si_174)
				ExitWindowsEx(0x02, 0x00);
			else
				fn00000001400033BC();
		}
	}
l00000001400080FA:
	Eq_384 rcx_198 = g_t4000C830;
	if (rcx_198 != null)
		CloseHandle(rcx_198);
	return (word32) (uint64) g_dw4000D544;
}

// 0000000140008160: Register word32 fn0000000140008160(Register ui64 rcx)
// Called from:
//      fn0000000140007E28
//      fn00000001400081D0
word32 fn0000000140008160(ui64 rcx)
{
	word32 ecx_22;
	if ((word64) (rcx << 0x05) + 4 + 0x14000D040 == 0x01)
	{
		(&g_t4000D040)[rcx] = (struct Eq_5064) 0x01;
		(word64) (rcx << 0x05) + 8 + 0x14000D040 = 0x00;
		(word64) (rcx << 0x05) + 16 + 0x14000D040 = 0x00;
		ecx_22 = 0x00;
	}
	else
	{
		ecx_22 = 0x00;
		if (CloseHandle((word64) (rcx << 0x05) + 24 + 0x14000D040) != 0x00)
			(&g_t4000D040)[rcx] = (struct Eq_5064) 0x01;
		else
			ecx_22 = ~0x00;
	}
	return (word32) (uint64) ecx_22;
}

// 00000001400081D0: void fn00000001400081D0(Register word32 ecx, Register (ptr64 Eq_9518) rdx)
void fn00000001400081D0(word32 ecx, struct Eq_9518 * rdx)
{
	ui64 rax_19 = g_qw4000C008 ^ fp - 0x0168;
	if (g_dw4000D5FC != 0x00)
	{
		if (ecx == 0x03)
			fn0000000140008160(rdx->qw0028);
		goto l0000000140008213;
	}
	if (ecx == 0x00)
	{
		fn0000000140007CE0(rdx);
		goto l00000001400083AF;
	}
	word32 ecx_50 = (word32) (uint64) (ecx - 0x01);
	if (ecx_50 != 0x00)
	{
		word32 ecx_55 = (word32) (uint64) (ecx_50 - 0x01);
		if (ecx_55 != 0x00)
		{
			word32 ecx_148 = (word32) (uint64) (ecx_55 - 0x01);
			if (ecx_148 != 0x00)
			{
				if (ecx_148 != 0x01)
					goto l000000014000823C;
				goto l0000000140008213;
			}
			if ((word32) (uint64) fn0000000140003BA8(fp - 0x0138, 0x14000D610, rdx->t0008) == 0x00)
				goto l0000000140008213;
			ui64 rdi_169 = rdx->qw0028;
			if ((word64) (rdi_169 << 0x05) + 4 + 0x14000D040 != 0x01 && (DosDateTimeToFileTime((uint64) ((word32) rdx->w0030), (uint64) ((word32) rdx->w0032), fp - 0x0140) != 0x00 && (LocalFileTimeToFileTime(fp - 0x0140, fp - 0x0148) != 0x00 && SetFileTime(((word64) (rdi_169 << 0x05) + 24) + 0x14000D040, fp - 0x0148, fp - 0x0148, fp - 0x0148) != 0x00)))
			{
				Eq_126 rdx_211;
				fn0000000140008160(rdx->qw0028);
				if (rdx->w0034 == 0x00)
					rdx_211.u1 = 0x80;
				else
					rdx_211.u1 = (uint64) ((word32) (uint64) (word32) rdx->w0034 & 0x27);
				if (SetFileAttributesA(fp - 0x0138, rdx_211) != 0x00)
				{
l00000001400083AF:
					fn00000001400013E0(rax_19 ^ fp - 0x0168);
					return;
				}
			}
l0000000140008213:
			goto l00000001400083AF;
		}
		Eq_1049 rcx_58 = g_t4000C828;
		if (rcx_58 != null)
			SetDlgItemTextA(rcx_58, 0x0837, rdx->t0008);
		if ((word32) (uint64) fn0000000140003BA8(fp - 0x0138, 0x14000D610, rdx->t0008) == 0x00)
			goto l0000000140008213;
		if ((word32) (uint64) fn0000000140004140(fp - 0x0138) != 0x00)
		{
			if (fn0000000140008400(fp - 0x0138, 33538) != ~0x00 && (word32) ((uint64) fn00000001400037DC(fp - 0x0138)) != 0x00)
			{
				++g_dw4000D820;
				goto l00000001400083AF;
			}
			goto l0000000140008213;
		}
	}
l000000014000823C:
	goto l00000001400083AF;
}

// 0000000140008400: Register int64 fn0000000140008400(Register Eq_225 rcx, Register word32 edx)
// Called from:
//      fn0000000140007E28
//      fn00000001400081D0
int64 fn0000000140008400(Eq_225 rcx, word32 edx)
{
	uint64 rbx_32 = (uint64) edx;
	word32 r15d_24 = 0x00;
	byte bl_63 = (byte) rbx_32;
	word32 * rax_33 = &g_t4000D040;
	while (*rax_33 != 0x01)
	{
		r15d_24 = (word32) (uint64) (r15d_24 + 0x01);
		rax_33 += 8;
		if (rax_33 >= &g_t4000D540)
			break;
	}
	int64 rax_309;
	ui32 ebx_70 = (word32) rbx_32;
	if (r15d_24 == 0x28)
	{
		word128 xmm0_546;
		fn00000001400061E8(g_t4000C828, 1211, 0x00, null, 0x10, 0x00, out xmm0_546);
		goto l0000000140008474;
	}
	int64 rdx_261;
	int32 eax_57 = lstrcmpA(rcx, 0x14000C200);
	if (eax_57 == 0x00)
	{
		if ((ebx_70 & 0x010B) != 0x00)
		{
l0000000140008474:
			rax_309 = ~0x00;
			return rax_309;
		}
		rdx_261 = (int64) r15d_24;
		(&g_t4000D040)[rdx_261] = (struct Eq_5064) ((&g_t4000D040)[rdx_261] & eax_57);
		Eq_225 rax_297 = g_t4000D560;
		(word64) (rdx_261 << 0x05) + 16 + 0x14000D040 = (ui64) 0x00;
		(word64) (rdx_261 << 0x05) + 8 + 0x14000D040 = (ui64) rax_297;
		(word64) (rdx_261 << 0x05) + 20 + 0x14000D040 = (ui64) (word32) (uint64) g_dw4000D568;
		(word64) (rdx_261 << 0x05) + 4 + 0x14000D040 = (ui64) 0x01;
l0000000140008633:
		rax_309 = rdx_261;
		return rax_309;
	}
	Eq_384 rcx_148;
	if ((bl_63 & 0x08) != 0x00)
	{
		rcx_148 = (void *) ~0x00;
		goto l000000014000860D;
	}
	Eq_126 ebx_103;
	word32 ebp_85 = (word32) (uint64) ((word32) (uint64) ((word32) (uint64) (0x00 - (((byte) ((uint64) ebx_70) & 0x03) == 0x00)) & 0xC0000000) + 0x80000000);
	if (!__bt(ebx_70, 0x08))
	{
		if (!__bt(ebx_70, 0x0A))
			ebx_103.u0 = 0x01;
		else
			ebx_103 = (word32) (uint64) ((word32) (uint64) ((word32) (uint64) (0x00 - ((word32) ((uint64) (-((word32) ((uint64) (ebx_70 & 0x0200))))) == 0x00)) & ~0x01) + 0x04);
	}
	else
		ebx_103 = (word32) (uint64) ((word32) (uint64) ((word32) (uint64) (0x00 - ((word32) ((uint64) (-((word32) ((uint64) (ebx_70 & 0x0200))))) == 0x00)) & 0x02) + 0x03);
	Eq_384 rax_147 = CreateFileA(rcx, (uint64) ebp_85, 0x00, null, ebx_103, 0x80, null);
	rcx_148 = rax_147;
	if (rax_147 != (void *) ~0x00 || ebx_103 == 0x03)
	{
l000000014000860D:
		rdx_261 = (int64) r15d_24;
		(word64) (rdx_261 << 0x05) + 24 + 0x14000D040 = (ui64) rcx_148;
		if (rcx_148 != (void *) ~0x00)
		{
			(&g_t4000D040)[rdx_261] = (struct Eq_5064) 0x00;
			(word64) (rdx_261 << 0x05) + 4 + 0x14000D040 = (ui64) 0x00;
		}
		else
			rdx_261 = ~0x00;
		goto l0000000140008633;
	}
	if (*rcx == 0x00)
	{
l00000001400085E1:
		rcx_148 = CreateFileA(rcx, (uint64) ebp_85, 0x00, null, ebx_103, 0x80, null);
		goto l000000014000860D;
	}
	Eq_10403 al_155 = *((word128) rcx + 1);
	word64 rdi_156 = rcx + 0x02;
	word32 r14d_189 = 0x00;
	if (al_155 == 0x3A && Mem144[rcx + 0x02:byte] == 0x5C)
		rdi_156 = rcx + 0x03;
	else
	{
		if (*rcx != 0x5C || al_155 != 0x5C)
		{
			rdi_156 = rcx + 0x01;
l00000001400085DD:
			while (al_155 != 0x00)
			{
				if (al_155 == 0x5C && *((word64) rdi_156 - 1) != 0x3A)
				{
					if (r14d_189 != 0x00)
						r14d_189 = (word32) (uint64) (r14d_189 - 0x01);
					else
					{
						*rdi_156 = 0x00;
						CreateDirectoryA(rcx, null);
						*rdi_156 = 0x5C;
					}
				}
				Eq_225 rax_209 = CharNextA(rdi_156);
				rdi_156 = rax_209;
				al_155 = (Eq_10403) *rax_209;
			}
			goto l00000001400085E1;
		}
		r14d_189 = 0x02;
	}
	al_155 = (Eq_10403) *rdi_156;
	goto l00000001400085DD;
}

// 0000000140008660: void fn0000000140008660(Register ui64 rcx, Register Eq_225 rdx, Register Eq_126 r8)
void fn0000000140008660(ui64 rcx, Eq_225 rdx, Eq_126 r8)
{
	up32 r8d = (word32) r8;
	word32 ecx_21 = (word32) (uint64) ((word64) (rcx << 0x05) + 4 + 0x14000D040);
	if (ecx_21 != 0x00)
	{
		if (ecx_21 == 0x01)
		{
			up32 ebx_56 = (word32) (uint64) ((word32) (uint64) ((word64) (rcx << 0x05) + 20 + 0x14000D040) - (((word64) (rcx << 0x05) + 16) + 0x14000D040));
			int64 rdx_55 = (int64) ((word64) (rcx << 0x05) + 16 + 0x14000D040);
			if (r8d < ebx_56)
				ebx_56 = r8d;
			memcpy(rdx, rdx_55 + (((word64) (rcx << 0x05) + 8) + 0x14000D040), (int64) ebx_56);
			(word64) (rcx << 0x05) + 16 + 0x14000D040 = (ui64) ((word64) (rcx << 0x05) + 16 + 0x14000D040 + ebx_56);
		}
	}
	else
		ReadFile((word64) (rcx << 0x05) + 24 + 0x14000D040, rdx, r8, fp + 0x18, null) != 0x00;
}

// 0000000140008710: void fn0000000140008710(Register ui64 rcx, Register Eq_395 rdx, Register word32 r8d)
void fn0000000140008710(ui64 rcx, Eq_395 rdx, word32 r8d)
{
	word32 r8d = (word32) r8;
	word32 edx_58 = (word32) rdx;
	Eq_126 r9_18 = 0x01;
	if ((word64) (rcx << 0x05) + 4 + 0x14000D040 != 0x01)
	{
		if (r8d != 0x00)
		{
			word32 r8d_24 = (word32) (uint64) (r8d - 0x01);
			if (r8d_24 != 0x00)
			{
				if (r8d_24 != 0x01)
					return;
				r9_18.u1 = 0x02;
			}
		}
		else
			r9_18.u1 = 0x00;
		(word32) (uint64) SetFilePointer((word64) (rcx << 0x05) + 24 + 0x14000D040, rdx, null, r9_18) != ~0x00;
	}
	else
	{
		if (r8d != 0x00)
		{
			word32 r8d_55 = (word32) (uint64) (r8d - 0x01);
			if (r8d_55 != 0x00)
			{
				if (r8d_55 != 0x01)
					return;
				rdx.u0 = (uint64) (edx_58 + (((word64) (rcx << 0x05) + 20) + 0x14000D040));
			}
			else
				rdx.u0 = (uint64) (edx_58 + (((word64) (rcx << 0x05) + 16) + 0x14000D040));
		}
		(word64) (rcx << 0x05) + 16 + 0x14000D040 = (ui64) (word32) rdx;
	}
}

// 00000001400087A0: void fn00000001400087A0(Register ui64 rcx, Register Eq_225 rdx, Register word32 r8d)
void fn00000001400087A0(ui64 rcx, Eq_225 rdx, word32 r8d)
{
	fn0000000140007F58();
	if (g_dw4000D5FC == 0x00)
	{
		if (WriteFile((&g_t4000D040.dw0000 + 6)[rcx * 0x20 /64 0x4000DE80], rdx, (uint64) r8d, fp + 0x18, null) != 0x00)
		{
			word32 ebx_44 = (word32) (uint64) r8d;
			if (ebx_44 != ~0x00)
			{
				Eq_10678 rdx_51 = (uint64) ((word32) (uint64) g_dw4000D82C + ebx_44);
				g_dw4000D82C = (word32) rdx_51;
				if (g_t4000C1AC != 0x00)
				{
					Eq_1049 rcx_56 = g_t4000C828;
					if (rcx_56 != null)
						SendDlgItemMessageA(rcx_56, 0x083A, 0x0402, (uint64) ((uint128) (rdx_51 *s 100) /u (uint64) g_dw4000D824), 0);
				}
			}
		}
	}
}

// 000000014000887C: void fn000000014000887C(Register Eq_225 rcx, Register Eq_888 edx, Register Eq_225 r8)
// Called from:
//      fn0000000140001A08
//      fn0000000140001D28
//      fn00000001400026B8
//      fn0000000140002D34
//      fn0000000140003044
//      fn00000001400041EC
//      fn00000001400046E8
//      fn0000000140004FD8
//      fn000000014000521C
//      fn0000000140005ED8
//      fn00000001400065B8
//      fn0000000140006768
//      fn0000000140006E50
//      fn000000014000721C
//      fn00000001400078B0
void fn000000014000887C(Eq_225 rcx, Eq_888 edx, Eq_225 r8)
{
	Eq_888 edx = (word32) rdx;
	uint64 rbp_17 = (uint64) edx;
	Eq_225 rdi_14 = r8;
	up32 ebp_33 = (word32) rbp_17;
	int64 r8_18 = ~0x00;
	do
	{
		++r8_18;
		word32 r8d_36 = (word32) r8_18;
	} while (*((word128) rcx + r8_18) != 0x00);
	if ((word32) (uint64) (word32) (r8_18 + 0x01) < ebp_33)
	{
		Eq_225 rbx_40 = (word128) rcx + (uint64) r8d_36;
		if (rbx_40 > rcx && *CharPrevA(rcx, rbx_40) != 0x5C)
		{
			*rbx_40 = 0x5C;
			++rbx_40;
		}
		*rbx_40 = 0x00;
		while (*rdi_14 == 0x20)
			rdi_14 = (word128) rdi_14 + 1;
		fn00000001400035A8(rcx, rbp_17, rdi_14);
	}
}

// 0000000140008914: void fn0000000140008914(Register Eq_225 rcx)
// Called from:
//      fn0000000140002A10
//      fn00000001400043CC
void fn0000000140008914(Eq_225 rcx)
{
	int64 rdx_16 = ~0x00;
	do
		++rdx_16;
	while (*((word128) rcx + rdx_16) != 0x00);
	Eq_225 rdx_30 = CharPrevA(rcx, (word128) rcx + rdx_16);
	while (true)
	{
		Eq_225 rax_34 = CharPrevA(rcx, rdx_30);
		Eq_225 rbx_35 = rax_34;
		if (rax_34 <= rcx)
			break;
		if (*rax_34 == 0x5C)
			goto l0000000140008972;
		rdx_30 = rax_34;
	}
	if (*rax_34 != 0x5C)
		return;
	if (rax_34 != rcx)
	{
l0000000140008972:
		if (*CharPrevA(rcx, rax_34) != 0x3A)
		{
l000000014000899B:
			*rbx_35 = 0x00;
			return;
		}
	}
	rbx_35 = CharNextA(rax_34);
	goto l000000014000899B;
}

// 00000001400089BC: Register Eq_225 fn00000001400089BC(Register (ptr64 byte) rcx, Register word16 dx)
// Called from:
//      fn0000000140002C98
//      fn0000000140006768
Eq_225 fn00000001400089BC(byte * rcx, word16 dx)
{
	uint64 rsi_15 = (uint64) (word32) dx;
	bool v29_71 = *rbx_16 == 0x00;
	byte sil_64 = (byte) rsi_15;
	while (true)
	{
		Eq_225 rax_19;
		word56 rcx_56_8_32 = SLICE(rbx_16, word56, 8);
		if (v29_71)
			break;
		uint64 rdi_26 = (uint64) (word32) *rbx_101;
		byte dil_27 = (byte) rdi_26;
		word16 di_38 = (word16) rdi_26;
		word16 si_40 = (word16) rsi_15;
		if (dil_27 == sil_64 && (IsDBCSLeadByte(SEQ(rcx_56_8_32, dil_27)) == 0x00 || di_38 == si_40))
		{
			rax_19 = rbx_101;
			return rax_19;
		}
		Eq_225 rax_58 = CharNextA(rbx_101);
		rbx_16 = rax_58;
		v29_71 = *rax_58 == 0x00;
		rbx_101 = rbx_16;
	}
	rax_19.u0 = 0x00;
	return rax_19;
}

// 0000000140008A2C: Register Eq_225 fn0000000140008A2C(Register Eq_225 rcx, Register word16 dx)
// Called from:
//      fn0000000140001D28
//      fn0000000140006768
Eq_225 fn0000000140008A2C(Eq_225 rcx, word16 dx)
{
	word56 rcx_56_8_32 = SLICE(rcx, word56, 8);
	uint64 rbp_17 = (uint64) (word32) dx;
	Eq_225 rdi_14 = 0x00;
	byte bpl_69 = (byte) rbp_17;
	Eq_225 rbx_19 = rcx;
	if (*rcx != 0x00)
	{
		do
		{
			uint64 rsi_26 = (uint64) (word32) *rbx_19;
			byte sil_27 = (byte) rsi_26;
			word16 si_38 = (word16) rsi_26;
			word16 bp_40 = (word16) rbp_17;
			if (sil_27 == bpl_69 && (IsDBCSLeadByte(SEQ(rcx_56_8_32, sil_27)) == 0x00 || si_38 == bp_40))
				rdi_14 = rbx_19;
			Eq_225 rax_47 = CharNextA(rbx_19);
			rcx_56_8_32 = SLICE(rbx_19, word56, 8);
			rbx_19 = rax_47;
		} while (*rax_47 != 0x00);
	}
	return rdi_14;
}

// 0000000140008AE4: Register word32 fn0000000140008AE4()
// Called from:
//      fn0000000140003DF0
//      fn00000001400061E8
word32 fn0000000140008AE4()
{
	word32 ebx_15 = (word32) (uint64) g_dw4000C208;
	Eq_265 rdi_14 = g_t4000DE70;
	if (ebx_15 != ~0x01)
		return (word32) (uint64) ebx_15;
	g_dw4000C208 = 0x00;
	EnumResourceLanguagesA(rdi_14, 0x10, 0x01, &g_t40008AB0, (LONG_PTR) (fp - 0x18));
	ebx_15 = 0x01;
	if (true)
	{
		EnumResourceLanguagesA(rdi_14, 0x10, 0x01, &g_t40008AB0, (LONG_PTR) (fp - 0x18));
		if (true)
		{
			ebx_15 = (word32) (uint64) g_dw4000C208;
			return (word32) (uint64) ebx_15;
		}
	}
	g_dw4000C208 = 0x01;
	return (word32) (uint64) ebx_15;
}

// 0000000140008BB4: Register word32 fn0000000140008BB4()
// Called from:
//      fn0000000140003DF0
//      fn00000001400061E8
word32 fn0000000140008BB4()
{
	ui64 rax_16 = g_qw4000C008 ^ fp - 0x0118;
	if ((word32) (uint64) g_dw4000C20C != ~0x01)
		return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
	g_dw4000C20C = 0x00;
	ui32 edi_115 = 0x00;
	if (GetVersionExA(fp - 200) == 0x00 || (dwLocB8 != 0x01 || (dwLocC4 != 0x04 || (dwLocC0 >= 0x0A || (GetSystemMetrics(0x4A) == 0x00 || RegOpenKeyExA(~0x7FFFFFFE, 0x140009A50, 0x00, 0x00020019, fp - 0xE0) != 0x00)))))
		return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
	word32 ebx_75 = (word32) (uint64) RegQueryValueExA(qwLocE0, 0x140009770, 0x00, fp - 0xD8, fp - 0x28, fp - 232);
	RegCloseKey(qwLocE0);
	if (ebx_75 != 0x00)
		return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
	Eq_225 rcx_186 = fp - 0x28;
	while (true)
	{
		if (*rcx_186 <= 0x39)
			edi_115 = (word32) (uint64) ((word32) (uint64) ((word32) (uint64) (edi_115 + ~0x02) << 0x04) + (int32) (*rcx_186));
		else
		{
			byte dl_96 = (byte) (uint64) (word32) (*rcx_186 - 0x20);
			word32 eax_94 = (word32) (uint64) (word32) *rcx_186;
			if (*rcx_186 < 0x61)
				dl_96 = (byte) eax_94;
			int32 r8d_99 = (int32) dl_96;
			if ((word32) (uint64) (word32) ((uint64) r8d_99 - 0x41) > 0x05)
			{
				if (rcx_186 == fp - 0x28)
					return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
				word32 edi_118 = (word32) (uint64) (edi_115 & 0x03FF);
				if (edi_118 != 0x01 && edi_118 != 0x0D)
					return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
				g_dw4000C20C = 0x01;
				return (word32) fn00000001400013E0(rax_16 ^ fp - 0x0118);
			}
			edi_115 = (word32) (uint64) ((word32) (uint64) ((word32) (uint64) (edi_115 << 0x04) + ~0x36) + r8d_99);
		}
		rcx_186 = CharNextA(rcx_186);
	}
}

// 0000000140008D7C: void fn0000000140008D7C(Register Eq_11099 rdx, Register (ptr64 Eq_11100) r9)
void fn0000000140008D7C(Eq_11099 rdx, struct Eq_11100 * r9)
{
	fn0000000140008DA0(rdx, r9, r9->ptr0038);
}

// 0000000140008DA0: void fn0000000140008DA0(Register Eq_11099 rcx, Register (ptr64 Eq_11100) rdx, Register (ptr64 Eq_11105) r8)
// Called from:
//      fn0000000140008D7C
void fn0000000140008DA0(Eq_11099 rcx, struct Eq_11100 * rdx, struct Eq_11105 * r8)
{
	word32 r11d_33 = (word32) (uint64) ((word32) (uint64) r8->dw0000 & ~0x07);
	Eq_11099 r9_15 = rcx;
	Eq_11099 r10_18 = rcx;
	if ((r8->dw0000 & 0x04) != 0x00)
		r10_18 = (word64) rcx + (int64) r8->dw0004 & (int64) ((word32) ((uint64) (-((word32) ((uint64) r8->dw0008)))));
	word64 rdx_37 = *((word64) r10_18 + (int64) r11d_33);
	struct Eq_11133 * rcx_41 = (uint64) rdx->ptr0010->dw0008;
	struct Eq_11141 * rax_42 = rdx->ptr0008;
	if ((Mem5[rcx_41 + 0x03 + rax_42:byte] & 0x0F) != 0x00)
		r9_15 = rcx + CONVERT(SLICE(CONVERT(CONVERT(Mem5[(rcx_41 + 0x03) + rax_42:byte], byte, word32), word32, uint64), word32, 0) & ~0x0F, word32, uint64);
	ui64 r9_56 = r9_15 ^ rdx_37;
	fn00000001400013E0(r9_56);
}

// 0000000140008E30: void fn0000000140008E30(Register (ptr64 code) rax)
void fn0000000140008E30(<anonymous> * rax)
{
	rax();
}

// 0000000140008E50: void fn0000000140008E50()
// Called from:
//      Win32CrtStartup
//      fn0000000140002590
//      fn0000000140003950
//      fn00000001400046E8
//      fn000000014000721C
//      fn0000000140007BB8
//      fn0000000140007FE4
void fn0000000140008E50()
{
	g_ptr40009678();
}

// 0000000140008E60: void fn0000000140008E60(Register (ptr64 word64) rcx)
void fn0000000140008E60(word64 * rcx)
{
	word64 rax_11 = *rcx;
	XcptFilter();
}

// 0000000140008E90: void fn0000000140008E90()
void fn0000000140008E90()
{
}

